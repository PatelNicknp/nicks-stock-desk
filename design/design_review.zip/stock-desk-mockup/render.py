from playwright.sync_api import sync_playwright
import pathlib
base=pathlib.Path('/workspace/stock-desk-mockup')
shots=[('home','01-home'),('top','02-top-stocks'),('score','03-scorecard'),('watch','04-watchlist'),('bt','05-backtest')]
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox'])
    pg=b.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
    for h,n in shots:
        pg.goto(f'file://{base}/index.html#{h}');pg.wait_for_timeout(400)
        pg.screenshot(path=str(base/'screens'/f'{n}.png'),full_page=True)
        print(n, pg.evaluate('document.documentElement.scrollHeight'))
    b.close()
