# CANSLIM: Looker design spec (Design Pro)

**Purpose.** The CANSLIM letters from Nick's NSE scan, scored against SPY: which names qualify strictly and are ready, with each letter's number. Letters the free data cannot check say "not verified" in words, never 0. No stop or target on this page.

No sample picture (same look as `sample_vcp.png`).

## 1. Layout (content x 244-1376)

| y | Height | Left | Right |
| --- | --- | --- | --- |
| 106 | 36 | Control bar: Status (244), Qualify (460), Index (676), Ticker (892); feed status line x 1116 | |
| 158 | 56 | Market direction strip, full width: M (SPY) text and QQQ text | |
| 230 | 96 | 4 count cards of 271: Ready, Broken out today, Strict qualify, Watching | |
| 342 | 520 | CANSLIM table, full width, 14 rows | |
| 878 | 300 | Letter details (x 244, w 740) | Why this name (x 1000, w 376) |

Canvas 1400 x 1210.

## 2. Elements (tab `scanner_canslim`)

**Controls.** Status: `status`, multi, default READY + BROKEN OUT today. Qualify: `qualify`, default `strict` (soft is the on switch for near misses). Group both with the table and the two lower tables. Index: `index_membership`. Ticker: `ticker`, Search ON.

**Market direction strip (y 158, 1132 x 56).** Panel with two text-value boxes side by side: label "Market (SPY)" 11 pt muted over `m_market` 13 pt #E6EBF5 (x 260, w 640); label "QQQ" over `m_qqq` 13 pt #8B96AD (x 920, w 440). One value each today, so they read as one line. If `m_market` starts with UP colour it #22C55E, DOWN #EF4444, MIXED #F59E0B (rules: Starts with / Contains).

**Count cards (y 230).** Record Count: `status` = READY (108); `status` = BROKEN OUT today (0); `qualify` = strict (183); `status` = WATCHING (132).

**CANSLIM table (y 342, 1132 x 520).** Columns: `ticker` Ticker, `index_membership` Index, `status` Status, `pivot` Buy point (2), `strength` Strength (bar), `qualify` Qualify, `c_quarterly_eps` C: quarter EPS vs yr ago % (1), `a_annual_eps` A: annual EPS % (1), `n_pct_from_high` N: % from 52w high (1), `s_adv` S: avg daily volume (Compact ON), `l_rs_percentile` L: RS percentile (0), `i_trend` I: holders trend, `freshness` Data. Sort `strength` Descending. Rows 14. Cross-filtering ON. Colours: setup words (6), ticker (1), return rules on `c_quarterly_eps` and `a_annual_eps` (6), `i_trend` font: up #22C55E, down #EF4444, not verified #8B96AD (3), `qualify` strict #E6EBF5 bold / soft #8B96AD (2) = 18. `stop` and `target` are not on the table: blank on purpose.

**Letter details (x 244, y 878, 740 x 300).** Table: `ticker`, `c_status` C, `a_status` A, `n_status` N, `s_status` S, `l_status` L, `i_status` I (all wrap ON), Rows 2, sort `strength` Descending. These are the plain-English sentences, including "not verified". Leave them as text.

**Why this name (x 1000, y 878, 376 x 300).** Table `ticker`, `reason` (wrap), Rows 2, same sort. Caption "Click a row to read the letters and the reason."

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Setup words (pattern scanners).** `status` font, bold, Apply to Status column: Equal to BROKEN OUT today #22C55E; READY #F59E0B; WATCHING #8B96AD. `freshness` font: FRESH #8B96AD; PARTIAL #F59E0B; STALE #EF4444. Strength as a calm data bar: Style > the Strength column > Bar (Show number ON), bar colour #7C9CFF, 0 decimals.

**Click-to-read detail panel.** Main table: Setup > Chart interactions > Cross-filtering ON. The detail table (same tab) then shows the clicked row; with nothing clicked it shows the top rows by the same sort. Detail table: Dimensions `ticker` + the long text fields, Style > General > Horizontal OFF, Wrap text ON, Rows 3, header ON (11 pt muted). Caption above it: "Click a row in the table to read its full reason." 

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Return colours (text, not fill).** Per return column: > 0 font #22C55E; < 0 font #EF4444; = 0 leaves #E6EBF5; Is null > font #D6A64A. Apply to that column only.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Text-value box (one-row table).** For a text field (company, reason, headline): Insert > Table, Dimension = the field, remove the metric (Record Count). Style: Table header OFF, Pagination OFF, Row numbers OFF, Wrap text ON, Background transparent, border none, Missing data Show blank. Font size and colour as listed.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Page > Duplicate page on VCP; Ctrl+A (not nav/header) > Setup > Data source > `scanner_canslim`. Status, freshness, strength bar and ticker rules survive. Delete the 8-rule table; turn it into Letter details by swapping its columns.
- Remove `stop`, `target`, `trail`, `trend_score`, `contractions`, `depths` from the main table; add the letter columns.

## 5. Data gaps
- `m_qqq` reads "not verified" on all 240 rows (QQQ is not in the price cache). Shown as muted text, as the spec says.
- `m_market` and `m_spy` are identical on every row today; only `m_market` is shown.
- No row is BROKEN OUT today; 108 READY.
- `c_quarterly_eps` and `a_annual_eps` blank on 7 rows: amber dash; the matching `c_status` / `a_status` sentence says "not verified".
- `stop` and `target` blank on all rows (by design). `vcp_heuristic` (1-7) is on the tab but not in the spec; left off.

## 6. Build order
1. Duplicate VCP; title "CANSLIM".
2. Data source swap; rebuild main table columns; rules.
3. Market strip, cards, Letter details, Why this name.
4. Controls and grouping. Test: Qualify = soft shows the near misses; cards stay put.
