# Earnings strength heatmap: Looker design spec (Design Pro)

**Purpose.** A grid of the last eight quarters per ticker: green where EPS beat, red where it missed, grey when in line. Honest labels: the free feed has no revenue estimate, so there is no "double beat".

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Left | Right |
| --- | --- | --- | --- |
| 106 | 36 | Control bar: Quarters (date range, 244, w 260), Ticker (520), EPS result (736); feed status line x 1116 | |
| 158 | 32 | Caption line, full width | |
| 206 | 900 | Heatmap pivot (x 244, w 740) | Quarter detail table (x 1000, w 376) |

Canvas 1400 x 1140.

## 2. Elements (tab `earnings_heatmap`)

**Data source prep (once).** Resource > Manage added data sources > `earnings_heatmap` > Edit: set `quarter` Type to Date & Time > **Year Quarter** (shows 2026 Q3). This groups report dates into calendar quarters with no formula. Set `heat` to Number.

**Controls.** Quarters: Date range control, default Advanced: start Today minus 730 days, end Today (about eight quarters). Each chart: Setup > Date range dimension = `quarter`. Ticker: drop-down `ticker`, multi, Search ON. EPS result: drop-down `eps_flag` (beat / miss / inline), default all.

**Caption (y 158).** 11 pt muted: "Green = EPS beat, red = miss, grey = in line. Revenue is n/a in this free feed, so a double beat cannot be shown."

**Heatmap pivot (x 244, y 206, 740 x 900).** Pivot table: Row dimension `ticker`, Column dimension `quarter` (Year Quarter), Metric `heat` (Aggregation Max), label "EPS result". Sort rows `ticker` Ascending; columns `quarter` Ascending. Totals OFF. Cell size compact (Style > font 11 pt). Colour rules on `heat` (apply to the metric): = 1 fill #14532D; = 0 fill #283146; = -1 fill #7F1D1D; Is null font #D6A64A; font #E6EBF5. The spec scale goes to 2 but heat here is only -1/0/1. Missing data Show "-".

**Quarter detail (x 1000, y 206, 376 x 900).** Table: `ticker` Ticker, `quarter` Quarter, `label` Result (text, e.g. "eps beat, revenue n/a"). Sort `quarter` Descending. Rows 25. Rules on `label`: Contains beat font #22C55E; Contains miss font #EF4444; Contains inline #8B96AD; Equal to incomplete #D6A64A. Keep the label wording as it is.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Detail table: copy the Top stocks table, switch to `earnings_heatmap`, delete its rules.
- Pivot: style is new; apply the table colours by hand (pivot tables share the Table colours section). Sector macro scores and Heatmaps can copy this pivot later.

## 5. Data gaps
- `rev_flag` is blank on all 2,075 rows (no free revenue estimate), so every label says "revenue n/a". That is honest; no double beat.
- `quarter` is the report date (205 distinct dates), not a quarter label. The Year Quarter type fixes the columns; two reports in one calendar quarter would show the Max.
- No `sector` column on this tab, so no sector filter (blending is not allowed).
- 1 row is "incomplete" with blank `heat`.

## 6. Build order
1. Canvas 1400 x 1140; data source with `quarter` set to Year Quarter.
2. Pivot, rules. 3. Detail table. 4. Controls (set the date range dimension on both charts). Test: 8 quarter columns appear.
