# Historical P/E: Looker design spec (Design Pro)

**Purpose.** The median trailing P/E of the desk's own stocks over five years, with an honest MISSING label for the official S&P 500 P/E (no free official series).

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Left | Right |
| --- | --- | --- | --- |
| 106 | 36 | Control bar: Period (date range, 244, w 260); feed status line x 1116 | |
| 158 | 72 | Status panel: "Official S&P 500 P/E" + `official_status` (x 244, w 366) | Note box (x 626, w 750) |
| 246 | 420 | Median P/E line chart, full width | |
| 682 | 300 | Monthly table (date, median P/E, stocks in median), full width, 12 rows | |

Canvas 1400 x 1010.

## 2. Elements (tab `historical_pe`)

**Controls.** Period: Date range on `date`, default Advanced start Today minus 1825 days (5 years; the tab has 61 monthly points from 2021-10-29).

**Status panel.** Label "Official S&P 500 P/E" 11 pt muted; text-value box on `official_status` (reads MISSING), 18 pt bold #F59E0B.

**Note box.** Text-value box on `note`, 12 pt #8B96AD, wrap: "desk_median_trailing_pe is the median of this desk's stocks. official_sp500_pe is MISSING: no free official series." Add a static line above it, 13 pt #E6EBF5: "This is the desk's median trailing P/E, not the official S&P 500 P/E."

**Line chart.** Time series `date`, Metric `desk_median_trailing_pe` "Desk median trailing P/E" #7C9CFF (Average, 1 dec). Legend None (title names it). Missing data Linear interpolation. No line for `official_sp500_pe`. Title "Desk median trailing P/E, monthly". Looker tooltips show only the chart's metrics, so `n` goes in the table below instead of the tooltip.

**Monthly table.** Columns `date` Month end, `desk_median_trailing_pe` Median P/E (1), `n` Stocks in the median (0). Sort `date` Descending. Rows 12.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Line chart style (L).** Time series chart, Dimension `date` (type Date). Style > Series: weight 2, colours as listed, Missing data > Linear interpolation (or Line breaks), never Show as 0. Axes Roboto 11 pt #8B96AD; Grid > Axis and Gridline colour #1E293B; Chart background #121826, Border #1E293B, radius 8. Legend: None for one series (the title names it); for several series, Legend Top, Roboto 11 pt #8B96AD, or name the colours in the title. Title Roboto 13 pt bold #E6EBF5 on the chart (Style > Show title) or a text box above it.

**Text-value box (one-row table).** For a text field (company, reason, headline): Insert > Table, Dimension = the field, remove the metric (Record Count). Style: Table header OFF, Pagination OFF, Row numbers OFF, Wrap text ON, Background transparent, border none, Missing data Show blank. Font size and colour as listed.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Line chart: copy the XLY/XLP line chart, switch to `historical_pe`, keep one metric.
- Status panel: copy the AAII message panel (same MISSING look), shrink with Arrange > Make same size.

## 5. Data gaps
- `official_sp500_pe` blank on all 61 rows; `official_status` MISSING (while `data_status` is OK, so the feed status line stays empty: the status panel carries the message).
- The spec asks for `n` in a tooltip; Looker cannot add a non-plotted field to a tooltip, so `n` is in the table.

## 6. Build order
1. Canvas 1400 x 1010. 2. Status panel, note. 3. Line chart, table. Test: latest point 27.76 with n 463 (2026-10-23).
