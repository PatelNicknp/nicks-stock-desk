# Nick's Stock Desk: shared left navigation + header (Looker Design Pro)

Sample picture: `sample_nav_header.png` (generator: `mock/gen_nav_header.py`, shared parts in `mock/nav_common.py`).
Pages and groups come from LOOKER_SPEC.md "Left navigation" (8 groups, 42 pages).
All positions are canvas pixels on a 1600 px wide canvas. Set them in the panels, nudge with the arrow keys,
and line things up with Arrange > Align / Distribute / Make same size. Don't drag.

Theme (exact): report bg #0B0F17, panels #121826, text #E6EBF5, muted #8B96AD, grid/border #1E293B,
up #22C55E, down #EF4444, hold #F59E0B, accent #7C9CFF, Roboto, 24 px outer margin, 16 px card padding, radius 8.
Two extra nav tones were already used in the approved Top stocks sample. Keep them so every page matches:
item text #C3CBDB, counts #5B6680, selected pill fill #1A2236.

## Which nav: recommendation

**Recommended: "current group open".** Every page shows all 8 group labels, and only the group that page belongs to is open. Nick already approved this look in the Top stocks picture. It stays short (the longest version, Scanners, is about 600 px tall), and it works like any normal app menu.
Clicking a closed group label opens that group's first page, which shows the group opened, so it behaves like an accordion without any
hover or scripts.

How it is split, because a report-level element looks identical on every page:
- **Report-level (once):** rail rectangle, logo, brand name, divider line, research line, Updated chip.
- **8 "group blocks" (page-level):** each block holds the 8 group labels plus the open group's page links. The labels under the
  open group move down, so these can't be report-level. Build each block once, group it, and paste it onto every page of that group (8 builds, not 42).
- **Per page:** the selected pill, its accent bar and the blue item text.

Option B, "two-level" (4th rail in the picture): a fixed "Sections" list of the 8 groups is report-level, and the current group's pages are listed under a divider. It has more report-level parts and so less chance of misalignment, but it looks less familiar and adds a second highlight. Use it only if pasting the group blocks keeps drifting.
Not recommended: all 42 pages always open (about 1,250 px of menu, cluttered) or Looker's built-in nav (it can't be darkened).

Note: the approved Top stocks picture shows Scanners open as well. Under this spec only Overview is open on Top stocks.

## Steps, in priority order

1. **Hide Looker's own page list.** Theme and layout > Layout > Navigation type: **Hidden**. Same panel: Canvas size > Custom,
   width **1600** (the nav now lives inside the canvas, so 1400 would leave only 1132 px for content). Height 1000 for Today. Taller pages
   (long tables) override it in Page > Current page settings > Style > Canvas size.
2. **Report theme first.** Theme and layout > Theme > Customize: background #0B0F17, component background #121826, text #E6EBF5,
   border #1E293B, radius 8, font Roboto. Charts then start out dark.
3. **Rail rectangle.** Insert > Rectangle. Style: Background #121826 at 100%, Border colour #1E293B, weight 1, radius 0. Size and position:
   x 0, y 0, w 220, h = canvas height (1000 on Today, the full canvas height on taller pages). If the rectangle's own size boxes are missing, size it with Arrange > Make same size against a
   1600x1000 reference box and nudge with the arrow keys.
4. **Brand.** Insert > Rectangle x 20, y 20, w 22, h 22, fill #7C9CFF, radius 6, no border. Insert > Text "N" on it, 12 bold #0B0F17, centred.
   Insert > Text "Nick's Stock Desk" x 50, y 20, h 22, 15 bold #E6EBF5. Insert > Line x 12 to 207, y 60, colour #1E293B, weight 1.
5. **Make the frame report-level.** Select the rail rectangle, logo, "N", brand text and divider (Shift+click each) > right-click > **Make
   report-level**. They now sit on every page in the same place. Edit them once and every page updates.
6. **Group labels** (one text box each). Insert > Text, 11 bold, #8B96AD, ALL CAPS typed (Looker has no letter-spacing), h 31.
   Text starts with "▸ " (closed) or "▾ " (open): copy the arrow characters from this file, don't type them. Text box x 20, w 150.
   Count in its own text box, 11 regular #5B6680, right-aligned, right edge x 199 (x 179, w 20).
   Link each label to its group's first page: Overview > Today, Scanners > Growth, Earnings > Calendar, Sentiment > Put/call ratio,
   Financials > Summary, Macro > Macro screener, Technicals > 52-week breakouts, System > Data updates.
7. **Page items** (one text box per page in the open group). Insert > Text, 13 regular #C3CBDB, x 34, w 170, h 28, pitch 29 px.
   **Linking:** select the words in the text box > the link icon in the text toolbar > paste the page URL (View the page, copy the address bar:
   `https://lookerstudio.google.com/reporting/<report id>/page/<page id>`). Paste with Ctrl+V. Typing drops characters, so never type URLs.
   Leave "open in new tab" off. If the link turns blue or underlined, select it, set the colour back to #C3CBDB and switch off the U (underline) button.
   Alternative: Insert > Button > Setup > Button action: Navigation > Static link (paste the same URL; if your version offers "Page
   navigation" with a page list, pick the page instead). Style: Background #121826, opacity 100%, border weight 0, radius 6, font 13 #C3CBDB Roboto.
   Button text is always centred, so text boxes match the picture better.
8. **Exact vertical positions (Overview open, e.g. Today):** Overview label y 70; items Today 102, Top stocks 131, Stock scorecard 160,
   Watchlist and portfolio 189, Alerts 218, Backtest 247; then Scanners 276, Earnings 307, Sentiment 338, Financials 369, Macro 400,
   Technicals 431, System 462. Rule for every block: first label at y 70, label height 31, item pitch 29, and the next label sits
   directly under the last item. Equal spacing check: select the items > Arrange > Distribute vertically.
9. **Build the 8 group blocks.** On the first page of a group, select all its labels, counts and item boxes > right-click > Group.
   Copy (Ctrl+C), open each other page in that group, Paste (Ctrl+V). Looker pastes in the same place. Check x 20 / y 70 on the first label.
10. **Selected state, per page (page-level, not report-level):** Insert > Rectangle x 12, y = the item's y, w 195, h 28, fill #1A2236,
    radius 6, no border. Insert > Rectangle x 12, same y, w 3, h 28, fill #7C9CFF, radius 0 (accent bar). Change that page's own item text
    to bold #7C9CFF. Order: select the pill > Arrange > Bring to front, then the bar > Bring to front, then the item text > Bring to front
    (otherwise the report-level rail can cover it).
11. **Hover: not possible.** Looker has no hover styling for text, rectangles or buttons. Viewers only see the hand cursor over links.
    Don't try to fake it. The selected pill is the only state.
12. **Shared header.**
    - Title: page-level text box (the words change per page), x 244, y 24, w 720, h 36, 32 bold #E6EBF5.
    - Research line: report-level text box, x 244, y 66, w 1000, h 20, 14 regular #8B96AD, one line:
      "Research only. Not a recommendation to buy or sell. This desk never places trades. Stocks only, no option contracts."
      This removes the big gap under the title that's in the current Today page.
    - Updated chip, report-level, right edge at x 1576: Rectangle x 1399, y 28, w 177, h 30, fill #121826, border #1E293B 1 px, radius 6.
      Text "Updated" 12 #8B96AD at x 1411. Value: data source `market_today`, Add a field `updated_label` =
      `FORMAT_DATETIME("%b %e, %I:%M %p PT", PARSE_DATETIME("%Y-%m-%d %H:%M", SUBSTR(updated_pt, 1, 16)))`
      (shows "Oct 23, 07:24 PM PT"; if the formula errors, use `updated_pt` as it is). Show it with the **text cell** recipe below, 12 #E6EBF5.
    - Filters (only pages that need them): one row at y 106, h 36, w 220 each, 16 px gaps, starting x 244, most important first
      (Ticker first when the page has a ticker column). Add a control > Drop-down list. Setup: control field, Search on.
      Style: background #121826, border #1E293B, radius 6, font 13 #E6EBF5, label renamed to plain words. Filters are page-level.
    - Content starts at y 158 with a filter row, y 110 without.
13. **Text cell recipe** (Looker scorecards can't show text): Insert > Table, dimension = the text field, no metric, Rows per page 1.
    Style: Show header off, pagination off, row numbers off, background #121826 (or the card's colour), cell borders the same as the
    background, font size as needed, colour #E6EBF5. Use it for the Updated value, put/call zone and any "n/a" text.
14. **On/off switches.** Looker can't show or hide a panel with a toggle. Feature switches stay in the sheet's `settings` tab, listed on the
    Data updates page. When a feature is off, its panel shows a muted one-liner (12 #8B96AD) "Turned off in Settings" instead of zeros.
    This works the same way as the `data_status` MISSING note. No "Open in TradingView" buttons, and alerts are never pop-ups. They live in tables.

## Build order
1. Theme and layout: Navigation Hidden, canvas 1600 wide, theme colours.
2. Rail, logo, brand and divider, then Make report-level.
3. Research line and Updated chip (report-level).
4. Overview block on Today (labels, counts, links), then Group, then paste on the other 5 Overview pages.
5. Repeat the block for the other 7 groups (Scanners, Earnings, Sentiment, Financials, Macro, Technicals, System).
6. On each of the 42 pages: title text and selected pill + bar + blue text, then Bring to front.
7. Filter rows on pages that need them. Click through every link in View mode once.
