# Breadth: Looker design spec (Design Pro)

**Purpose.** How much of the desk is in good shape: the share of stocks above their 20, 50, 100 and 200-day averages over the last six months, with today's reading of each.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Period (date range, 244, w 260); feed status line x 1116 |
| 158 | 96 | 4 cards of 271: Above 20-day, Above 50-day (with week-ago comparison), Above 100-day, Above 200-day |
| 270 | 460 | Breadth line chart, full width |
| 746 | 32 | Caption |

Canvas 1400 x 820.

## 2. Elements

**Controls.** Period: Date range on `date` (tab `breadth_history`), default Last 6 months (Advanced: Today minus 182 days). Group it with the chart only.

**Cards (tab `market_today`, one row = today's reading).** `breadth_sma20` "% above 20-day", `breadth_sma50` "% above 50-day", `breadth_sma100` "% above 100-day", `breadth_sma200` "% above 200-day", Aggregation Max, 1 dec. On the 50-day card add a small second scorecard under the value: `breadth_sma50_week_ago` labelled "a week ago" (12 pt muted). Scorecards cannot pick the latest row of `breadth_history`, and `market_today` already holds it.

**Line chart (tab `breadth_history`).** Time series `date`; Metrics `pct_above_sma20` "Above 20-day" #7C9CFF, `pct_above_sma50` "Above 50-day" #22C55E, `pct_above_sma100` "Above 100-day" #F59E0B, `pct_above_sma200` "Above 200-day" #E6EBF5 (Average). Style > Left Y-axis: Min 0, Max 100. Reference line: Constant 50, colour #8B96AD, dotted, label "Half". Missing data **Line breaks** (a blank point is a session without enough prices; leave the gap). Legend Top. Title "% of desk stocks above each average".

**Caption.** "A blank point is a session that did not have enough prices. The gap is left open, never drawn as zero."

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Line chart style (L).** Time series chart, Dimension `date` (type Date). Style > Series: weight 2, colours as listed, Missing data > Linear interpolation (or Line breaks), never Show as 0. Axes Roboto 11 pt #8B96AD; Grid > Axis and Gridline colour #1E293B; Chart background #121826, Border #1E293B, radius 8. Legend: None for one series (the title names it); for several series, Legend Top, Roboto 11 pt #8B96AD, or name the colours in the title. Title Roboto 13 pt bold #E6EBF5 on the chart (Style > Show title) or a text box above it.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Chart: copy the Today page's breadth line if it is built (same tab and four series), or the Backtest line chart; set the Y-axis to 0-100.
- Cards: copy the Today page breadth card (it already uses `market_today`), then copy three more.

## 5. Data gaps
- `breadth_history` has no blanks today (140 sessions from 2026-04-07); the Line breaks setting is there for later runs.
- The latest-point cards come from `market_today` (one row), because `breadth_history` has no "latest" flag. Both are written by the same run.

## 6. Build order
1. Canvas 1400 x 820. 2. Cards from `market_today`. 3. Chart, caption. Test: today 68.2 / 57.9 (44.7 a week ago) / 51.5 / 58.0.
