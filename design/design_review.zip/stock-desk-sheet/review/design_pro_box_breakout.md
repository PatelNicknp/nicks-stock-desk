# Box breakout: Looker design spec (Design Pro)

**Purpose.** Tight sideways ranges (15-40 days, at most 10% wide) that are ready to break, or closed out of the top today on volume. Buy point is the range high, stop the range low, target the range high plus its height.

No sample picture (same look as `sample_vcp.png`).

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Status (244), Index (460), Sector (676), Ticker (892); feed status line x 1116 |
| 158 | 96 | 3 count cards of 366: Broken out today, Ready, Watching |
| 270 | 520 | Box table, full width, 14 rows |
| 806 | 220 | Why this name (detail), full width |
| 1042 | 48 | Rule line (`note`) |

Canvas 1400 x 1120.

## 2. Elements (tab `scanner_box`)

**Controls.** Status: `status`, multi, default READY + BROKEN OUT today (grouped with the table and detail). Index `index_membership`. Sector `sector`. Ticker `ticker`.

**Count cards.** Record Count: BROKEN OUT today (2 today), READY (36), WATCHING (97).

**Box table (y 270).** Columns: `ticker` Ticker, `company` Company, `index_membership` Index, `status` Status, `price` Price (2), `pivot` Buy point (range high) (2), `stop` Stop (range low) (2), `target` Target (2), `strength` Strength (bar), `range_days` Range days (0), `range_width_pct` Range width % (1), `volume_ratio` Volume vs 50-day (2, shows 1.55 = 1.55x), `freshness` Data. Sort `strength` Descending. Rows 14. Cross-filtering ON. Colours: setup words (6), ticker (1), stop red / target green Is-not-null font rules (2), `volume_ratio` >= 1.5 font #22C55E bold (1) = 10.

**Why this name (y 806).** Table `ticker`, `reason` (wrap ON), Rows 3, sort `strength` Descending. Caption "Click a row to read why it is on the list."

**Rule line (y 1042).** Text-value box on `note`, 11 pt muted: "Desk rule, not the Pine script: a 15 to 40 day range no wider than 10% whose first and last closes drift by 5% or less, then a close through the range high on volume above 1.5 times the 50-day average."

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Setup words (pattern scanners).** `status` font, bold, Apply to Status column: Equal to BROKEN OUT today #22C55E; READY #F59E0B; WATCHING #8B96AD. `freshness` font: FRESH #8B96AD; PARTIAL #F59E0B; STALE #EF4444. Strength as a calm data bar: Style > the Strength column > Bar (Show number ON), bar colour #7C9CFF, 0 decimals.

**Click-to-read detail panel.** Main table: Setup > Chart interactions > Cross-filtering ON. The detail table (same tab) then shows the clicked row; with nothing clicked it shows the top rows by the same sort. Detail table: Dimensions `ticker` + the long text fields, Style > General > Horizontal OFF, Wrap text ON, Rows 3, header ON (11 pt muted). Caption above it: "Click a row in the table to read its full reason." 

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Text-value box (one-row table).** For a text field (company, reason, headline): Insert > Table, Dimension = the field, remove the metric (Record Count). Style: Table header OFF, Pagination OFF, Row numbers OFF, Wrap text ON, Background transparent, border none, Missing data Show blank. Font size and colour as listed.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Page > Duplicate page on VCP; swap data source to `scanner_box`; delete the 8-rule table and the In a trade control/card; widen Why this name to full width (Arrange > Make same size against the main table, width only).
- Then duplicate this page for Flag breakout (same shape, four different columns).

## 5. Data gaps
- All spec columns exist. `company` and `price` are added (real columns).
- One row is STALE (`price_as_of` 2026-10-22); the freshness rule shows it red.

## 6. Build order
1. Duplicate VCP; title "Box breakout".
2. Swap source, columns, rules; remove VCP-only parts.
3. Cards (3), detail, rule line. Test: default shows 38 rows, TECH first (highest strength); MSI and FTV show green status.
