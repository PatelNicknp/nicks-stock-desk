# Trends: Looker design spec (Design Pro)

**Purpose.** Which stocks are in an uptrend (above all four moving averages), a downtrend (below all four) or mixed, with the four above/below flags.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Trend chips (fixed-size list, 244, w 420), Sector (680), Ticker (896); feed status line x 1116 |
| 158 | 96 | 3 cards of 366: Uptrend, Mixed, Downtrend |
| 270 | 880 | Trends table, full width, 25 rows |
| 1166 | 32 | Caption |

Canvas 1400 x 1230.

## 2. Elements (tab `trends`)

**Controls.** Trend chips: Fixed-size list control on `trend_label`, Style > horizontal layout (three chips: Uptrend, Mixed, Downtrend), default Uptrend only. Group it with the table (cards keep the full split). Sector: drop-down. Ticker: drop-down, Search ON.

**Cards.** Record Count, filters `trend_label` = Uptrend (210) / Mixed (206) / Downtrend (107). Value font: Uptrend #22C55E, Mixed #8B96AD, Downtrend #EF4444.

**Trends table.** Columns: `ticker` Ticker, `company` Company, `trend_label` Trend, `sma_alignment` Moving averages (11 pt muted, e.g. "above 20, above 50, below 100, above 200"), `above_sma20` Above 20d, `above_sma50` Above 50d, `above_sma100` Above 100d, `above_sma200` Above 200d, `price` Price (2), `score` Score. Sort `score` Descending. Rows 25. Rules: flags 1/0/null on four columns (12), `trend_label` Uptrend #22C55E / Downtrend #EF4444 / Mixed #8B96AD (3), ticker (1) = 16. Score stays plain (rule budget); or drop the ticker rule and add score bands only if staying at or under 20 (16 - 1 + 5 = 20).

**Caption.** "Uptrend means the price is above all four averages. Downtrend means it is below all four."

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**1 / 0 flags (text).** Per flag column: Equal to 1 font #22C55E bold; Equal to 0 font #EF4444; Is null font #D6A64A. (On the Heatmaps page use fills instead: 1 fill #14532D, 0 fill #7F1D1D.)

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Total score bands (`score`, desk range -6 to 13).** Single colour rules, Apply to = Score column, font #E6EBF5 bold: >= 12 fill #166534; between 9 and 11 fill #14532D; between 5 and 8 fill #283146; between 1 and 4 fill #7F1D1D; <= 0 fill #B91C1C. Same bands as Top stocks, so copying a Top stocks table brings them along.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Table: copy the Top stocks table, switch to `trends`, keep score bands, delete verdict and Day % rules, add flag rules. Heatmaps copies this table next (same four flags).
- Cards: copy from Growth.

## 5. Data gaps
- `trend_label` is Uptrend / Mixed / Downtrend (no "Sideways" here, unlike `timing` on other tabs).
- `above_sma100` blank on 2 rows, `above_sma200` on 3 (short history): amber dash.

## 6. Build order
1. Canvas 1400 x 1230. 2. Table (copied), rules. 3. Cards, caption. 4. Fixed-size list default Uptrend; test Downtrend shows 107.
