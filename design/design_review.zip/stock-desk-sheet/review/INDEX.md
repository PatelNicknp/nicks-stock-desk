# Nick's Stock Desk: design files index (Looker Design Pro)

One design file per page in `review/`. Build in nav order. Every file is self-contained (layout, elements with real column names, menu paths, colours, copy-paste tips, data gaps, build order).

Shared frame: `design_pro_nav_header.md` (left nav + header, sample `sample_nav_header.png`). Build it first, then Top stocks, then the rest: most pages copy a styled table from Top stocks.

**Canvas width note.** These page files give positions on a 1400-wide canvas (as briefed). The nav/header file recommends a 1600-wide canvas. If 1600 is used, every page file's Canvas grid section says how to convert (widen full-width items by 200 px). The sample pictures are 1600 wide like the approved Top stocks sample.

**Percent note.** Columns ending `_pct` already hold percent units (-1.08 means -1.08%). Keep them as Number with % in the column label. Switching them to Looker's Percent type would show -108%.

**n/a note.** Looker cannot print custom text for blank cells. Every page uses Missing data > Show "-" plus an amber (#D6A64A) Is-null rule, so blanks read as an amber dash, never 0.

| Group | Page | Design file | Status | Sample picture |
| --- | --- | --- | --- | --- |
| Overview | Today | `design_pro_today.md` | ready | `sample_today_polished.png` |
| Overview | Top stocks | `design_pro_top_stocks.md` | ready | `sample_top_stocks_polished.png` |
| Overview | Stock scorecard | `design_pro_stock_scorecard.md` | ready | `sample_stock_scorecard.png` |
| Overview | Watchlist and portfolio | `design_pro_watchlist_and_portfolio.md` | ready | `sample_watchlist_and_portfolio.png` |
| Overview | Alerts | `design_pro_alerts.md` | ready | none |
| Overview | Backtest | `design_pro_backtest.md` | ready | `sample_backtest.png` |
| Scanners | Growth | `design_pro_growth.md` | ready | none |
| Scanners | Quality | `design_pro_quality.md` | ready | none |
| Scanners | Dividend | `design_pro_dividend.md` | ready | none |
| Scanners | Wheel (stocks only) | `design_pro_wheel.md` | ready | none |
| Scanners | VCP | `design_pro_vcp.md` | ready | `sample_vcp.png` |
| Scanners | CANSLIM | `design_pro_canslim.md` | ready | none |
| Scanners | Box breakout | `design_pro_box_breakout.md` | ready | none |
| Scanners | Flag breakout | `design_pro_flag_breakout.md` | ready | none |
| Scanners | Leaders | `design_pro_leaders.md` | ready | none |
| Earnings | Calendar | `design_pro_earnings_calendar.md` | ready | none |
| Earnings | Strength heatmap | `design_pro_earnings_strength_heatmap.md` | ready | none |
| Earnings | Report cards | `design_pro_earnings_report_cards.md` | ready | none |
| Sentiment | Put/call ratio | `design_pro_put_call_ratio.md` | ready | none |
| Sentiment | Put and call walls | `design_pro_put_and_call_walls.md` | ready | none |
| Sentiment | Analyst ratings | `design_pro_analyst_ratings.md` | ready | none |
| Sentiment | 13F tracker | `design_pro_13f_tracker.md` | ready | none |
| Sentiment | AAII | `design_pro_aaii.md` | ready | none |
| Sentiment | Insider trading | `design_pro_insider_trading.md` | ready | none |
| Sentiment | Headline sentiment | `design_pro_headline_sentiment.md` | ready | none |
| Sentiment | XLY/XLP | `design_pro_xly_xlp.md` | ready | none |
| Financials | Summary | `design_pro_financials_summary.md` | ready | none |
| Financials | Earnings tracker | `design_pro_earnings_tracker.md` | ready | none |
| Financials | Company financials | `design_pro_company_financials.md` | ready | none |
| Financials | Dividend fundamentals | `design_pro_dividend_fundamentals.md` | ready | none |
| Macro | Macro screener | `design_pro_macro_screener.md` | ready | none |
| Macro | Sector macro scores | `design_pro_sector_macro_scores.md` | ready | none |
| Macro | Historical P/E | `design_pro_historical_pe.md` | ready | none |
| Technicals | 52-week breakouts | `design_pro_52_week_breakouts.md` | ready | none |
| Technicals | Trends | `design_pro_trends.md` | ready | none |
| Technicals | Pullbacks | `design_pro_pullbacks.md` | ready | none |
| Technicals | Gainers and losers | `design_pro_gainers_and_losers.md` | ready | none |
| Technicals | Breadth | `design_pro_breadth.md` | ready | none |
| Technicals | Sector performance | `design_pro_sector_performance.md` | ready | none |
| Technicals | Heatmaps | `design_pro_heatmaps.md` | ready | none |
| System | Data updates | `design_pro_data_updates.md` | ready | none |
| System | Help | `design_pro_help.md` | ready | none |
| Frame | Nav and header | `design_pro_nav_header.md` | ready | `sample_nav_header.png` |

Sample generators: `mock/` (`common.py` reuses the Top stocks CSS and `nav_common.py`; one `sample_*.py` per picture, data read from the GitHub CSVs). Re-run with `python3 mock/sample_<name>.py` from `review/mock`.

Progress: all three batches done (Batch A Overview, Batch B Scanners, Batch C Earnings / Sentiment / Financials / Macro / Technicals / System).

## Data gaps found (from the GitHub CSV headers and rows, Oct 23 2026 7:24 PM PT export)

Missing or always-blank columns:
- `roe`, `de`, `pts_roe`, `pts_de` (scores, scanner_quality) and `ind_roe`, `ind_de`, `pts_roe_ind`, `pts_de_ind`, `roe_avg`, `de_avg` (scores): blank on all 523 rows. Quality scanner passes nobody; its `data_status` still says OK.
- `analyst_ratings.upside_pct`: blank on all rows (left off the page).
- `portfolio.score_week_ago`, `score_week_change`: blank on all rows (no week-ago memory yet).
- `company_financials.pe`, `ps`, `pfcf`; `earnings_tracker.result`; `earnings_heatmap.rev_flag`; `historical_pe.official_sp500_pe`; AAII counts: blank on all rows (the last three by design).
- `prices.sma20` blank in about 31% of rows and `sma50` in about 67%: the scorecard chart needs interpolation.
- Columns the spec mentions that are not in any CSV: no single "entry zone" column (it is `entry_low` + `entry_high`), no `day_change` (uses `day_pct`), no bucket order column for backtest buckets, no "nearest expiry" flag for option walls, no absolute score-change column (a small `ABS(score_change)` sort field is needed), no latest-row flag for time-series tabs.
- `backtest_equity` does not start at 10,000 (first row 8,890.14 for the top 20).
- No Freshness page in the nav although the Dividend fundamentals section refers to one; the `freshness` tab is placed on Data updates.

Values to check in the Sheet (Google Sheets may convert them when the script writes text with setValues):
- `scanner_vcp.trend_score` (8/8 can become a date), `backtest_buckets.bucket` (1-3, 4-5... can become dates), `score_details.points_label` (+1 can become 1).

Data quality notes:
- Sector names mix two naming sets (Information Technology / Technology, Financials / Financial Services, Consumer Discretionary / Consumer Cyclical, Consumer Staples / Consumer Defensive): 15 sector values instead of 11, with one-stock sectors on Sector performance.
- `news` and `headline_sentiment` cover only 34 focus tickers; `option_walls` likewise.
- No row is BROKEN OUT today on VCP, CANSLIM or Leaders (Box has 2, Flag has 2).
