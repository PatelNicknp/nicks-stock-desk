# Wheel candidates (stocks only): Looker design spec (Design Pro)

**Purpose.** Liquid stocks in an uptrend that are not extended: a stock screen only. No strike, no expiry, no premium, no contract symbol anywhere on the page.

Page title text: **Wheel candidates (stocks only)**. No sample picture (same look as `sample_vcp.png`).

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Passes screen (244), Sector (460), Trend (676), Ticker (892); feed status line x 1116 |
| 158 | 32 | Stocks-only line, full width (muted text) |
| 206 | 96 | 4 count cards of 271 |
| 318 | 880 | Scanner table, full width, 25 rows |

Canvas 1400 x 1240.

## 2. Elements (tab `scanner_wheel`)

**Controls.** Passes screen: `passes`, Single select, default `yes`, grouped with the table. Sector: `sector`. Trend: `timing`, multi, default all. Ticker: `ticker`, Search ON.

**Stocks-only line (y 158).** Static text, 12 pt #8B96AD: "Stock screen only. This is not an option contract. No strikes, expiries or premiums are shown or suggested." (It repeats the `why` text once, so `why` is not a column.)

**Count cards (y 206).** "Passing the screen" Record Count, `passes` = yes (92 today). "Of those, BUY". "Average RSI-14, passing" `rsi14` Average, 1 dec. "Median daily dollar volume, passing" `dollar_volume` Median, Compact numbers ON, Currency USD (shows like $469M).

**Scanner table (y 318).** Columns: `ticker` Ticker, `company` Company, `sector` Sector, `price` Price (2), `score` Score, `verdict` Verdict, `timing` Trend, `rsi14` RSI-14 (1), `above_sma200` Above 200-day, `dollar_volume` Daily dollar volume (Currency USD, Compact numbers ON). Sort `score` Descending, then `dollar_volume` Descending. Rows 25. Colours: score bands (5), verdict (3), ticker (1), `timing` font Uptrend #22C55E / Downtrend #EF4444 / Extended #F59E0B / Sideways #8B96AD (4), `above_sma200` = 1 font #22C55E, = 0 font #EF4444, Is null amber (3) = 16. `rsi14` plain #E6EBF5.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Total score bands (`score`, desk range -6 to 13).** Single colour rules, Apply to = Score column, font #E6EBF5 bold: >= 12 fill #166534; between 9 and 11 fill #14532D; between 5 and 8 fill #283146; between 1 and 4 fill #7F1D1D; <= 0 fill #B91C1C. Same bands as Top stocks, so copying a Top stocks table brings them along.

**Verdict text.** Rules on `verdict`, Apply to = Verdict column, bold, no fill: Equal to BUY font #22C55E; HOLD font #F59E0B; AVOID font #EF4444.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Page > Duplicate page on Growth; Ctrl+A (not nav/header) > Setup > Data source > `scanner_wheel`; swap the growth columns for timing, rsi14, above_sma200, dollar_volume.
- Trend colour rules: copy them from the Top stocks table (it already colours Uptrend / Downtrend / Extended / Sideways) by starting from that table instead of Growth's if easier.
- Change the page title text only; the nav item already reads "Wheel (stocks only)".

## 5. Data gaps
- `timing` has seven values (Downtrend, Sideways, Uptrend, Extended, In entry zone, Breakout, Pullback). Colour the four listed; In entry zone, Breakout and Pullback stay #E6EBF5 (or give In entry zone #7C9CFF if Nick wants it to stand out: 1 more rule).
- `above_sma200` is 1/0 (blank on 3 rows). Looker cannot show Yes/No without a calculated field; 1 and 0 in green/red read clearly.
- `why` has two fixed sentences; shown once as the stocks-only line.

## 6. Build order
1. Duplicate Growth; canvas 1400 x 1240; title "Wheel candidates (stocks only)".
2. Swap data source and columns; rules.
3. Stocks-only line, cards. Test: Passes = no changes only the table (cards stay at 92); Trend = Uptrend narrows table and cards together.
