# Financials summary: Looker design spec (Design Pro)

**Purpose.** For one stock, each valuation and quality metric now versus its own 3-year average and versus the sector median, with a point for each comparison.

No sample picture (the same rows appear in `sample_stock_scorecard.png`, Score breakdown).

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Ticker (244), Metric (460); feed status line x 1116 |
| 158 | 80 | Stock line: ticker 24 pt + sector (text-value boxes), full-width panel |
| 254 | 420 | Metrics table, full width, 9 rows |
| 690 | 40 | Caption (verbatim) |

Canvas 1400 x 780.

## 2. Elements (tab `financials_summary`)

**Controls.** Ticker: drop-down `ticker`, Single select, Search ON, default ADSK (or make it the report-level Ticker control from Stock scorecard so the pick carries over). Metric: drop-down `metric`, multi, default all.

**Stock line.** Text-value boxes on `ticker` (24 pt bold #7C9CFF) and `sector` (13 pt muted).

**Metrics table.** Columns: `metric` Metric, `direction` Better when, `now_value` Now (2), `avg_3y` Own 3-yr avg (2), `pts_vs_self` Points vs own history, `industry_median` Sector median (2), `pts_vs_industry` Points vs sector. Sort `metric` Ascending. Rows 10, pagination OFF. Rules: point rules on both point columns (12), `direction` lower / higher font #8B96AD (none needed), null amber on `now_value`, `avg_3y`, `industry_median` (3) = 15.

**Caption (verbatim).** "Direction says whether a lower or a higher number earns the point. The industry median needs four peers."

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Point colours (-2..+2), per point column.** Style > Conditional formatting > Add > Single colour, Apply to = that column only (not entire row): = 2 fill #166534; = 1 fill #14532D; = 0 fill #283146; = -1 fill #7F1D1D; = -2 fill #B91C1C; all with font #E6EBF5 bold; plus Is null > font #D6A64A, no fill. Centre the column if Style offers alignment. Looker allows 20 rules per chart: if a table has more than three point columns, use one Colour scale rule per column instead (Colour type > Colour scale, Min -2 #B91C1C, Mid 0 #283146, Max 2 #166534), or a "Select any field" rule set when every coloured column is a point column.

**Text-value box (one-row table).** For a text field (company, reason, headline): Insert > Table, Dimension = the field, remove the metric (Record Count). Style: Table header OFF, Pagination OFF, Row numbers OFF, Wrap text ON, Background transparent, border none, Missing data Show blank. Font size and colour as listed.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Table: copy the Stock scorecard Score breakdown table, switch to `financials_summary`, swap columns; its point rules move to `pts_vs_self` (re-pick the field) and add six for `pts_vs_industry`.
- Ticker control: copy the report-level one (it is already on the page if it was made report-level).

## 5. Data gaps
- `Debt / equity` and `Return on equity %` rows have blank values and points for every stock (no feed): amber dashes.
- Blank rates: `now_value` 1,636 of 4,707 rows, `avg_3y` 1,709, `pts_vs_self` 1,786, `industry_median` 1,096, `pts_vs_industry` 1,674.
- `direction` values are "lower" / "higher"; the label "Better when" makes them read naturally.

## 6. Build order
1. Canvas 1400 x 780. 2. Ticker control. 3. Stock line, table, caption. Test: ADSK shows 9 metrics, 2 all-dash rows.
