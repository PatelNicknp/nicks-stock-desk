# Alerts: Looker design spec (Design Pro)

**Purpose.** A calm list of what changed since the previous run (score moves, verdict changes, breakouts, entry-zone arrivals). A research list only: nothing pops up, nothing is emailed, nothing goes to a broker.

No sample picture for this page (layout reuses the Top stocks table look).

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Alert type, Verdict now, Ticker |
| 150 | 28 | Caption (verbatim, below) |
| 186 | 96 | 4 count cards of 271: Changes this run, Verdict changes, Breakouts, Entry-zone arrivals |
| 298 | 440 | Alerts table, full width (rows 12) |
| 762 | 28 | Section title "Score changes" |
| 798 | 440 | Score changes table, full width (rows 12) |

Canvas 1400 x 1300.

## 2. Elements

**Feed status line.** Right end of the control bar (x 1116, y 112, w 260, h 24): one-row table on `note` from `alerts`, filter `data_status` = MISSING (recipe in Styling). Empty on a normal day.

**Controls (y 106).** Alert type: drop-down `kind` (tab `alerts`), multi-select, default all. Verdict now: drop-down `verdict` (tab `alerts`), default all. Ticker: drop-down `ticker` (tab `alerts`), Search ON. Score change: Slider on `score_change` (tab `score_changes`), full range by default, x 892. Group the first three with the alerts cards and table, and the slider with the Score changes table (Arrange > Group).

**Caption (y 150).** Text, 11 pt #8B96AD, verbatim: "These are changes since the previous run. Nothing is emailed and nothing is sent to a broker."

**Count cards (y 186), tab `alerts`.** Scorecards, Metric Record Count, each with a chart filter. All four exclude `kind` Equal to info, so a lone "no changes yet" row is not counted:
- "Changes this run": filter Exclude `kind` = info.
- "Verdict changes": Include `kind` = verdict_change.
- "Breakouts": Include `kind` = breakout.
- "Entry-zone arrivals": Include `kind` = entry_zone.
Value 24 pt #E6EBF5 (no colour: counts are neutral).

**Alerts table (y 298).** Tab `alerts`. Columns: `ticker` Ticker, `kind` Type, `text` What changed (wrap ON, widest column ~420 px), `score` Score, `score_prev` Score before, `verdict` Verdict, `verdict_prev` Verdict before, `price` Price (2 dec). Sort `score` Descending. Rows 12. Colours: ticker accent; score bands on `score` only (`score_prev` plain #8B96AD so the eye goes to today); verdict rules on `verdict` only; `verdict_prev` stays plain #8B96AD (colouring both is too busy). `kind` font: breakout #22C55E, entry_zone #7C9CFF, verdict_change #F59E0B, score_jump and score_cross #E6EBF5. The `info` row, when it is the only row, reads "no changes yet" in `text`: give it rule `kind` = info > Entire row font #8B96AD.

**Score changes table (y 798).** Tab `score_changes`. Columns: `ticker` Ticker, `company` Company, `score` Score, `score_prev` Score before, `score_change` Change, `verdict` Verdict, `day_pct` Day %, `price` Price. Sort by absolute change: add a chart-level calculated field in Setup > Sort > Add field > Create field, name "Change size", formula `ABS(score_change)`, Descending (type it slowly and check it reads exactly ABS(score_change)). Rows 12. Colours: return rules on `score_change` (a drop is red) and `day_pct`; score bands on `score`; verdict; ticker accent. 0 decimals on scores (values arrive as 8.0).

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Total score bands (`score`, desk range -6 to 13).** Single colour rules, Apply to = Score column, font #E6EBF5 bold: >= 12 fill #166534; between 9 and 11 fill #14532D; between 5 and 8 fill #283146; between 1 and 4 fill #7F1D1D; <= 0 fill #B91C1C. Same bands as Top stocks, so copying a Top stocks table brings them along.

**Return colours (text, not fill).** Per return column: > 0 font #22C55E; < 0 font #EF4444; = 0 leaves #E6EBF5; Is null > font #D6A64A. Apply to that column only.

**Verdict text.** Rules on `verdict`, Apply to = Verdict column, bold, no fill: Equal to BUY font #22C55E; HOLD font #F59E0B; AVOID font #EF4444.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Alerts table: copy the Top stocks table, change the data source to `alerts`; score, verdict and ticker rules survive.
- Score changes table: copy the finished Alerts table, switch to `score_changes`, add `score_change` and `day_pct`. Copy the Day % rule pair onto Change.
- Count cards: style one, copy three, change only the chart filter. Arrange > Distribute horizontally.

## 5. Data gaps
- `kind` values are code words (score_jump, verdict_change, score_cross, entry_zone, breakout). Looker cannot relabel values without a calculated field. Optional, if Nick wants plain words: data source calculated field "Alert type" = `CASE kind WHEN "score_jump" THEN "Score jump" WHEN "verdict_change" THEN "Verdict change" WHEN "score_cross" THEN "Crossed a line" WHEN "entry_zone" THEN "In entry zone" WHEN "breakout" THEN "Breakout" ELSE kind END`. Long to type: skip it unless typing is reliable that day.
- No `info` row in today's file (198 real alerts), so the "no changes yet" case cannot be checked today.
- No absolute-change column in `score_changes`; the one small calculated sort field above is needed.
- `score_changes.score`, `score_prev`, `score_change` arrive as decimals (8.0); set 0 decimals.

## 6. Build order
1. Canvas 1400 x 1300, shared header, caption.
2. Data sources `alerts`, `score_changes`.
3. Alerts table (copied from Top stocks), then the count cards.
4. Score changes table (copied from Alerts), sort field.
5. Controls, then Arrange > Group with their charts.
