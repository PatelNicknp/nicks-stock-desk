# Heatmaps: Looker design spec (Design Pro)

**Purpose.** One row per stock with 1-day, 1-week, 1-month and year-to-date returns as a colour grid, plus the four above-average flags. This is a heatmap page, so returns use fills.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Left | Right |
| --- | --- | --- | --- |
| 106 | 36 | Control bar: Sector (244), Ticker (460), Above 200-day (676); feed status line x 1116 | |
| 158 | 880 | Heatmap table (x 244, w 800), 25 rows | Sector average pivot (x 1060, w 316) |
| 1054 | 32 | Caption | |

Canvas 1400 x 1110.

## 2. Elements (tab `heatmaps`)

**Controls.** Sector: drop-down `sector`, default all (spec). Ticker: drop-down. Above 200-day: drop-down `above_sma200` (1 / 0), default all.

**Heatmap table (x 244).** Columns: `ticker` Ticker, `company` Company, `ret_1d` 1 day %, `ret_1w` 1 week %, `ret_1m` 1 month %, `ret_ytd` YTD % (all 1 dec, centred, w 72), `above_sma20` 20d, `above_sma50` 50d, `above_sma100` 100d, `above_sma200` 200d (w 44). Sort `ret_1d` Descending. Rows 25. Colours: one Colour scale rule per return column (4): Min -5 #B91C1C, Mid 0 #283146, Max 5 #166534 for 1 day and 1 week; Min -15 / Max 15 for 1 month; Min -40 / Max 40 for YTD (wider ranges so the grid is not all saturated); font #E6EBF5. Flags: "1 / 0" fills (1 fill #14532D, 0 fill #7F1D1D, null amber) x 4 = 12. Ticker (1). Total 17.

**Sector average pivot (x 1060).** Pivot table: Row dimension `sector`, Metric `ret_1d` Average (2 dec), Sort metric Descending. Same colour scale as 1 day. Title, exactly: "Average of the stocks above, 1 day %" so it is not mistaken for the sector ETF.

**Caption.** "Each cell is that stock's own return. The sector column on the right is the plain average of the desk's stocks, not the ETF."

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**1 / 0 flags (text).** Per flag column: Equal to 1 font #22C55E bold; Equal to 0 font #EF4444; Is null font #D6A64A. (On the Heatmaps page use fills instead: 1 fill #14532D, 0 fill #7F1D1D.)

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Table: copy the Trends table (four flag columns already set), switch to `heatmaps`, change flag rules from font to fill, add the four return columns with colour-scale rules.
- Pivot: copy the Earnings strength heatmap pivot, switch source and fields.

## 5. Data gaps
- Return columns have no blanks today; `above_sma100` blank on 2, `above_sma200` on 3.
- The same mixed sector naming as Sector performance applies to the pivot (Technology vs Information Technology).

## 6. Build order
1. Canvas 1400 x 1110. 2. Table (copied from Trends), colour scales. 3. Pivot, caption. 4. Controls.
