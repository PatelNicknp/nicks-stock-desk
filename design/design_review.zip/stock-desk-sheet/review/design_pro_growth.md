# Growth scanner: Looker design spec (Design Pro)

**Purpose.** Stocks whose revenue growth clears the desk's growth level and are not labelled AVOID, fastest growers first.

No sample picture (same look as `sample_vcp.png`: control bar, four count cards, one wide table).

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Passes screen (x 244), Sector (460), Verdict (676), Ticker (892); feed status line x 1116 |
| 158 | 96 | 4 count cards of 271 |
| 270 | 880 | Scanner table, full width, 25 rows |
| 1166 | 40 | Caption (screen rule) |

Canvas 1400 x 1240.

## 2. Elements (tab `scanner_growth`)

**Controls.**
- Passes screen: drop-down `passes`, Single select, default `yes`. This is the page's on/off switch: `no` shows the names that did not pass; clearing it shows all 523. Group it with the table.
- Sector: drop-down `sector`, multi, default all. Verdict: drop-down `verdict`, default all. Ticker: drop-down `ticker`, Search ON.

**Count cards (y 158).**
- "Passing the screen": Record Count, filter `passes` = yes (77 today).
- "Of those, BUY": Record Count, filter `passes` = yes AND `verdict` = BUY.
- "Average revenue growth %, passing": `rev_growth` Average, 1 dec, filter `passes` = yes.
- "Average 3-month vs S&P 500 %, passing": `rs_spy_3m` Average, 1 dec, same filter.

**Scanner table (y 270, 1132 x 880).** Columns: `ticker` Ticker, `company` Company, `sector` Sector, `price` Price (2), `score` Score, `verdict` Verdict, `rev_growth` Revenue growth % (1), `eps_growth` EPS growth % (1), `rs_spy_3m` vs S&P 500, 3 mo % (1). Sort `rev_growth` Descending. Rows 25. Colours: score bands, verdict, ticker accent, return rules on `rev_growth`, `eps_growth`, `rs_spy_3m` (5 + 3 + 1 + 9 = 18 rules, under the 20 limit).

**Caption (y 1166).** 11 pt muted: "Passes when revenue growth is at least the desk's growth level (setting scoring.growth_min_pct) and the label is not AVOID. Blank growth means the filing did not have it." The `why` column is left out of the table: it holds only two fixed sentences, and the caption says the same.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Total score bands (`score`, desk range -6 to 13).** Single colour rules, Apply to = Score column, font #E6EBF5 bold: >= 12 fill #166534; between 9 and 11 fill #14532D; between 5 and 8 fill #283146; between 1 and 4 fill #7F1D1D; <= 0 fill #B91C1C. Same bands as Top stocks, so copying a Top stocks table brings them along.

**Return colours (text, not fill).** Per return column: > 0 font #22C55E; < 0 font #EF4444; = 0 leaves #E6EBF5; Is null > font #D6A64A. Apply to that column only.

**Verdict text.** Rules on `verdict`, Apply to = Verdict column, bold, no fill: Equal to BUY font #22C55E; HOLD font #F59E0B; AVOID font #EF4444.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Build this page first among the scanners. Table: copy the Top stocks table (score bands, verdict, ticker and Day % rules ride along), Setup > Data source > `scanner_growth`, swap columns, copy the Day % rule pair onto the growth columns.
- Cards: copy one styled card from Alerts or Watchlist, switch to `scanner_growth`, set the filter; copy three times; Arrange > Distribute horizontally.
- Then Page > Duplicate page to make Quality, Dividend and Wheel: on the copy, select all charts and controls (Ctrl+A, then Shift+click the nav and header to leave them out) > Setup > Data source > the new tab. Same-named fields (ticker, company, sector, price, score, verdict, passes) carry over.

## 5. Data gaps
- `why` has only two values ("Does not pass the growth screen." / "Revenue growth is at least the screen level and the label is not AVOID."), so it is a caption, not a column.
- `rev_growth` blank for 111 of 523 rows, `eps_growth` for 74: amber dashes, sorted to the bottom.
- `sector` mixes two naming sets (Information Technology and Technology, Financials and Financial Services, Consumer Discretionary and Consumer Cyclical, Consumer Staples and Consumer Defensive): 15 values instead of 11. The Sector drop-down will show both spellings until the job maps them.

## 6. Build order
1. Duplicate the Top stocks page or start a page; canvas 1400 x 1240; check the shared header and nav block.
2. Data source `scanner_growth`.
3. Table (copied), then cards, caption.
4. Controls; Arrange > Group the Passes switch with the table.
5. Test: Passes = no shows 446 names; the card numbers do not change.
