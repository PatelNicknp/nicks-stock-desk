# Backtest: Looker design spec (Design Pro)

**Purpose.** An honest answer to "does the score work?": the headline result, the growth of 10,000 versus the S&P 500, returns by score bucket, year by year, and the test's limits always in view.

Sample picture: `sample_backtest.png` (real values from the five backtest tabs).

## 1. Layout (content x 244-1376)

| y | Height | Left | Right |
| --- | --- | --- | --- |
| 106 | 36 | Control bar: Test window (grouped with the cards), Horizon (grouped with buckets) | |
| 158 | 72 | Headline panel, full width | |
| 246 | 96 | 4 cards of 271: Top-20 yearly pace, S&P 500 pace, Worst drop (top 20), 12-week hit rate | |
| 358 | 320 | Growth of 10,000 line (x 244, w 740) | Excess return by score bucket column chart (x 1000, w 376) |
| 694 | 250 | Score buckets table (w 740) | Year by year table (w 376) |
| 960 | 330 | Test limits (notes) table, full width | |

Canvas 1400 x 1340.

## 2. Elements

**Feed status line.** Right end of the control bar (x 1116, y 112, w 260, h 24): one-row table on `note` from `backtest_summary`, filter `data_status` = MISSING (recipe in Styling). Empty on a normal day.

**Controls (y 106).**
- Test window: drop-down `window` (tab `backtest_summary`), Single select, default `5y` (the headline row). Arrange > Group it with the 4 cards only, so the headline never disappears.
- Horizon: drop-down `horizon` (tab `backtest_buckets`), Single select, default `12w`, options 1w / 4w / 12w. Group it with the bucket chart and bucket table.

**Headline (y 158, 1132 x 72).** Tab `backtest_summary`, text-value box `headline`, chart filter Include `is_headline` Equal to yes. Roboto 20 pt, font #E6EBF5, on the plain panel. No green or red banner: today it says there is no clear edge. A second text-value table under it, 11 pt #8B96AD, Dimensions `start`, `end`, `months` with header ON (labels "From", "To", "Months") gives the window.

**Cards (y 246), tab `backtest_summary`.** Aggregation Max, Number 1 decimal, labels:
- `top20_cagr_pct` "Top-20 yearly pace %"
- `spy_cagr_pct` "S&P 500 yearly pace %"
- `top20_max_drawdown_pct` "Worst drop, top 20 %" (font #EF4444)
- `hit_rate_12w_pct` "12-week hit rate %"
No green on the top-20 card unless it beats the S&P card; keep both #E6EBF5 (simple and honest).

**Growth of 10,000 (x 244, y 358, 740 x 320).** Tab `backtest_equity`. Time series, Dimension `date` (Date, monthly points), Metrics `top20` "Top 20 by score" #22C55E, `spy` "S&P 500" #E6EBF5, `bottom20` "Bottom 20" #EF4444, Average aggregation, Currency off, 0 decimals, Compact numbers ON on the axis. Missing data Linear interpolation. Legend Top. Title "Growth of 10,000, monthly test".

**Excess by bucket (x 1000, y 358, 376 x 320).** Tab `backtest_buckets`. Column chart, Dimension `bucket` "Score at signal", Metric `excess_pct` "Excess vs S&P %" (Average, 2 dec). Sort `n` Descending (this puts the buckets in score order <=0, 1-3, 4-5, 6-7, 8-9, 10+, because fewer stocks reach higher scores). Bar rules: > 0 #22C55E, < 0 #EF4444. Data labels ON. Title "Excess return vs S&P 500 by score bucket". Leave red bars red.

**Buckets table (x 244, y 694, 740 x 250).** Tab `backtest_buckets`. Columns: `bucket` Score bucket, `n` Signals (0 dec), `avg_return_pct` Avg return %, `avg_spy_pct` S&P same period %, `excess_pct` Excess %, `hit_rate_pct` Hit rate % (1 dec; others 2). Sort `n` Descending (same trick). Rows 6, pagination OFF. Return colours on `avg_return_pct`, `avg_spy_pct`, `excess_pct`; null amber dash on all (the 10+ bucket has no signals).

**Year by year (x 1000, y 694, 376 x 250).** Tab `backtest_yearly`. Columns: `year` Year, `top20_pct` Top 20 %, `spy_pct` S&P 500 %, `difference_pct` Difference %, `signals` Signals. Sort `year` Ascending. Return colours on the three % columns. `hit_rate_12w_pct` left off to fit 376 px (it is in the cards). Caption: "2026 is the year so far."

**Test limits (y 960, 1132 x 330).** Tab `backtest_notes`. Columns `item` "What was tested" (w 300, bold #E6EBF5), `detail` "Detail" (wrap ON). Rows 8, pagination OFF, always visible. Title "Test limits, read before trusting the score".

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Text-value box (one-row table).** For a text field (company, reason, headline): Insert > Table, Dimension = the field, remove the metric (Record Count). Style: Table header OFF, Pagination OFF, Row numbers OFF, Wrap text ON, Background transparent, border none, Missing data Show blank. Font size and colour as listed.

**Return colours (text, not fill).** Per return column: > 0 font #22C55E; < 0 font #EF4444; = 0 leaves #E6EBF5; Is null > font #D6A64A. Apply to that column only.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Line chart style (L).** Time series chart, Dimension `date` (type Date). Style > Series: weight 2, colours as listed, Missing data > Linear interpolation (or Line breaks), never Show as 0. Axes Roboto 11 pt #8B96AD; Grid > Axis and Gridline colour #1E293B; Chart background #121826, Border #1E293B, radius 8. Legend: None for one series (the title names it); for several series, Legend Top, Roboto 11 pt #8B96AD, or name the colours in the title. Title Roboto 13 pt bold #E6EBF5 on the chart (Style > Show title) or a text box above it.

**Bar/column chart style (B).** Style > Bars colour as listed, Show data labels ON (11 pt #E6EBF5) when there are fewer than 15 bars, Axes 11 pt #8B96AD, Gridlines #1E293B, Background #121826, Border #1E293B, radius 8, Legend None (title names it). Bar charts accept conditional formatting: > 0 bar #22C55E, < 0 bar #EF4444.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Cards: copy a styled card from Watchlist and portfolio (Portfolio value) and switch data source to `backtest_summary`; copy 3 more, Arrange > Distribute horizontally.
- Line chart: build it here first; later pages (Breadth, XLY/XLP, Put/call, Historical P/E) copy this chart.
- Tables: copy the Top stocks table, switch data source, delete its CF rules that no longer apply (score/verdict), then copy the Day % rule pair for the return columns.
- Bucket chart: style once; Sector performance and Gainers pages reuse it.

## 5. Data gaps
- The spec says the equity line starts at 10,000. The first row in `backtest_equity` (2022-09-30) is already 8,890.14 / 9,065.54 / 9,015.29, so the 10,000 base is the month before and is not a row. The title says "Growth of 10,000" honestly; the first point just is not 10,000.
- There is no bucket order column. Sorting by `n` gives the right order today; if that ever looks wrong, the job should add a `bucket_order` column.
- The 10+ bucket has `n` 0 and blank returns at every horizon (no stock scored 10+ in the history); it shows amber dashes.
- Bucket labels 1-3, 4-5, 6-7, 8-9 could be turned into dates by Google Sheets when the script writes them (Jan 3, Apr 5...). Check the tab; if so, the job should prefix them (e.g. "score 1-3") or the sheet column should be Plain text.
- Spec cards: only 3 are listed; the 4th (`hit_rate_12w_pct`) is a real column added for balance. Drop it if Nick prefers three.

## 6. Build order
1. Canvas 1400 x 1340, shared header.
2. Data sources: `backtest_summary`, `backtest_equity`, `backtest_buckets`, `backtest_yearly`, `backtest_notes`.
3. Headline + window line, then cards.
4. Line chart, bucket chart.
5. Buckets table, Year table, Limits table.
6. Controls, Arrange > Group each with its charts. Test: Horizon 1w turns the top three buckets green; 12w shows all red.
