# Data updates: Looker design spec (Design Pro)

**Purpose.** How fresh every number is: each feed's last check, status (OK / CACHED / MISSING) and note, plus how many stocks are missing each field. No other decoration.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Left | Right |
| --- | --- | --- | --- |
| 106 | 36 | Control bar: Status (244) | |
| 158 | 600 | Updates log table (x 244, w 740), 15 rows | Field coverage table (x 1000, w 376), 15 rows |

Canvas 1400 x 800.

## 2. Elements

**Controls.** Status: drop-down `status` (tab `updates_log`), default all.

**Updates log (tab `updates_log`, x 244).** Columns: `checked_pt` Checked (PT), `source` Source, `status` Status (centred, w 90), `latest` Latest, `note` Note (wrap ON). Sort `checked_pt` Descending (text in yyyy-mm-dd hh:mm PT form sorts right). Rows 15, pagination OFF. Status fills (spec), font #E6EBF5 bold: OK fill #166534; CACHED fill #92400E; MISSING fill #7F1D1D. Title "Feeds, last run".

**Field coverage (tab `freshness`, x 1000).** Columns: `field` Field, `n_present` On file (0), `n_missing` Missing (0). Sort `n_missing` Descending. Rows 15. Rule: `n_missing` > 0 font #F59E0B; = 0 font #8B96AD. Title "How many stocks have each field". This is where a yield of 0 (real) and an unknown yield (missing) are told apart.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Both tables: copy the Backtest Year by year table (plain style), switch sources, delete return rules.

## 5. Data gaps
- `updates_log` has no `data_status` column (it is the status itself), so no feed status line on this page.
- `latest` mixes dates and counts (2026-10-23, 503, 101) and is blank for FRED; shown as text.
- FRED shows CACHED with a timeout message today; the fill makes it stand out.
- `freshness` is not in the spec's nav as its own page; placed here (see Dividend fundamentals). It shows `de` and `roe` missing for all 523.

## 6. Build order
1. Canvas 1400 x 800. 2. Updates log table and fills. 3. Field coverage table. 4. Control.
