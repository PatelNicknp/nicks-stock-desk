# VCP: Looker design spec (Design Pro)

**Purpose.** Nick's TradingView VCP rules run on the prices already on file: which names are ready (8/8 trend template, tightening pullbacks, under the buy point) or broke out today, with buy point, 7% stop, 20% target and 20-day trail. Nothing is downloaded and there is no TradingView button.

Page title text: **VCP**. Sample picture: `sample_vcp.png` (real rows from `scanner_vcp`: today 6 READY, 0 broken out).

## 1. Layout (content x 244-1376)

| y | Height | Left | Right |
| --- | --- | --- | --- |
| 106 | 36 | Control bar: Status (244), In a trade (460), Index (676), Ticker (892); feed status line x 1116 | |
| 158 | 96 | 4 count cards of 271: Broken out today, Ready, Watching, In a trade | |
| 270 | 460 | VCP table, full width, 12 rows per page | |
| 746 | 300 | Why this name (detail, x 244, w 558) | Trend template, 8 rules (x 818, w 558) |
| 1062 | 48 | Note line (the tab's `note`), full width | |

Canvas 1400 x 1140.

## 2. Elements (tab `scanner_vcp`)

**Controls (y 106).**
- Status: drop-down `status`, multi-select, default READY + BROKEN OUT today (WATCHING off). This is the main switch: tick WATCHING to see the 273 names still forming. Group it with the table, detail and rules tables (not the cards).
- In a trade: drop-down `in_trade`, default all. To see names where a buy already printed, pick yes and tick WATCHING in Status (those rows carry WATCHING).
- Index: drop-down `index_membership`, default all (values like SP500, SP500 / NDX100, Growth).
- Ticker: drop-down `ticker`, Search ON.

**Count cards (y 158).** Record Count with chart filters: `status` = BROKEN OUT today; `status` = READY; `status` = WATCHING; `in_trade` = yes. Today: 0, 6, 273, 5.

**VCP table (y 270, 1132 x 460).** Columns and labels: `ticker` Ticker, `index_membership` Index, `status` Status, `price` Price (2), `pivot` Buy point (2), `stop` Stop (2), `target` Target (2), `trail` 20-day trail (2), `strength` Strength (bar), `trend_score` Trend template, `contractions` Pullbacks, `depths` Pullback depths %, `freshness` Data. Sort: `status` Ascending (alphabetical gives BROKEN OUT today, READY, WATCHING, exactly the spec order), secondary `strength` Descending. Rows 12. Setup > Chart interactions > Cross-filtering ON. Colours: setup words (status 3, freshness 3), ticker (1), `stop` font #EF4444 and `target` font #22C55E via "Is not null" rules (2) = 9. `reason` is not a column (too long); it lives in the detail panel.

**Why this name (x 244, y 746, 558 x 300).** Table on the same tab: `ticker` Ticker, `reason` Reason (wrap ON), sort `strength` Descending, Rows 3. Caption: "Click a row in the table to read its full reason."

**Trend template, 8 rules (x 818, y 746, 558 x 300).** Table: `ticker`, `r1`..`r8`, Rows 8, header Wrap ON, sort `strength` Descending. Labels (from the indicator): r1 "Above 150d & 200d", r2 "150d over 200d", r3 "200d rising", r4 "50d over 150d & 200d", r5 "Above 50d", r6 "30%+ over 52w low", r7 "Within 25% of 52w high", r8 "Beats S&P 6m & 12m". PASS / FAIL rules (2). Column widths about 58 px each; ticker 70.

**Note line (y 1062).** Text-value box on `note` (one distinct value), 11 pt #8B96AD, wrap ON. Today it reads: "Stop and target before a buy apply the indicator's 7% and 20% to the pivot. On the buy bar they use that bar's close. A swing confirms 3 bars later. A tie for the high or low is not a pivot."

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Setup words (pattern scanners).** `status` font, bold, Apply to Status column: Equal to BROKEN OUT today #22C55E; READY #F59E0B; WATCHING #8B96AD. `freshness` font: FRESH #8B96AD; PARTIAL #F59E0B; STALE #EF4444. Strength as a calm data bar: Style > the Strength column > Bar (Show number ON), bar colour #7C9CFF, 0 decimals.

**PASS / FAIL cells.** Style > Conditional formatting > Add > Single colour > Select any field > Equal to PASS > font #22C55E bold; second rule Equal to FAIL > font #EF4444. Two rules cover all eight rule columns.

**Click-to-read detail panel.** Main table: Setup > Chart interactions > Cross-filtering ON. The detail table (same tab) then shows the clicked row; with nothing clicked it shows the top rows by the same sort. Detail table: Dimensions `ticker` + the long text fields, Style > General > Horizontal OFF, Wrap text ON, Rows 3, header ON (11 pt muted). Caption above it: "Click a row in the table to read its full reason." 

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Text-value box (one-row table).** For a text field (company, reason, headline): Insert > Table, Dimension = the field, remove the metric (Record Count). Style: Table header OFF, Pagination OFF, Row numbers OFF, Wrap text ON, Background transparent, border none, Missing data Show blank. Font size and colour as listed.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Build VCP first among the pattern scanners; CANSLIM, Box breakout, Flag breakout and Leaders are Page > Duplicate page of this one, then Ctrl+A (leave out nav and header) > Setup > Data source > the new tab. `ticker`, `index_membership`, `status`, `pivot`, `stop`, `target`, `strength`, `reason`, `freshness`, `price`, `note` exist on all five tabs, so most columns, the status/freshness rules and the strength bar survive.
- Main table: start from the Top stocks table copy (dark table style), delete its score/verdict rules, add the setup-word rules.
- Cards: copy from Growth, change filters.

## 5. Data gaps
- Today no row is BROKEN OUT today, so the default view shows the 6 READY names only. The status rule for BROKEN OUT is set up ahead of time.
- Names with a printed buy (`in_trade` = yes, 5 today) carry status WATCHING, so they are hidden by the default Status filter. The In a trade control (plus ticking WATCHING) shows them; `stop_basis` = buy on those rows.
- `trend_score` holds text like 8/8. Google Sheets may turn 8/8 into a date (Aug 8) when the script writes it. Check the tab: if it shows a date, set that sheet column to Plain text (Format > Number > Plain text) and re-run, or ask the job to write "8 of 8".
- `depths` is text ("20.2; 9.0; 5.7"), not numbers, so it cannot be coloured or sorted numerically. Fine as text.
- `volume_ok`, `in_trade`, `stop_basis` are on the tab but not in the spec's columns; only `in_trade` is used (as a control and card).

## 6. Build order
1. Canvas 1400 x 1140, title "VCP", shared header and the Scanners nav block.
2. Data source `scanner_vcp`.
3. Main table (copied from Top stocks), rules, strength bar, cross-filtering.
4. Cards, then the detail and 8-rule tables, then the note line.
5. Controls; Arrange > Group Status + In a trade with the three tables.
6. Test: tick WATCHING; click STLD in the table and the two lower tables show only STLD.
