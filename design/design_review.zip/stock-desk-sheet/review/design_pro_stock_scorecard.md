# Stock scorecard: Looker design spec (Design Pro)

**Purpose.** One stock on one page: who it is, the desk's verdict and plan, why it scored that way, and how price and earnings have behaved.

Sample picture: `sample_stock_scorecard.png` (real ADSK values from the GitHub CSVs, Oct 23 2026 run).

## 1. Layout (1400 canvas, content x 244-1376)

| y | Height | Left (x 244, w 740) | Right (x 1000, w 376) |
| --- | --- | --- | --- |
| 106 | 36 | Control bar: Ticker, News type | |
| 158 | 120 | **Identity panel**, full width 1132: ticker, company / sector / industry, price, day %, verdict, confidence, score | |
| 294 | 64 | **Reason** box, full width | |
| 374 | 116 | **Plan** panel (w 558): 5 mini cards | **Valuation** panel (x 818, w 558): 5 mini cards |
| 506 | 96 | **Score row**, full width: 6 cards of 175 (Technical, Financials, Sentiment, Earnings, Sector, Total) | |
| 618 | 300 | **Price chart** | **Earnings history** columns |
| 934 | 540 | **Score breakdown** table | **Versus sector** table (h 300), **Data basis** facts (y 1250, h 224) |
| 1490 | 230 | **News** table, full width | |

Canvas: Page settings > Canvas size Custom 1400 x 1780.

## 2. Elements

All from tab `scores` unless stated. Every chart's filter comes from the Ticker control.

**Feed status line.** Right end of the control bar (x 1116, y 112, w 260, h 24): one-row table on `note` from `scores`, filter `data_status` = MISSING (recipe in Styling). Empty on a normal day.

**Controls (y 106).**
- Ticker: Drop-down list, field `ticker` (tab `scores`), Single select ON, Search ON, Default selection = the rank-1 ticker at build time (ADSK on Oct 23). Make it report-level (right-click > Make report-level) so the choice follows Nick from Top stocks. x 244.
- News type: Drop-down, field `kind` (tab `news`), default `headline` only, so the desk note (which repeats the reason) is off unless Nick turns it on. x 460. Group it with the News table (Arrange > Group).

**Identity panel (y 158, 1132 x 120).** Rectangle (panel style) behind; on top:
- Ticker: text-value box `ticker`, Roboto 28 pt bold #7C9CFF, x 260 y 172, w 220.
- Company line: text-value box `company`, 15 pt #E6EBF5, x 260 y 214; under it a text-value table with `sector` and `industry` as two columns, 12 pt #8B96AD, header off, x 260 y 240.
- Price: scorecard `price`, Aggregation Max, label "Price", 2 decimals, x 700 y 170, 150 x 84, no border (sits on the panel).
- Day %: scorecard `day_pct` (Max), label "Day %", 2 decimals, conditional formatting > 0 font #22C55E, < 0 font #EF4444. x 866.
- Verdict: text-value box `verdict`, 20 pt bold, rules BUY #22C55E / HOLD #F59E0B / AVOID #EF4444. Pill: a 96 x 36 rectangle radius 6, border #1E293B, behind it. x 1032 y 178.
- Confidence: text-value box `confidence`, 12 pt #8B96AD, with a static text "Confidence" above, x 1032 y 226.
- Score: scorecard `score` (Max), label "Desk score", 28 pt, score-band fill (rules below), 110 x 84, x 1250 y 170.

**Reason (y 294).** Text-value box `reason`, 13 pt #E6EBF5, wrap ON, w 1132, panel behind it.

**Plan panel (x 244, y 374, 558 x 116).** Title text "Plan" (13 pt bold). Five scorecards 98 x 68, Aggregation Max, 2 decimals, label 11 pt muted: `entry_low` "Entry low", `entry_high` "Entry high", `stop` "Stop" (value font #EF4444), `trade_target` "Trade target" (value font #22C55E), `reward_risk` "Reward / risk". Caption under: "AVOID leaves entry and trade target blank on purpose."
**Valuation panel (x 818, y 374, 558 x 116).** Title "Valuation". Five cards: `target_analyst` "Analyst target", `target_pfcf` "Cash-flow target", `target_peg` "PEG target", `target_blended` "Blended target" (bold #7C9CFF), `target_blend_n` "Inputs in blend" (0 decimals). Under the analyst card a text-value box `target_analyst_kind` 11 pt #8B96AD (reads "median").

**Score row (y 506).** Six scorecards 175 x 96, Aggregation Max: `pts_tech` "Technical", `pts_fin` "Financials", `pts_sent` "Sentiment", `pts_earnings` "Earnings", `pts_sector` "Sector", `score` "Total score". The five component cards use these background rules (scorecard > Style > Conditional formatting): >= 2 fill #166534; = 1 fill #14532D; = 0 fill #283146; = -1 fill #7F1D1D; <= -2 fill #B91C1C (financials runs -7..7 and sentiment -2..4, so the ends are >= / <=). Total uses the score bands. Missing data "-".

**Price chart (x 244, y 618, 740 x 300).** Tab `prices`. Time series, Dimension `date`, Metrics `close` "Close" #E6EBF5, `sma20` "20-day avg" #7C9CFF, `sma50` "50-day avg" #8B96AD (all Aggregation Average). Date range: all (the tab holds about 126 sessions). Style > Reference lines > Add 4, type Metric, Calculation Average (the plan levels are the same on every row): `entry_low` "Entry low" #F59E0B dashed 1 px; `entry_high` "Entry high" #F59E0B dashed; `stop` "Stop" #EF4444 dashed; `trade_target` "Target" #22C55E dashed; Show label ON. Missing data > Linear interpolation. Legend Top. Title "Price, last 6 months, with plan levels".

**Earnings history (x 1000, y 618, 376 x 300).** Tab `earnings_history`. Column chart, Dimension `earnings_date` (Date), Metrics `surprise_pct` "EPS surprise %" #7C9CFF and `move_1d_pct` "Next-day move %" #8B96AD. Sort `earnings_date` Descending, Bars 8. Filter: Exclude `eps_actual` Is null (drops the future date). Data labels ON, 1 decimal. Title "Last 8 reports: surprise and next-day move %". Legend Top.

**Score breakdown (x 244, y 934, 740 x 540).** Tab `score_details`. Table, Dimensions: `group_name` "Group", `item` "Item" (wrap ON), `points_label` "Points", `now_value` "Now", `avg_value` "Own 3-yr avg", `vs_industry` "Vs sector". No metric. Sort `group_name` Ascending, secondary `item` Ascending. Rows per page 20 (16 rows per stock). `now_value` / `avg_value` Number 2 decimals. Colour rules on `points_label` (text): Equal to +2 fill #166534; +1 fill #14532D; +0 fill #283146; -1 fill #7F1D1D; -2 fill #B91C1C; Equal to n/a font #D6A64A. `vs_industry`: point rules for 1 / 0 / -1 and Is null amber (10 + 4 = 14 rules, under the 20 limit). Title "Score breakdown, every point shown".

**Versus sector (x 1000, y 934, 376 x 300).** Tab `scores`. Table, no dimension, Metrics (Aggregation Max): `pts_forward_pe_ind` "Forward P/E", `pts_ttm_pe_ind` "Trailing P/E", `pts_ps_ind` "Price / sales", `pts_pfcf_ind` "Price / FCF", `pts_rev_growth_ind` "Revenue growth", `pts_eps_growth_ind` "EPS growth", `pts_div_yield_ind` "Dividend yield". Style > General > Horizontal (turns the columns into rows so it fits 376 px). Colour with one "Select any field" rule set (every value here is a point). Caption under the title, verbatim: "Versus other stocks in this sector on the desk, not a paid industry set. Not added into the score again."

**Data basis (x 1000, y 1250, 376 x 224).** Tab `scores`. Table, Dimensions `fundamentals_basis` "Fundamentals from", `fundamentals_filed` "Filed", `fin_avg_years` "Years in own average", `forward_pe_avg_basis` "Forward P/E average" (wrap), `missing_fields` "Missing fields", Style > General > Horizontal, 11 pt, values #8B96AD. Title "Data basis".

**News (x 244, y 1490, 1132 x 230).** Tab `news`. Table: `headline` "Headline" (wrap ON, w ~760), `publisher` "Source", `published` "Published". Sort `published` Descending (text in yyyy-mm-dd hh:mm form, so it sorts right). Rows 6. Rule: `kind` Equal to desk_note > Entire row font #8B96AD (only visible when Nick switches News type to include it). Optional: `link` as a Hyperlink field on the headline. Caption: "News is fetched for the focus list only. Other tickers show no rows here."

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Text-value box (one-row table).** For a text field (company, reason, headline): Insert > Table, Dimension = the field, remove the metric (Record Count). Style: Table header OFF, Pagination OFF, Row numbers OFF, Wrap text ON, Background transparent, border none, Missing data Show blank. Font size and colour as listed.

**Total score bands (`score`, desk range -6 to 13).** Single colour rules, Apply to = Score column, font #E6EBF5 bold: >= 12 fill #166534; between 9 and 11 fill #14532D; between 5 and 8 fill #283146; between 1 and 4 fill #7F1D1D; <= 0 fill #B91C1C. Same bands as Top stocks, so copying a Top stocks table brings them along.

**Point colours (-2..+2), per point column.** Style > Conditional formatting > Add > Single colour, Apply to = that column only (not entire row): = 2 fill #166534; = 1 fill #14532D; = 0 fill #283146; = -1 fill #7F1D1D; = -2 fill #B91C1C; all with font #E6EBF5 bold; plus Is null > font #D6A64A, no fill. Centre the column if Style offers alignment. Looker allows 20 rules per chart: if a table has more than three point columns, use one Colour scale rule per column instead (Colour type > Colour scale, Min -2 #B91C1C, Mid 0 #283146, Max 2 #166534), or a "Select any field" rule set when every coloured column is a point column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Line chart style (L).** Time series chart, Dimension `date` (type Date). Style > Series: weight 2, colours as listed, Missing data > Linear interpolation (or Line breaks), never Show as 0. Axes Roboto 11 pt #8B96AD; Grid > Axis and Gridline colour #1E293B; Chart background #121826, Border #1E293B, radius 8. Legend: None for one series (the title names it); for several series, Legend Top, Roboto 11 pt #8B96AD, or name the colours in the title. Title Roboto 13 pt bold #E6EBF5 on the chart (Style > Show title) or a text box above it.

**Bar/column chart style (B).** Style > Bars colour as listed, Show data labels ON (11 pt #E6EBF5) when there are fewer than 15 bars, Axes 11 pt #8B96AD, Gridlines #1E293B, Background #121826, Border #1E293B, radius 8, Legend None (title names it). Bar charts accept conditional formatting: > 0 bar #22C55E, < 0 bar #EF4444.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Panels: copy one styled rectangle and paste for Identity, Reason, Plan, Valuation; resize with Arrange > Make same size.
- Mini cards: style the Entry low card once, copy 4 times, swap the metric (Setup > Metric). Then select the five and Arrange > Distribute horizontally, Align top. Do the same in Valuation by copying the whole set of five.
- Score row: build Technical with its five background rules, copy 4 times (rules follow the copy; re-pick the field in each rule after swapping the metric). Total: copy from the Top stocks score styling.
- Breakdown and News tables: copy the Top stocks table (it already has the dark table style), then Setup > Data source > `score_details` / `news`, and rebuild the columns.
- Bring the panel rectangles to the back: select them > Arrange > Send to back.

## 5. Data gaps
- `prices.sma20` is blank in about 31% of rows and `sma50` in about 67% (ADSK: 38 and 83 of 124). Linear interpolation hides short gaps; long gaps will draw a straight bridge. The job should fill these.
- `scores.reward_risk` is 2.5 on every row (a fixed rule, not measured).
- `pts_de_ind`, `pts_roe_ind`, `pts_de`, `pts_roe` are blank on all 523 rows (no debt/equity or ROE feed), so they are left off the versus-sector table.
- `score_details.points_label` uses text like +1 and +0. Google Sheets may turn "+1" into the number 1 when the script writes it. If the Points column shows 1 instead of +1, colour `points` (numeric) instead and hide `points_label`.
- `news` covers 34 focus tickers only. The `desk_note` row has headline "Desk note" and its text sits in `summary` (same text as `reason`), with blank `published`.
- No `day_change` column; the header uses `day_pct`.
- `target_peg` is blank for 338 of 523 stocks (ADSK too); the card shows the amber dash.

## 6. Build order
1. Canvas 1400 x 1780; paste the shared header.
2. Add data sources `scores`, `score_details`, `prices`, `news`, `earnings_history` (Resource > Manage added data sources); set `date` / `earnings_date` to Date.
3. Ticker control (report-level), then the News type control.
4. Panels (rectangles), send to back.
5. Identity, Reason, Plan, Valuation, Score row (style one card, copy the rest).
6. Price chart, Earnings chart.
7. Breakdown, Versus sector, Data basis, News tables.
8. Check with ADSK, then a HOLD and an AVOID ticker (blank entry and target should show dashes, not 0).
