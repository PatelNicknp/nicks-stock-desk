# Watchlist and portfolio: Looker design spec (Design Pro)

**Purpose.** How Nick's holdings stand today (value, gain, score, which need a look) and how far each watchlist name is from its entry zone.

Sample picture: `sample_watchlist_and_portfolio.png` (real values from `portfolio_summary`, `portfolio`, `watchlist`; these are the example holdings the job ships with).

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Verdict, Holding status, Ticker |
| 158 | 32 | Example warning strip (amber text), full width |
| 202 | 104 | Summary row: 4 panels of 271 (Portfolio value, Day P/L, Total gain, Average score) + needs-attention text inside the 4th |
| 322 | 28 | Section title "My holdings" + caption right ("n holdings") |
| 358 | 260 | Holdings table, full width |
| 642 | 28 | Section title "Watchlist, not owned yet" |
| 678 | 240 | Watchlist table, full width |

Canvas 1400 x 1000.

## 2. Elements

**Feed status line.** Right end of the control bar (x 1116, y 112, w 260, h 24): one-row table on `note` from `portfolio`, filter `data_status` = MISSING (recipe in Styling). Empty on a normal day.

**Controls (y 106).** Verdict: drop-down `verdict` (tab `portfolio`), multi-select, default all. Holding status: drop-down `status` (tab `portfolio`), default all. Ticker: drop-down `ticker` (tab `watchlist`), Search ON, default all. Group Verdict + Status with the Holdings table and Ticker with the Watchlist table (Arrange > Group) so each switch drives only its table.

**Example warning (y 158).** Tab `portfolio_summary`. Text-value box on `example_warning`, Roboto 12 pt, font #F59E0B, Missing data Show blank (so it disappears when Nick's real holdings are loaded). Put a 1132 x 32 rectangle behind it: background #121826 with border #F59E0B 1 px, radius 6.

**Summary row (y 202), tab `portfolio_summary`.** Four 271 x 104 panels. In each, a big scorecard (label 11 pt muted, value 24 pt) and under it a small scorecard with the label hidden (12 pt):
- Portfolio value: `value`, Currency USD, 0 decimals. Small: `n_holdings` with a static text "holdings" after it.
- Day P/L: `day_pnl`, Currency USD, 2 decimals, rule > 0 font #22C55E, < 0 font #EF4444. Small: `day_pnl_pct` Number 2 decimals, same rules, a static "%" text after it.
- Total gain: `total_gain`, Currency USD 0 decimals, same rules. Small: `total_gain_pct` 2 decimals, same rules.
- Average desk score: `avg_score`, 1 decimal. Small: `needs_attention` 0 decimals, value font #F59E0B when > 0, with static text "need attention".

**Holdings table (y 358, 1132 x 260).** Tab `portfolio`. Dimensions in this order, with labels: `ticker` Ticker, `shares` Shares (0 dec), `avg_cost` Avg cost (2), `price` Price (2), `value` Value (Currency 0), `gain` Gain (Currency 0), `gain_pct` Gain % (1), `weight_pct` Weight % (1), `score` Score, `score_week_change` Score vs week ago, `verdict` Verdict, `stop` Stop (2), `status` Status. Treat numbers as dimensions (one row per holding, so no aggregation is needed) or as metrics with Sum; either is fine. Sort `weight_pct` Descending. Rows per page 25. Colours: score bands on `score`; returns on `gain`, `gain_pct`, `score_week_change`; verdict rules; ticker accent; `status` rules (font, bold): Equal to Below stop #EF4444, Weakening #F59E0B, Earnings soon #7C9CFF, On track #8B96AD. That is 5 + 12 + 3 + 1 + 4 = 25 rules, over the 20 limit, so colour `gain` and `gain_pct` only by font (> 0 green, < 0 red: 4 rules) and give `score_week_change` just the null-amber rule: 5 + 4 + 2 + 3 + 1 + 4 = 19.

**Watchlist table (y 678, 1132 x 240).** Tab `watchlist`. Columns: `ticker` Ticker, `company` Company, `price` Price (2), `day_pct` Day % (2), `score` Score, `verdict` Verdict, `entry_low` Entry low (2), `entry_high` Entry high (2), `distance_to_entry_pct` Distance to entry % (1), `timing` Trend, `note_input` Nick's note (wrap ON). Sort `score` Descending. Colours: score bands, verdict, ticker accent, returns on `day_pct`; `distance_to_entry_pct` font: > 0 #F59E0B (price above the zone: wait for a dip), < 0 #EF4444 (price has fallen below the zone), = 0 #22C55E (inside the zone), Is null amber dash; `timing` font Uptrend #22C55E, Downtrend #EF4444, Extended #F59E0B, Sideways #8B96AD. Blank entry (AVOID names) shows the amber dash.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Text-value box (one-row table).** For a text field (company, reason, headline): Insert > Table, Dimension = the field, remove the metric (Record Count). Style: Table header OFF, Pagination OFF, Row numbers OFF, Wrap text ON, Background transparent, border none, Missing data Show blank. Font size and colour as listed.

**Total score bands (`score`, desk range -6 to 13).** Single colour rules, Apply to = Score column, font #E6EBF5 bold: >= 12 fill #166534; between 9 and 11 fill #14532D; between 5 and 8 fill #283146; between 1 and 4 fill #7F1D1D; <= 0 fill #B91C1C. Same bands as Top stocks, so copying a Top stocks table brings them along.

**Return colours (text, not fill).** Per return column: > 0 font #22C55E; < 0 font #EF4444; = 0 leaves #E6EBF5; Is null > font #D6A64A. Apply to that column only.

**Verdict text.** Rules on `verdict`, Apply to = Verdict column, bold, no fill: Equal to BUY font #22C55E; HOLD font #F59E0B; AVOID font #EF4444.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Holdings and Watchlist tables: copy the Top stocks table (score bands, verdict, ticker and Day % rules already set), paste, switch Setup > Data source, then add/remove columns. Rules on fields that also exist in the new tab keep working; re-pick any rule that shows a red field.
- Summary cards: style Portfolio value (panel + big + small card) once, select the three items, Ctrl+C, paste 3 times, swap the metrics. Arrange > Distribute horizontally across x 244-1376.
- Copy the Day P/L colour rules to Total gain by copying the card, not by retyping.

## 5. Data gaps
- `portfolio.score_week_ago` and `score_week_change` are blank on all 5 rows today (the week-ago memory has no entry yet). The column shows amber dashes until a week has passed.
- The status values in today's file are only "On track" and "Earnings soon". "Below stop" and "Weakening" rules are set up ahead of time.
- No single "entry zone" column: the spec's entry zone is `entry_low` + `entry_high` (two columns).
- All holdings are `example = yes`; the warning strip stays until Nick edits input/holdings.csv.
- `distance_to_entry_pct` sign checked against today's rows: LLY +5.69 and PLTR +0.63 sit above `entry_high`, AVGO -7.75 sits below `entry_low`. No row is inside a zone today, so the = 0 case is unverified.
- `watchlist` has `day_pct` and `company`, which the spec does not list; they are used because they are real and short.

## 6. Build order
1. Canvas 1400 x 1000, shared header.
2. Data sources `portfolio_summary`, `portfolio`, `watchlist`.
3. Warning strip, then the four summary panels (style one, copy three).
4. Holdings table (copied from Top stocks), then Watchlist table (copied from Holdings).
5. Controls, then Arrange > Group each control with its table.
6. Test: pick Verdict = AVOID (JPM only), Status = Earnings soon.
