import csv,sys
sys.path.insert(0,'.')
from common import *
D='/workspace/nsd-repo/data/'
R=lambda f:list(csv.DictReader(open(D+f)))
T='ADSK'
s=[r for r in R('scores.csv') if r['ticker']==T][0]
det=[r for r in R('score_details.csv') if r['ticker']==T]
pr=[r for r in R('prices.csv') if r['ticker']==T]
news=[r for r in R('news.csv') if r['ticker']==T and r['kind']=='headline']
eh=[r for r in R('earnings_history.csv') if r['ticker']==T and r['eps_actual']!=''][:8][::-1]
num=lambda k: None if s[k]=='' else float(s[k])
H=2010
def card(l,v,color=TX,size=26,bg=None,sub=None):
    st=f' style="background:{bg};border-color:{bg}"' if bg else ''
    return f'<div class="card"{st}><div class="l"{" style=color:#E6EBF5" if bg else ""}>{l}</div><div class="v" style="color:{color};font-size:{size}px">{v}</div>{f"<div class=s>{sub}</div>" if sub else ""}</div>'
vc=VC[s['verdict']]
ident=f'''<div class="panel pad" style="display:flex;align-items:center;gap:28px;margin-bottom:16px;height:120px">
<div style="width:380px"><div style="font-size:30px;font-weight:800;color:{AC}">{T}</div><div style="font-size:16px;margin-top:4px">{s['company']}</div><div class="cap" style="margin-top:3px">{s['sector']} &middot; {s['industry']}</div></div>
<div style="width:170px"><div class="cap">Price</div><div style="font-size:26px;font-weight:700">{f(s['price'])}</div></div>
<div style="width:150px"><div class="cap">Day %</div><div style="font-size:26px;font-weight:700;color:{retc(s['day_pct'])}">{f(s['day_pct'],2,True)}</div></div>
<div style="width:190px"><div class="cap">Verdict</div><div style="display:inline-block;margin-top:4px;padding:4px 16px;border:1px solid #1E293B;border-radius:6px;font-size:20px;font-weight:800;color:{vc}">{s['verdict']}</div>
<div class="cap" style="margin-top:6px">Confidence <b style="color:#E6EBF5">{s['confidence']}</b></div></div>
<div style="margin-left:auto;width:130px;height:88px;border-radius:8px;background:{band(int(s['score']))};display:flex;flex-direction:column;align-items:center;justify-content:center"><div style="font-size:12px">Desk score</div><div style="font-size:32px;font-weight:800">{s['score']}</div></div></div>'''
reason=f'<div class="panel pad" style="margin-bottom:16px;font-size:14px;line-height:21px">{esc(s["reason"])}</div>'
def mini(l,k,color=TX):
    v=num(k); return f'<div style="flex:1"><div class="cap">{l}</div><div style="font-size:20px;font-weight:700;color:{color};margin-top:4px">{f(v) if v is not None else NA_HTML}</div></div>'
plan=f'''<div class="panel pad" style="flex:1"><div class="ptitle">Plan</div><div style="display:flex;gap:12px;margin-top:10px">{mini("Entry low","entry_low")}{mini("Entry high","entry_high")}{mini("Stop","stop",DN)}{mini("Trade target","trade_target",UP)}{mini("Reward / risk","reward_risk")}</div><div class="cap" style="margin-top:10px">AVOID leaves entry and trade target blank on purpose.</div></div>'''
val=f'''<div class="panel pad" style="flex:1"><div class="ptitle">Valuation</div><div style="display:flex;gap:12px;margin-top:10px">{mini("Analyst target","target_analyst")}{mini("Cash-flow target","target_pfcf")}{mini("PEG target","target_peg")}{mini("Blended target","target_blended",AC)}<div style="flex:1"><div class="cap">Inputs in blend</div><div style="font-size:20px;font-weight:700;margin-top:4px">{s["target_blend_n"]}</div></div></div><div class="cap" style="margin-top:10px">Analyst target is the {s["target_analyst_kind"]}. The blend used {s["target_blend_n"]} inputs.</div></div>'''
srow='<div class="row">'+"".join(card(l,f"{num(k):+.0f}",TX,28,pts(num(k))) for l,k in [("Technical","pts_tech"),("Financials","pts_fin"),("Sentiment","pts_sent"),("Earnings","pts_earnings"),("Sector","pts_sector")])+card("Total score",s['score'],TX,28,band(int(s['score'])))+'</div>'
cl=[float(r['close']) for r in pr]; s20=[float(r['sma20']) if r['sma20'] else None for r in pr]; s50=[float(r['sma50']) if r['sma50'] else None for r in pr]
xl=[(i,pr[i]['date'][5:7]+"/"+pr[i]['date'][8:]) for i in range(0,len(pr),25)]
svg=line_svg([(s50,MU,1.6),(s20,AC,1.6),(cl,TX,2)],820,300,refs=[(num('trade_target'),UP,"Target 275.87","r"),(num('entry_high'),AM,"Entry high 230.90","r"),(num('entry_low'),AM,"Entry low 223.08","rb"),(num('stop'),DN,"Stop 207.44","rb")],xlabels=xl)
chart=f'''<div class="panel pad" style="width:870px;flex:none"><div style="display:flex;justify-content:space-between"><div class="ptitle">Price, last 6 months, with plan levels</div><div class="lg"><span><i style="background:#E6EBF5"></i>Close</span><span><i style="background:{AC}"></i>20-day avg</span><span><i style="background:{MU}"></i>50-day avg</span></div></div>{svg}<div class="cap">Gaps in the averages are bridged (Missing data: Linear interpolation). The file leaves many average values blank.</div></div>'''
# earnings columns
mx=max(max(abs(float(r['surprise_pct'])),abs(float(r['move_1d_pct'] or 0))) for r in eh)
bars=""; W=380; bw=14; base=150; sc=120/mx
for i,r in enumerate(eh):
    x=30+i*44; su=float(r['surprise_pct']); mv=r['move_1d_pct']
    bars+=f'<rect x="{x}" y="{base-su*sc if su>0 else base}" width="{bw}" height="{abs(su)*sc}" fill="{AC}" rx="2"/><text x="{x+7}" y="{base-su*sc-4 if su>0 else base+abs(su)*sc+12}" font-size="10" fill="#E6EBF5" text-anchor="middle">{su:.1f}</text>'
    if mv!='':
        m=float(mv); bars+=f'<rect x="{x+bw+2}" y="{base-m*sc if m>0 else base}" width="{bw}" height="{abs(m)*sc}" fill="{MU}" rx="2"/><text x="{x+bw+9}" y="{base-m*sc-4 if m>0 else base+abs(m)*sc+12}" font-size="10" fill="#8B96AD" text-anchor="middle">{m:.1f}</text>'
    bars+=f'<text x="{x+15}" y="292" font-size="10" fill="#8B96AD" text-anchor="middle">{r["earnings_date"][2:7]}</text>'
earn=f'''<div class="panel pad" style="flex:1;min-width:0"><div class="ptitle">Last 8 reports: surprise and next-day move %</div><div class="lg" style="margin:4px 0 2px"><span><i style="background:{AC};height:8px"></i>EPS surprise %</span><span><i style="background:{MU};height:8px"></i>Next-day move %</span></div>
<svg width="{W}" height="300"><line x1="20" x2="{W-10}" y1="{base}" y2="{base}" stroke="#1E293B"/>{bars}</svg></div>'''
def ptd(lbl):
    c={"+2":"#166534","+1":"#14532D","+0":"#283146","-1":"#7F1D1D","-2":"#B91C1C"}.get(lbl)
    return f'<td class="pill" style="background:{c}">{lbl}</td>' if c else f'<td class="c na">n/a</td>'
def vs(v):
    if v=='': return f'<td class="c">{NA_HTML}</td>'
    v=float(v); return f'<td class="pill" style="background:{pts(v)}">{v:+.0f}</td>'
order={"Technical":0,"Financials":1,"Sentiment":2,"Earnings":3,"Sector":4}
det=sorted(det,key=lambda r:(r['group_name'],r['item']))
rows="".join(f'<tr><td class="m2">{r["group_name"]}</td><td>{esc(r["item"])}</td>{ptd(r["points_label"])}<td class="num">{f(r["now_value"])}</td><td class="num">{f(r["avg_value"])}</td>{vs(r["vs_industry"])}</tr>' for r in det)
brk=f'''<div class="panel" style="width:870px;flex:none"><div class="pad" style="padding-bottom:8px"><div class="ptitle">Score breakdown, every point shown</div></div><table><thead><tr><th>Group<span class="sort">&#9650;</span></th><th>Item</th><th class="c">Points</th><th class="num">Now</th><th class="num">Own 3-yr avg</th><th class="c">Vs sector</th></tr></thead><tbody>{rows}</tbody></table></div>'''
ind=[("Forward P/E","pts_forward_pe_ind"),("Trailing P/E","pts_ttm_pe_ind"),("Price / sales","pts_ps_ind"),("Price / FCF","pts_pfcf_ind"),("Revenue growth","pts_rev_growth_ind"),("EPS growth","pts_eps_growth_ind"),("Dividend yield","pts_div_yield_ind")]
irows="".join(f'<tr><td>{l}</td>{vs(s[k])}</tr>' for l,k in ind)
indp=f'''<div class="panel" style="margin-bottom:16px"><div class="pad" style="padding-bottom:6px"><div class="ptitle">Versus sector</div><div class="cap">Versus other stocks in this sector on the desk, not a paid industry set. Not added into the score again.</div></div><table><tbody>{irows}</tbody></table></div>'''
facts=[("Fundamentals from",s['fundamentals_basis']),("Filed",s['fundamentals_filed']),("Years in own average",s['fin_avg_years']),("Forward P/E average",s['forward_pe_avg_basis']),("Missing fields",s['missing_fields'])]
frows="".join(f'<tr><td class="m2" style="width:150px">{l}</td><td class="wrap">{esc(v)}</td></tr>' for l,v in facts)
factp=f'<div class="panel"><div class="pad" style="padding-bottom:6px"><div class="ptitle">Data basis</div></div><table><tbody>{frows}</tbody></table></div>'
nrows="".join(f'<tr><td class="wrap">{esc(r["headline"])}</td><td class="m2">{esc(r["publisher"])}</td><td class="m2">{r["published"]}</td></tr>' for r in news)
newsp=f'<div class="panel"><div class="pad" style="padding-bottom:6px"><div class="ptitle">News</div><div class="cap">News is fetched for the focus list only. Other tickers show no rows here.</div></div><table><thead><tr><th>Headline</th><th>Source</th><th>Published<span class="sort">&#9660;</span></th></tr></thead><tbody>{nrows}</tbody></table></div>'
body=ident+reason+f'<div class="row">{plan}{val}</div>'+srow+f'<div class="row">{chart}{earn}</div>'+f'<div class="row">{brk}<div style="flex:1;min-width:0">{indp}{factp}</div></div>'+newsp
html=page("Stock scorecard","Stock scorecard",[("Ticker","ADSK"),("News type","headline")],body,H)
render(html,'/workspace/stock-desk-sheet/review/sample_stock_scorecard.png',H)
print("ok")
