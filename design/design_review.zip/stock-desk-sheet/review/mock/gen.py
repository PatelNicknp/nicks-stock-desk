rows = [
("2","BSX","Boston Scientific","Health Care",13,"BUY",45.69,-0.7,"Sideways",42.52,43.7,40.17,50.47),
("1","ADSK","Autodesk","Information Technology",13,"BUY",252.2,-1.08,"Extended",223.08,230.9,207.44,275.87),
("3","AVY","Avery Dennison","Materials",12,"BUY",181.83,-1.53,"Sideways",169.11,172.81,161.7,194.12),
("6","LOW","Lowe's","Consumer Discretionary",11,"BUY",198.68,-2.78,"Sideways",183.39,188.58,173.01,218.43),
("4","BR","Broadridge Financial","Industrials",11,"BUY",183.28,-1.53,"Extended",164.4,168.34,156.52,190.98),
("7","TDY","Teledyne Technologies","Information Technology",11,"BUY",625.41,0.8,"Sideways",601.35,615.89,572.25,699.53),
("5","HCA","HCA Healthcare","Health Care",11,"BUY",469.03,0.37,"Uptrend",437.26,448.85,414.09,515.46),
("9","WMT","Walmart","Consumer Staples",11,"BUY",119.89,-1.02,"Uptrend",109.56,112.19,104.29,127.34),
("8","TYL","Tyler Technologies","Information Technology",11,"BUY",390.14,-0.59,"Extended",335.02,346.06,312.94,409.53),
(None,"DVA","DaVita","Health Care",10,"BUY",183.64,-1.32,"Sideways",174.44,180.27,162.79,213.76),
(None,"FICO","Fair Isaac","Information Technology",10,"HOLD",815.31,-0.97,"Downtrend",691.28,727.72,618.39,937.27),
(None,"WAT","Waters Corporation","Health Care",10,"BUY",453.67,-0.42,"Uptrend",424.14,438.73,394.89,522.77),
(None,"DIS","Walt Disney Co","Communication Services",10,"BUY",112.52,-0.54,"Uptrend",106.9,107.65,102.96,118.05),
(None,"AMT","American Tower","Real Estate",10,"BUY",188.97,4.08,"Extended",173.49,174.18,160.65,206.8),
(None,"PLTR","Palantir Technologies","Information Technology",10,"BUY",196.75,0.29,"Uptrend",186.55,195.51,168.62,247.06),
(None,"MSI","Motorola Solutions","Information Technology",10,"BUY",481.83,0.84,"Sideways",447.26,455.35,431.08,501.87),
(None,"MLM","Martin Marietta Materials","Materials",10,"BUY",507.17,-2.03,"Sideways",477.17,489.02,453.47,557.15),
(None,"STE","Steris","Health Care",10,"BUY",232.15,-0.03,"Sideways",211.53,216.9,200.78,247.81),
]
def band(s):
    return "#166534" if s>=12 else "#14532D" if s>=9 else "#283146" if s>=5 else "#7F1D1D" if s>=1 else "#B91C1C"
VC={"BUY":"#22C55E","HOLD":"#F59E0B","AVOID":"#EF4444"}
TC={"Uptrend":"#22C55E","Downtrend":"#EF4444","Extended":"#F59E0B","Sideways":"#8B96AD"}
body=""
for i,r in enumerate(rows):
    rk,t,c,sec,sc,v,p,d,tr,el,eh,st,tg=r
    bg="#0F1420" if i%2==0 else "#121826"
    dc="#22C55E" if d>0 else "#EF4444" if d<0 else "#E6EBF5"
    rkc=f'<td class="num rk">{rk}</td>' if rk else '<td class="num rk na">&ndash;</td>'
    body+=f'''<tr style="background:{bg}">{rkc}<td class="tk">{t}</td><td>{c}</td><td class="mut">{sec}</td>
<td class="sc" style="background:{band(sc)}">{sc}</td><td class="vd" style="color:{VC[v]}">{v}</td>
<td class="num">{p:.2f}</td><td class="num" style="color:{dc}">{d:+.2f}%</td><td style="color:{TC[tr]}">{tr}</td>
<td class="num">{el:.2f}</td><td class="num">{eh:.2f}</td><td class="num">{st:.2f}</td><td class="num">{tg:.2f}</td></tr>\n'''
nav=[("Overview",["Today","Top stocks","Stock scorecard","Watchlist and portfolio","Alerts","Backtest"],True),
("Scanners",["Growth","Quality","Dividend","Wheel (stocks only)","VCP","CANSLIM","Box breakout","Flag breakout","Leaders"],True),
("Earnings",["Calendar","Strength heatmap","Report cards"],False),
("Sentiment",["x"]*8,False),("Financials",["x"]*4,False),("Macro",["x"]*3,False),
("Technicals",["x"]*7,False),("System",["Data updates","Help"],False)]
navh=""
for g,items,open_ in nav:
    chev="&#9662;" if open_ else "&#9656;"
    navh+=f'<div class="grp"><span class="chev">{chev}</span>{g}<span class="cnt">{len(items)}</span></div>'
    if open_:
        for it in items:
            navh+=f'<div class="item{" sel" if it=="Top stocks" else ""}">{it}</div>'
dd=""
for l in ["Verdict","Sector","Confidence","Index"]:
    dd+=f'<div class="dd"><span>{l}</span><span class="dmut">All</span><svg width="10" height="6" viewBox="0 0 10 6"><path d="M1 1l4 4 4-4" stroke="#8B96AD" stroke-width="1.5" fill="none"/></svg></div>'
html=f'''<!doctype html><html><head><meta charset="utf-8"><style>
*{{box-sizing:border-box;margin:0;padding:0}}
body{{width:1600px;height:1000px;background:#0B0F17;font-family:Roboto,Arial,sans-serif;color:#E6EBF5;display:flex;overflow:hidden;-webkit-font-smoothing:antialiased}}
.nav{{width:220px;height:1000px;background:#121826;border-right:1px solid #1E293B;padding:20px 12px;flex:none}}
.brand{{font-size:15px;font-weight:700;padding:0 8px 18px;border-bottom:1px solid #1E293B;margin-bottom:10px;display:flex;align-items:center;gap:8px}}
.logo{{width:22px;height:22px;border-radius:6px;background:#7C9CFF;display:flex;align-items:center;justify-content:center;color:#0B0F17;font-size:12px;font-weight:800}}
.grp{{font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#8B96AD;padding:12px 8px 6px;display:flex;align-items:center}}
.chev{{width:14px;font-size:10px}}.cnt{{margin-left:auto;font-weight:500;color:#5B6680}}
.item{{font-size:13px;color:#C3CBDB;padding:6px 8px 6px 22px;border-radius:6px;margin:1px 0}}
.item.sel{{color:#7C9CFF;background:#1A2236;font-weight:700;box-shadow:inset 3px 0 0 #7C9CFF}}
.main{{flex:1;padding:24px;position:relative}}
.hdr{{display:flex;justify-content:space-between;align-items:flex-start}}
h1{{font-size:32px;font-weight:700;line-height:36px}}
.rl{{font-size:14px;color:#8B96AD;margin-top:6px}}
.upd{{font-size:12px;color:#8B96AD;background:#121826;border:1px solid #1E293B;border-radius:6px;padding:7px 12px;margin-top:4px}}
.upd b{{color:#E6EBF5;font-weight:500}}
.ctrls{{display:flex;gap:16px;margin:18px 0 16px}}
.dd{{width:220px;height:36px;background:#121826;border:1px solid #1E293B;border-radius:6px;display:flex;align-items:center;padding:0 12px;gap:8px;font-size:13px}}
.dd .dmut{{color:#8B96AD;margin-left:auto}}
.panel{{background:#121826;border:1px solid #1E293B;border-radius:8px;overflow:hidden}}
table{{width:100%;border-collapse:collapse;font-size:13px}}
th{{background:#121826;color:#8B96AD;font-weight:700;font-size:12px;text-align:left;padding:0 10px;height:38px;border-bottom:1px solid #1E293B;white-space:nowrap}}
th.num,td.num{{text-align:right}} th.c{{text-align:center}}
td{{height:39px;padding:0 10px;border-bottom:1px solid #1E293B;white-space:nowrap}}
.tk{{color:#7C9CFF;font-weight:700}} .mut{{color:#C3CBDB}}
.sc{{text-align:center;font-weight:700;width:64px}} .vd{{font-weight:700}}
.rk{{color:#8B96AD;width:40px}} .na{{color:#5B6680}}
td.num{{font-variant-numeric:tabular-nums}}
.sort{{color:#7C9CFF;font-size:10px;margin-left:4px}}
.foot{{display:flex;justify-content:flex-end;align-items:center;gap:14px;height:40px;padding:0 14px;font-size:12px;color:#8B96AD;border-top:1px solid #1E293B}}
.pg{{display:flex;gap:6px}} .pg span{{width:24px;height:24px;border:1px solid #1E293B;border-radius:6px;display:flex;align-items:center;justify-content:center;color:#E6EBF5;font-size:13px}}
.pg span.dis{{color:#3A4560}}
.tag{{position:absolute;right:24px;bottom:16px;font-size:11px;color:#8B96AD;background:#121826;border:1px dashed #2A3650;border-radius:6px;padding:5px 10px}}
</style></head><body>
<div class="nav"><div class="brand"><div class="logo">N</div>Nick's Stock Desk</div>{navh}</div>
<div class="main">
<div class="hdr"><div><h1>Top stocks</h1><div class="rl">Research only. Not a recommendation to buy or sell. This desk never places trades. Stocks only, no option contracts.</div></div>
<div class="upd">Updated <b>Oct 23, 2026</b></div></div>
<div class="ctrls">{dd}</div>
<div class="panel"><table><thead><tr><th class="num">#</th><th>Ticker</th><th>Company</th><th>Sector</th><th class="c">Score<span class="sort">&#9660;</span></th><th>Verdict</th>
<th class="num">Price</th><th class="num">Day %</th><th>Trend</th><th class="num">Entry low</th><th class="num">Entry high</th><th class="num">Stop</th><th class="num">Target</th></tr></thead>
<tbody>{body}</tbody></table>
<div class="foot"><span>1 - 25 / 523</span><div class="pg"><span class="dis">&#8249;</span><span>&#8250;</span></div></div></div>
<div class="tag">Sample picture, real data from Oct 23</div>
</div></body></html>'''
open("page.html","w").write(html)
