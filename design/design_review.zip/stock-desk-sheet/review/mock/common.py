"""Shared pieces for sample pictures. Nav, header and table look copied from gen.py (Top stocks sample)."""
import subprocess, os, html as H
NAV=[("Overview",["Today","Top stocks","Stock scorecard","Watchlist and portfolio","Alerts","Backtest"],True),
("Scanners",["Growth","Quality","Dividend","Wheel (stocks only)","VCP","CANSLIM","Box breakout","Flag breakout","Leaders"],True),
("Earnings",["x"]*3,False),("Sentiment",["x"]*8,False),("Financials",["x"]*4,False),("Macro",["x"]*3,False),
("Technicals",["x"]*7,False),("System",["Data updates","Help"],False)]
CSS='''*{box-sizing:border-box;margin:0;padding:0}
body{width:1600px;height:%dpx;background:#0B0F17;font-family:Roboto,Arial,sans-serif;color:#E6EBF5;display:flex;overflow:hidden;-webkit-font-smoothing:antialiased}
.nav{width:220px;height:%dpx;background:#121826;border-right:1px solid #1E293B;padding:20px 12px;flex:none}
.brand{font-size:15px;font-weight:700;padding:0 8px 18px;border-bottom:1px solid #1E293B;margin-bottom:10px;display:flex;align-items:center;gap:8px}
.logo{width:22px;height:22px;border-radius:6px;background:#7C9CFF;display:flex;align-items:center;justify-content:center;color:#0B0F17;font-size:12px;font-weight:800}
.grp{font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#8B96AD;padding:12px 8px 6px;display:flex;align-items:center}
.chev{width:14px;font-size:10px}.cnt{margin-left:auto;font-weight:500;color:#5B6680}
.item{font-size:13px;color:#C3CBDB;padding:6px 8px 6px 22px;border-radius:6px;margin:1px 0}
.item.sel{color:#7C9CFF;background:#1A2236;font-weight:700;box-shadow:inset 3px 0 0 #7C9CFF}
.main{flex:1;padding:24px;position:relative;min-width:0}
.hdr{display:flex;justify-content:space-between;align-items:flex-start}
h1{font-size:32px;font-weight:700;line-height:36px}
.rl{font-size:14px;color:#8B96AD;margin-top:6px}
.upd{font-size:12px;color:#8B96AD;background:#121826;border:1px solid #1E293B;border-radius:6px;padding:7px 12px;margin-top:4px;white-space:nowrap}
.upd b{color:#E6EBF5;font-weight:500}
.ctrls{display:flex;gap:16px;margin:18px 0 16px}
.dd{width:220px;height:36px;background:#121826;border:1px solid #1E293B;border-radius:6px;display:flex;align-items:center;padding:0 12px;gap:8px;font-size:13px}
.dd .dmut{color:#8B96AD;margin-left:auto;white-space:nowrap}
.panel{background:#121826;border:1px solid #1E293B;border-radius:8px;overflow:hidden}
.pad{padding:16px}
.ptitle{font-size:14px;font-weight:700;margin-bottom:4px}
.cap{font-size:12px;color:#8B96AD;line-height:17px}
table{width:100%%;border-collapse:collapse;font-size:13px}
th{background:#121826;color:#8B96AD;font-weight:700;font-size:12px;text-align:left;padding:0 10px;height:36px;border-bottom:1px solid #1E293B;white-space:nowrap}
th.num,td.num{text-align:right} th.c,td.c{text-align:center}
td{height:36px;padding:0 10px;border-bottom:1px solid #1E293B;white-space:nowrap}
td.wrap{white-space:normal;line-height:17px;padding-top:7px;padding-bottom:7px}
tr:nth-child(odd) td{background:#0F1420} tr:nth-child(even) td{background:#121826}
.tk{color:#7C9CFF;font-weight:700} .mut{color:#C3CBDB} .m2{color:#8B96AD}
.pill{font-weight:700;text-align:center;color:#E6EBF5}
.na{color:#D6A64A} td.num{font-variant-numeric:tabular-nums}
.sort{color:#7C9CFF;font-size:10px;margin-left:4px}
.foot{display:flex;justify-content:flex-end;align-items:center;gap:14px;height:40px;padding:0 14px;font-size:12px;color:#8B96AD;border-top:1px solid #1E293B}
.pg{display:flex;gap:6px} .pg span{width:24px;height:24px;border:1px solid #1E293B;border-radius:6px;display:flex;align-items:center;justify-content:center;color:#E6EBF5;font-size:13px}
.pg span.dis{color:#3A4560}
.tag{position:absolute;right:24px;bottom:16px;font-size:11px;color:#8B96AD;background:#121826;border:1px dashed #2A3650;border-radius:6px;padding:5px 10px}
.row{display:flex;gap:16px;margin-bottom:16px}
.card{background:#121826;border:1px solid #1E293B;border-radius:8px;padding:14px 16px;flex:1;min-width:0}
.card .l{font-size:12px;color:#8B96AD;white-space:nowrap}
.card .v{font-size:26px;font-weight:700;margin-top:6px;font-variant-numeric:tabular-nums;white-space:nowrap}
.card .s{font-size:12px;margin-top:4px;color:#8B96AD;white-space:nowrap}
.lg{display:flex;gap:14px;font-size:12px;color:#8B96AD;align-items:center}
.lg i{display:inline-block;width:14px;height:2px;margin-right:5px;vertical-align:middle}
'''
UP,DN,AM,AC,MU,TX="#22C55E","#EF4444","#F59E0B","#7C9CFF","#8B96AD","#E6EBF5"
NA_HTML='<span class="na">&ndash;</span>'
VC={"BUY":UP,"HOLD":AM,"AVOID":DN}
TC={"Uptrend":UP,"Downtrend":DN,"Extended":AM,"Sideways":MU}
def band(s):
    return "#166534" if s>=12 else "#14532D" if s>=9 else "#283146" if s>=5 else "#7F1D1D" if s>=1 else "#B91C1C"
def pts(v):
    if v is None: return None
    return "#166534" if v>=2 else "#14532D" if v>=1 else "#283146" if v>-1 else "#7F1D1D" if v>-2 else "#B91C1C"
def f(v,d=2,sign=False):
    if v in (None,""): return NA_HTML
    v=float(v); return (f"{v:+,.{d}f}" if sign else f"{v:,.{d}f}")
def retc(v):
    if v in (None,""): return MU
    v=float(v); return UP if v>0 else DN if v<0 else TX
def esc(s): return H.escape(str(s))
def nav(sel):
    h=""
    for g,items,o in NAV:
        h+=f'<div class="grp"><span class="chev">{"&#9662;" if o else "&#9656;"}</span>{g}<span class="cnt">{len(items)}</span></div>'
        if o:
            for it in items: h+=f'<div class="item{" sel" if it==sel else ""}">{it}</div>'
    return h
def controls(items):
    svg='<svg width="10" height="6" viewBox="0 0 10 6"><path d="M1 1l4 4 4-4" stroke="#8B96AD" stroke-width="1.5" fill="none"/></svg>'
    return '<div class="ctrls">'+"".join(f'<div class="dd"><span>{l}</span><span class="dmut">{v}</span>{svg}</div>' for l,v in items)+'</div>'
from nav_common import nav_html
def page(title,sel,ctrl,body,height=1000,tag="Sample picture. Real data from the Oct 23, 7:24 PM PT export. Dashes = value not available here",updated="Oct 23, 7:24 PM PT"):
    return f'''<!doctype html><html><head><meta charset="utf-8"><style>{CSS%(height,height)}</style></head><body>
{nav_html(sel,height=height)}
<div class="main"><div class="hdr"><div><h1>{title}</h1><div class="rl">Research only. Not a recommendation to buy or sell. This desk never places trades. Stocks only, no option contracts.</div></div>
<div class="upd">Updated <b>{updated}</b></div></div>{controls(ctrl) if ctrl else ""}{body}<div class="tag">{tag}</div></div></body></html>'''
def render(html,out,height):
    hp=os.path.join(os.path.dirname(os.path.abspath(__file__)),os.path.basename(out).replace(".png",".html")); open(hp,"w").write(html)
    subprocess.run(["google-chrome","--headless=new","--no-sandbox","--disable-gpu","--hide-scrollbars",f"--window-size=1600,{height}","--force-device-scale-factor=2",f"--screenshot={out}","file://"+os.path.abspath(hp)],check=True,capture_output=True)
    return out
def line_svg(series,w,h,ymin=None,ymax=None,refs=(),pad=(44,10,16,24),xlabels=None):
    """series: list of (values(list with None), color, width). refs: list of (value,color,label)."""
    L,T,R,B=pad
    allv=[v for s in series for v in s[0] if v is not None]+[r[0] for r in refs]
    lo=min(allv) if ymin is None else ymin; hi=max(allv) if ymax is None else ymax
    sp=(hi-lo) or 1; lo-=sp*0.04 if ymin is None else 0; hi+=sp*0.04 if ymax is None else 0
    n=max(len(s[0]) for s in series)
    X=lambda i:L+(w-L-R)*i/(n-1); Y=lambda v:T+(h-T-B)*(1-(v-lo)/(hi-lo))
    g=""
    for k in range(5):
        v=lo+(hi-lo)*k/4; y=Y(v)
        g+=f'<line x1="{L}" x2="{w-R}" y1="{y:.1f}" y2="{y:.1f}" stroke="#1E293B"/><text x="{L-6}" y="{y+4:.1f}" fill="#8B96AD" font-size="11" text-anchor="end">{v:,.0f}</text>'
    if xlabels:
        for i,lab in xlabels: g+=f'<text x="{X(i):.1f}" y="{h-6}" fill="#8B96AD" font-size="11" text-anchor="middle">{lab}</text>'
    lab_=""
    for ref in refs:
        v,c,lab=ref[:3]; pos=ref[3] if len(ref)>3 else "l"
        y=Y(v); tx=(w-R-6) if "r" in pos else L+6; anc="end" if "r" in pos else "start"; ty=y+13 if "b" in pos else y-4
        g+=f'<line x1="{L}" x2="{w-R}" y1="{y:.1f}" y2="{y:.1f}" stroke="{c}" stroke-dasharray="5 4" stroke-width="1"/>'
        lab_+=f'<text x="{tx}" y="{ty:.1f}" fill="{c}" font-size="11" text-anchor="{anc}" paint-order="stroke" stroke="#121826" stroke-width="3">{lab}</text>'
    for vals,c,sw in series:
        # linear interpolation over gaps (what the spec asks Looker to do)
        idx=[i for i,v in enumerate(vals) if v is not None]
        if not idx: continue
        pts_=" ".join(f"{X(i):.1f},{Y(vals[i]):.1f}" for i in idx)
        g+=f'<polyline points="{pts_}" fill="none" stroke="{c}" stroke-width="{sw}" stroke-linejoin="round"/>'
    return f'<svg width="{w}" height="{h}" viewBox="0 0 {w} {h}">{g}{lab_}</svg>'
