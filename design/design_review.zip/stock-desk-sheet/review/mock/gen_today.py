# Today page sample. Real values: /home/box/Downloads/data.csv (market_today export, updated 2026-10-23 19:24 PT)
# + looker_today_v2.png (sector bars and the 20-day breadth line, read off the chart pixels).
from nav_common import CSS, nav_html, header_html
import datetime as dt

# 20-day breadth line traced from looker_today_v2.png (x pixel -> y pixel; y=499 is 0%, 1.9875 px per point).
trace = {257:355,258:362,259:363,260:357,261:354,262:352,263:351,264:351,265:352,266:350,267:348,268:344,269:340,270:339,271:340,272:342,273:346,274:353,275:359,276:363,277:365,278:366,279:366,280:369,281:375,282:379,283:382,284:385,285:386,286:388,287:393,288:397,289:389,290:381,291:382,292:383,293:388,294:398,295:404,296:403,297:401,298:396,299:392,300:396,301:402,302:407,303:409,304:412,305:413,306:413,307:411,308:409,309:410,310:413,311:414,312:414,313:415,314:418,315:422,316:415,317:408,318:412,319:415,320:415,321:406,322:400,323:396,324:391,325:384,326:380,327:395,
373:407,374:389,375:385,376:382,377:381,378:380,379:378,380:376,381:373,382:370,383:369,384:370,385:372,386:372,387:371,388:368,389:365,390:364,391:364,392:363,393:365,394:366,395:370,396:378,397:383,398:381,399:379,400:377,401:375,402:375,403:375,404:377,405:382,406:386,407:390,408:391,409:380,410:371,411:376,412:382,413:387,414:391,415:394,416:397,417:399,418:402,419:406,420:409,421:410,422:401,423:393,424:386,425:378,426:371,427:367,428:363,429:367,430:373,431:377,432:382,433:387,434:390,435:390,436:384,437:377,438:368,439:361,440:361,441:364,442:367,443:369,444:371,445:369,446:367,447:368,448:369,449:371,450:370.5,451:370,452:369,453:366,454:362,455:360,456:360,457:361,458:363,459:371,460:379,461:385,462:390,463:389,464:388,465:389,466:398,467:402,468:399,469:396,470:393,471:392,472:392,473:393,474:393,475:391,476:392,477:400,478:408,479:410,480:411,481:413,482:416,483:421,484:428,485:431,486:425,487:420,488:414,489:406,490:409,491:419,492:434,
539:422,540:413,541:407,542:411,543:415,544:414,545:405,546:398,547:391,548:387,549:385,550:383,551:381,552:379,553:379,554:382,555:379,556:368,557:361,558:362,559:363,560:365,561:369,562:368,563:362,564:358,565:355,566:354,567:354,568:355,569:357,570:360}
X0, X1 = 257, 570
D0, D1 = dt.date(2026,4,9), dt.date(2026,10,23)
# chart geometry (inside the breadth panel)
PW, PH = 800, 380
L, R, T, B = 56, 24, 84, 60          # plot margins
pw, ph = PW-L-R, PH-T-B
def px(x): return L + (x-X0)/(X1-X0)*pw
def py(v): return T + ph - v/100*ph
segs, cur = [], []
for x in range(X0, X1+1):
    if x in trace:
        v = (499-trace[x])/1.9875
        cur.append(f"{px(x):.1f},{py(v):.1f}")
    elif cur:
        segs.append(cur); cur = []
if cur: segs.append(cur)
lines = "".join(f'<polyline points="{" ".join(s)}" fill="none" stroke="#7C9CFF" stroke-width="2" stroke-linejoin="round"/>' for s in segs)
grid = ""
for v in (0,25,50,75,100):
    grid += f'<line x1="{L}" x2="{PW-R}" y1="{py(v)}" y2="{py(v)}" stroke="#1E293B"/><text x="{L-10}" y="{py(v)+4}" fill="#8B96AD" font-size="11" text-anchor="end">{v}</text>'
span = (D1-D0).days
for m in range(5,11):
    d = dt.date(2026,m,1); x = L + (d-D0).days/span*pw
    grid += f'<text x="{x:.0f}" y="{PH-B+22}" fill="#8B96AD" font-size="11" text-anchor="middle">{d.strftime("%b")}</text>'
chips = ""
for lab, val, col in [("20-day","67.9%","#7C9CFF"),("50-day","&mdash;","#E6EBF5"),("100-day","&mdash;","#F59E0B"),("200-day","&mdash;","#8B96AD")]:
    chips += f'<div class="chip"><span class="dot" style="background:{col}"></span>{lab}<b>{val}</b></div>'
breadth = f'''<div class="panel" style="left:244px;top:230px;width:{PW}px;height:{PH}px">
<div class="ptitle">Market breadth</div><div class="psub">% of the 523 desk stocks above each average, 6 months</div>
<div class="chips">{chips}</div>
<svg width="{PW}" height="{PH}" style="position:absolute;left:0;top:0">{grid}{lines}</svg>
<div class="gapnote">Gaps = days with no breadth data (shown as breaks, not 0)</div></div>'''

# 11 SPDR sector ETFs, day % read off the current sector bar (+/- 0.05)
sect = [("Energy",2.58),("Technology",0.50),("Real Estate",0.11),("Utilities",-0.71),("Materials",-0.73),
        ("Health Care",-1.11),("Industrials",-1.26),("Financials",-1.32),("Discretionary",-1.64),("Communication",-1.78),("Staples",-1.91)]
SW, SH = 516, 380
lab_w, val_w = 104, 40
bx0 = 16+lab_w; bx1 = SW-16-val_w
vmin, vmax = -2.6, 3.2
def sx(v): return bx0 + (v-vmin)/(vmax-vmin)*(bx1-bx0)
rowh = (SH-72-36)/len(sect)
bars = f'<line x1="{sx(0):.1f}" x2="{sx(0):.1f}" y1="70" y2="{SH-30}" stroke="#2A3650"/>'
for i,(n,v) in enumerate(sect):
    y = 72 + i*rowh; bh = 14; yy = y + (rowh-bh)/2
    col = "#16A34A" if v>=0 else "#DC2626"
    col = "#1F9D55" if v>=0 else "#D14343"
    x = min(sx(0), sx(v)); w = abs(sx(v)-sx(0))
    tc = "#22C55E" if v>=0 else "#EF4444"
    bars += f'<text x="{16+lab_w-10}" y="{yy+11}" fill="#C3CBDB" font-size="12" text-anchor="end">{n}</text>'
    bars += f'<rect x="{x:.1f}" y="{yy:.1f}" width="{max(w,2):.1f}" height="{bh}" rx="3" fill="{col}"/>'
    lx = sx(v)+6 if v>=0 else sx(v)-6
    bars += f'<text x="{lx:.1f}" y="{yy+11}" fill="{tc}" font-size="11" font-weight="500" text-anchor="{"start" if v>=0 else "end"}">{v:+.1f}%</text>'
for v in (-2,-1,0,1,2,3):
    pass
for v in (-2,-1,0,1,2,3):
    bars += f'<text x="{sx(v):.1f}" y="{SH-12}" fill="#5B6680" font-size="10" text-anchor="middle">{v:+d}%</text>'.replace("+0%","0%")
sector = f'''<div class="panel" style="left:1060px;top:230px;width:{SW}px;height:{SH}px">
<div class="ptitle">Sectors today</div><div class="psub">Day % change, 11 S&amp;P sector ETFs</div>
<svg width="{SW}" height="{SH}" style="position:absolute;left:0;top:0">{bars}</svg></div>'''

# Top 5 sectors (of the 19 in `sectors`) by day %
top5 = [("Energy",2.58),("Oil and Gas",2.45),("Semiconductors",0.73),("Technology",0.50),("Real Estate",0.11)]
mx = 2.58
rows = ""
for i,(n,v) in enumerate(top5):
    bg = "#0F1420" if i%2==0 else "#121826"
    rows += f'<tr style="background:{bg}"><td class="rk">{i+1}</td><td>{n}</td><td class="num" style="color:#22C55E">{v:+.2f}%</td><td><div class="mbar"><div style="width:{v/mx*100:.0f}%"></div></div></td></tr>'
topt = f'''<div class="panel" style="left:244px;top:634px;width:520px;height:342px">
<div class="ptitle">Top 5 sectors today</div><div class="psub">Best day % of the 19 sector and industry ETFs</div>
<table class="t" style="position:absolute;left:0;right:0;top:72px"><thead><tr><th style="width:40px">#</th><th>Sector</th><th class="num" style="width:90px">Day %</th><th style="width:170px"></th></tr></thead><tbody>{rows}</tbody></table></div>'''

arows = ""
for i in range(8):
    bg = "#0F1420" if i%2==0 else "#121826"
    arows += f'<tr style="background:{bg}" class="ph"><td>&mdash;</td><td>&mdash;</td><td class="num">&mdash;</td><td>&mdash;</td></tr>'
alerts = f'''<div class="panel" style="left:780px;top:634px;width:796px;height:342px">
<div class="ptitle">Latest alerts</div><div class="psub">Changes since the previous run. Nothing is emailed and nothing is sent to a broker.</div>
<div class="viewall">All alerts &rsaquo;</div>
<table class="t sm" style="position:absolute;left:0;right:0;top:72px"><thead><tr><th style="width:90px">Ticker</th><th>What changed</th><th class="num" style="width:110px">Score</th><th style="width:120px">Verdict</th></tr></thead><tbody>{arows}</tbody></table></div>'''

cards = [
 ("S&amp;P 500","759.97",None,'<span style="color:#EF4444">&#9660; 0.52% today</span>'),
 ("% above 50-day","&mdash;",None,'<span class="m">vs week ago &mdash;</span>'),
 ("Advancers / decliners",'<span style="color:#22C55E">144</span><span class="sl"> / </span><span style="color:#EF4444">378</span>',None,'<span class="m">of 523 stocks</span>'),
 ("New 52-week highs","14",None,'<span class="m">5 new lows</span>'),
 ("Put/call mood",'<span style="color:#F59E0B">Greed</span>',None,'<span class="m">0.69 today &middot; 5-day 0.59</span>'),
 ("VIX","19.45",None,'<span class="m">fear gauge</span>'),
 ("10-year yield","4.96%",None,'<span class="m">10y&ndash;2y 0.31</span>'),
]
cw = (1332-6*16)/7
ch = ""
for i,(lab,val,_,sub) in enumerate(cards):
    ch += f'<div class="card" style="left:{244+i*(cw+16):.1f}px;width:{cw:.1f}px"><div class="cl">{lab}</div><div class="cv">{val}</div><div class="cs">{sub}</div></div>'

html = f'''<!doctype html><html><head><meta charset="utf-8"><style>{CSS}
body{{width:1600px;height:1000px;position:relative}}
.nav{{position:absolute;left:0;top:0}}
.main{{position:absolute;left:244px;top:24px;width:1332px}}
.card{{position:absolute;top:110px;height:96px;background:#121826;border:1px solid #1E293B;border-radius:8px;padding:14px 16px}}
.cl{{font-size:11px;line-height:14px;font-weight:700;letter-spacing:.05em;text-transform:uppercase;color:#8B96AD;white-space:nowrap}}
.cv{{font-size:27px;line-height:32px;font-weight:500;margin-top:6px;font-variant-numeric:tabular-nums;white-space:nowrap}}
.cv .sl{{color:#5B6680;font-weight:400}}
.cs{{font-size:12px;line-height:16px;margin-top:2px;white-space:nowrap}} .m{{color:#8B96AD}}
.panel{{position:absolute;background:#121826;border:1px solid #1E293B;border-radius:8px;overflow:hidden}}
.ptitle{{position:absolute;left:16px;top:14px;font-size:15px;font-weight:700}}
.psub{{position:absolute;left:16px;top:36px;font-size:12px;color:#8B96AD}}
.chips{{position:absolute;right:16px;top:16px;display:flex;gap:8px}}
.chip{{font-size:12px;color:#8B96AD;background:#0F1420;border:1px solid #1E293B;border-radius:6px;padding:5px 9px;display:flex;align-items:center;gap:6px;white-space:nowrap}}
.chip b{{color:#E6EBF5;font-weight:500}} .dot{{width:8px;height:8px;border-radius:4px;display:inline-block}}
.gapnote{{position:absolute;right:24px;bottom:10px;font-size:11px;color:#5B6680}}
table.t{{border-collapse:collapse;font-size:13px;width:100%}}
.t th{{color:#8B96AD;font-weight:700;font-size:12px;text-align:left;padding:0 16px;height:36px;border-bottom:1px solid #1E293B;border-top:1px solid #1E293B}}
.t td{{height:44px;padding:0 16px;border-bottom:1px solid #1E293B;white-space:nowrap}}
.t.sm td{{height:29px}}
.t th.num,.t td.num{{text-align:right;font-variant-numeric:tabular-nums}}
.t .rk{{color:#8B96AD}}
.t tr.ph td{{color:#5B6680}}
.mbar{{height:8px;background:#1A2236;border-radius:4px;overflow:hidden}} .mbar div{{height:8px;background:#1F9D55;border-radius:4px}}
.viewall{{position:absolute;right:16px;top:16px;font-size:12px;color:#7C9CFF}}
</style></head><body>
{nav_html("Today")}
<div class="main">{header_html("Today","Oct 23, 7:24 PM PT")}</div>
{ch}{breadth}{sector}{topt}{alerts}
<div class="tag" style="bottom:4px;right:24px;font-size:10px;padding:2px 8px">Sample picture. Real data from the Oct 23, 7:24 PM PT export. Dashes = value not available here</div>
</body></html>'''
open("today.html","w").write(html)
