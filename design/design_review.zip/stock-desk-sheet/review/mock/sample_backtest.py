import csv,sys
sys.path.insert(0,'.')
from common import *
D='/workspace/nsd-repo/data/'
R=lambda f:list(csv.DictReader(open(D+f)))
sm=[r for r in R('backtest_summary.csv') if r['is_headline']=='yes'][0]
eq=R('backtest_equity.csv'); bk=[r for r in R('backtest_buckets.csv') if r['horizon']=='12w']; yr=R('backtest_yearly.csv'); nt=R('backtest_notes.csv')
H=1500
head=f'''<div class="panel pad" style="margin-bottom:16px"><div style="font-size:22px;font-weight:500">{esc(sm["headline"])}</div><div class="cap" style="margin-top:6px">From {sm["start"]} to {sm["end"]} &middot; {sm["months"]} months &middot; every month, buy the 20 highest-scoring stocks, compare with the S&amp;P 500.</div></div>'''
def card(l,v,c=TX): return f'<div class="card"><div class="l">{l}</div><div class="v" style="color:{c}">{v}</div></div>'
cards='<div class="row">'+card("Top-20 yearly pace %",f(sm['top20_cagr_pct'],1))+card("S&amp;P 500 yearly pace %",f(sm['spy_cagr_pct'],1))+card("Worst drop, top 20 %",f(sm['top20_max_drawdown_pct'],1),DN)+card("12-week hit rate %",f(sm['hit_rate_12w_pct'],1))+'</div>'
t20=[float(r['top20']) for r in eq]; sp=[float(r['spy']) for r in eq]; b20=[float(r['bottom20']) for r in eq]
xl=[(i,eq[i]['date'][:4]) for i in range(len(eq)) if eq[i]['date'][5:7]=='12']
svg=line_svg([(b20,DN,1.8),(sp,TX,1.8),(t20,UP,2.2)],830,300,xlabels=xl)
line=f'''<div class="panel pad" style="width:880px;flex:none"><div style="display:flex;justify-content:space-between"><div class="ptitle">Growth of 10,000, monthly test</div><div class="lg"><span><i style="background:{UP}"></i>Top 20 by score</span><span><i style="background:{TX}"></i>S&amp;P 500</span><span><i style="background:{DN}"></i>Bottom 20</span></div></div>{svg}
<div class="cap">Last point: top 20 {t20[-1]:,.0f} &middot; S&amp;P 500 {sp[-1]:,.0f} &middot; bottom 20 {b20[-1]:,.0f}. First row (2022-09-30) is already {t20[0]:,.0f}.</div></div>'''
# bucket column chart
vals=[(r['bucket'],r['excess_pct'],int(r['n'])) for r in sorted(bk,key=lambda r:-int(r['n']))]
W=380;base=70;sc=150/1.5;bars=""
for i,(b,e,n) in enumerate(vals):
    x=24+i*58
    if e=='':
        bars+=f'<text x="{x+18}" y="{base+16}" fill="#D6A64A" font-size="12" text-anchor="middle">&ndash;</text>'
    else:
        e=float(e); hgt=abs(e)*sc; y=base if e<0 else base-hgt
        bars+=f'<rect x="{x}" y="{y}" width="36" height="{hgt}" rx="2" fill="{UP if e>0 else DN}"/><text x="{x+18}" y="{y+hgt+14 if e<0 else y-5}" fill="#E6EBF5" font-size="11" text-anchor="middle">{e:+.2f}</text>'
    bars+=f'<text x="{x+18}" y="292" fill="#8B96AD" font-size="11" text-anchor="middle">{esc(b)}</text>'
bar=f'''<div class="panel pad" style="flex:1;min-width:0"><div class="ptitle">Excess return vs S&amp;P 500 by score bucket</div><div class="cap">12-week horizon, % per signal. Score at signal along the bottom.</div><svg width="{W}" height="300"><line x1="14" x2="{W-10}" y1="{base}" y2="{base}" stroke="#334155"/>{bars}</svg></div>'''
def rc(v,d=2): return f'<td class="num" style="color:{retc(v)}">{f(v,d,True)}</td>' if v!='' else f'<td class="num">{NA_HTML}</td>'
brows="".join(f'<tr><td>{esc(r["bucket"])}</td><td class="num">{int(r["n"]):,}</td>{rc(r["avg_return_pct"])}{rc(r["avg_spy_pct"])}{rc(r["excess_pct"])}<td class="num">{f(r["hit_rate_pct"],1) if r["hit_rate_pct"] else NA_HTML}</td></tr>' for r in sorted(bk,key=lambda r:-int(r['n'])))
btab=f'''<div class="panel" style="width:880px;flex:none"><div class="pad" style="padding-bottom:6px"><div class="ptitle">Score buckets, 12 weeks</div></div><table><thead><tr><th>Score bucket</th><th class="num">Signals</th><th class="num">Avg return %</th><th class="num">S&amp;P same period %</th><th class="num">Excess %</th><th class="num">Hit rate %</th></tr></thead><tbody>{brows}</tbody></table></div>'''
yrows="".join(f'<tr><td>{r["year"]}</td>{rc(r["top20_pct"])}{rc(r["spy_pct"])}{rc(r["difference_pct"])}<td class="num">{int(r["signals"]):,}</td></tr>' for r in yr)
ytab=f'''<div class="panel" style="flex:1;min-width:0"><div class="pad" style="padding-bottom:6px"><div class="ptitle">Year by year</div><div class="cap">2026 is the year so far.</div></div><table><thead><tr><th>Year<span class="sort">&#9650;</span></th><th class="num">Top 20 %</th><th class="num">S&amp;P 500 %</th><th class="num">Difference %</th><th class="num">Signals</th></tr></thead><tbody>{yrows}</tbody></table></div>'''
nrows="".join(f'<tr><td style="width:300px;font-weight:700">{esc(r["item"])}</td><td class="wrap">{esc(r["detail"])}</td></tr>' for r in nt)
ntab=f'<div class="panel"><div class="pad" style="padding-bottom:6px"><div class="ptitle">Test limits, read before trusting the score</div></div><table><thead><tr><th>What was tested</th><th>Detail</th></tr></thead><tbody>{nrows}</tbody></table></div>'
body=head+cards+f'<div class="row">{line}{bar}</div><div class="row">{btab}{ytab}</div>'+ntab
html=page("Backtest","Backtest",[("Test window","5y"),("Horizon","12w")],body,H)
render(html,'/workspace/stock-desk-sheet/review/sample_backtest.png',H); print('ok')
