# Shared nav + header for all Stock Desk samples (same CSS as the approved Top stocks sample,
# with fixed line-heights so the Looker build can copy exact pixel positions).
NAV = [
 ("Overview", ["Today","Top stocks","Stock scorecard","Watchlist and portfolio","Alerts","Backtest"]),
 ("Scanners", ["Growth","Quality","Dividend","Wheel (stocks only)","VCP","CANSLIM","Box breakout","Flag breakout","Leaders"]),
 ("Earnings", ["Calendar","Strength heatmap","Report cards"]),
 ("Sentiment", ["Put/call ratio","Put and call walls","Analyst ratings","13F tracker","AAII","Insider trading","Headline sentiment","XLY/XLP"]),
 ("Financials", ["Summary","Earnings tracker","Company financials","Dividend fundamentals"]),
 ("Macro", ["Macro screener","Sector macro scores","Historical P/E"]),
 ("Technicals", ["52-week breakouts","Trends","Pullbacks","Gainers and losers","Breadth","Sector performance","Heatmaps"]),
 ("System", ["Data updates","Help"]),
]
CSS = """
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0B0F17;font-family:Roboto,Arial,sans-serif;color:#E6EBF5;-webkit-font-smoothing:antialiased;overflow:hidden}
.nav{width:220px;background:#121826;border-right:1px solid #1E293B;padding:20px 12px;flex:none}
.brand{font-size:15px;font-weight:700;height:40px;padding:0 8px 18px;border-bottom:1px solid #1E293B;margin-bottom:10px;display:flex;align-items:center;gap:8px}
.logo{width:22px;height:22px;border-radius:6px;background:#7C9CFF;display:flex;align-items:center;justify-content:center;color:#0B0F17;font-size:12px;font-weight:800}
.grp{font-size:11px;line-height:13px;height:31px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#8B96AD;padding:12px 8px 6px;display:flex;align-items:center}
.chev{width:14px;font-size:10px}.cnt{margin-left:auto;font-weight:500;color:#5B6680}
.item{font-size:13px;line-height:16px;height:28px;color:#C3CBDB;padding:6px 8px 6px 22px;border-radius:6px;margin:1px 0;white-space:nowrap}
.item.sel{color:#7C9CFF;background:#1A2236;font-weight:700;box-shadow:inset 3px 0 0 #7C9CFF}
.hdr{display:flex;justify-content:space-between;align-items:flex-start}
h1{font-size:32px;font-weight:700;line-height:36px}
.rl{font-size:14px;line-height:20px;color:#8B96AD;margin-top:6px}
.upd{font-size:12px;color:#8B96AD;background:#121826;border:1px solid #1E293B;border-radius:6px;padding:7px 12px;margin-top:4px;white-space:nowrap}
.upd b{color:#E6EBF5;font-weight:500}
.dd{width:220px;height:36px;background:#121826;border:1px solid #1E293B;border-radius:6px;display:flex;align-items:center;padding:0 12px;gap:8px;font-size:13px}
.dd .dmut{color:#8B96AD;margin-left:auto}
.tag{position:absolute;right:24px;bottom:16px;font-size:11px;color:#8B96AD;background:#121826;border:1px dashed #2A3650;border-radius:6px;padding:5px 10px}
"""
RESEARCH = "Research only. Not a recommendation to buy or sell. This desk never places trades. Stocks only, no option contracts."

def nav_html(selected, open_group=None, height=1000, extra_cls=""):
    if open_group is None:
        open_group = next(g for g, items in NAV if selected in items)
    h = ""
    for g, items in NAV:
        o = (g == open_group)
        h += f'<div class="grp"><span class="chev">{"&#9662;" if o else "&#9656;"}</span>{g}<span class="cnt">{len(items)}</span></div>'
        if o:
            for it in items:
                h += f'<div class="item{" sel" if it == selected else ""}">{it}</div>'
    return f'<div class="nav {extra_cls}" style="height:{height}px"><div class="brand"><div class="logo">N</div>Nick\'s Stock Desk</div>{h}</div>'

def header_html(title, updated="Oct 23, 2026"):
    return (f'<div class="hdr"><div><h1>{title}</h1><div class="rl">{RESEARCH}</div></div>'
            f'<div class="upd">Updated <b>{updated}</b></div></div>')
