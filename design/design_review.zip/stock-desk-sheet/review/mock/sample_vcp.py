import csv,sys
sys.path.insert(0,'.')
from common import *
D='/workspace/nsd-repo/data/'
R=lambda f:list(csv.DictReader(open(D+f)))
v=R('scanner_vcp.csv')
H=1000
cnt=lambda fn:sum(1 for r in v if fn(r))
def card(l,n): return f'<div class="card"><div class="l">{l}</div><div class="v">{n}</div></div>'
cards='<div class="row">'+card("Broken out today",cnt(lambda r:r['status']=='BROKEN OUT today'))+card("Ready",cnt(lambda r:r['status']=='READY'))+card("Watching",cnt(lambda r:r['status']=='WATCHING'))+card("In a trade (buy printed)",cnt(lambda r:r['in_trade']=='yes'))+'</div>'
sel=[r for r in v if r['status'] in ('READY','BROKEN OUT today')]
sel=sorted(sel,key=lambda r:(r['status'],-float(r['strength'])))
STC={"BROKEN OUT today":UP,"READY":AM,"WATCHING":MU}; FC={"FRESH":MU,"PARTIAL":AM,"STALE":DN}
def bar(x):
    x=float(x); return f'<td><div style="display:flex;align-items:center;gap:8px"><div style="width:70px;height:8px;background:#1E293B;border-radius:4px"><div style="width:{x*0.7:.0f}px;height:8px;background:{AC};border-radius:4px"></div></div><span>{x:.0f}</span></div></td>'
rows="".join(f'''<tr><td class="tk">{r["ticker"]}</td><td class="m2">{r["index_membership"]}</td><td style="color:{STC[r["status"]]};font-weight:700">{r["status"]}</td><td class="num">{f(r["price"])}</td><td class="num">{f(r["pivot"])}</td><td class="num" style="color:{DN}">{f(r["stop"])}</td><td class="num" style="color:{UP}">{f(r["target"])}</td><td class="num">{f(r["trail"])}</td>{bar(r["strength"])}<td class="c">{r["trend_score"]}</td><td class="c">{r["contractions"]}</td><td>{r["depths"]}</td><td style="color:{FC[r["freshness"]]}">{r["freshness"].title()}</td></tr>''' for r in sel)
tab=f'''<div class="panel" style="margin-bottom:16px"><table><thead><tr><th>Ticker</th><th>Index</th><th>Status<span class="sort">&#9650;</span></th><th class="num">Price</th><th class="num">Buy point</th><th class="num">Stop</th><th class="num">Target</th><th class="num">20-day trail</th><th>Strength<span class="sort">&#9660;</span></th><th class="c">Trend template</th><th class="c">Pullbacks</th><th>Pullback depths %</th><th>Data</th></tr></thead><tbody>{rows}</tbody></table>
<div class="foot"><span>1 - {len(sel)} / {len(sel)}</span><div class="pg"><span class="dis">&#8249;</span><span class="dis">&#8250;</span></div></div></div>'''
top=sorted(sel,key=lambda r:-float(r['strength']))
why="".join(f'<tr><td class="tk" style="vertical-align:top;padding-top:9px">{r["ticker"]}</td><td class="wrap">{esc(r["reason"])}</td></tr>' for r in top[:2])
whyp=f'<div class="panel" style="flex:1;min-width:0"><div class="pad" style="padding-bottom:6px"><div class="ptitle">Why this name</div><div class="cap">Click a row in the table to read its full reason.</div></div><table><tbody>{why}</tbody></table></div>'
labs=["Above 150d &amp; 200d","150d over 200d","200d rising","50d over 150d &amp; 200d","Above 50d","30%+ over 52w low","Within 25% of 52w high","Beats S&amp;P 6m &amp; 12m"]
rh="".join(f'<th class="c" style="white-space:normal;line-height:13px;font-size:11px;padding:4px 4px;height:46px">{l}</th>' for l in labs)
rr="".join('<tr><td class="tk">'+r['ticker']+'</td>'+"".join(f'<td class="c" style="color:{UP if r["r"+str(i)]=="PASS" else DN};font-weight:700;font-size:12px;padding:0 4px">{r["r"+str(i)]}</td>' for i in range(1,9))+'</tr>' for r in top)
rulep=f'<div class="panel" style="flex:1;min-width:0"><div class="pad" style="padding-bottom:6px"><div class="ptitle">Trend template, 8 rules</div></div><table style="table-layout:fixed"><thead><tr><th style="width:70px">Ticker</th>{rh}</tr></thead><tbody>{rr}</tbody></table></div>'
note=f'<div class="cap" style="margin-top:2px">{esc(v[0]["note"])}</div>'
body=cards+tab+f'<div class="row">{whyp}{rulep}</div>'+note
html=page("VCP","VCP",[("Status","READY, BROKEN OUT"),("In a trade","All"),("Index","All"),("Ticker","All")],body,H)
render(html,'/workspace/stock-desk-sheet/review/sample_vcp.png',H); print('ok',len(sel))
