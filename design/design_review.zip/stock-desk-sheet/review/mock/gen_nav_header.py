from nav_common import CSS, NAV, nav_html, header_html
def two_level(selected, height):
    grp = next(g for g, items in NAV if selected in items)
    h = '<div class="grp" style="padding-left:8px">Sections</div>'
    for g, items in NAV:
        h += f'<div class="item{" gsel" if g==grp else ""}" style="padding-left:8px">{g}<span class="icnt">{len(items)}</span></div>'
    h += '<div class="div2"></div>'
    h += f'<div class="grp" style="padding-left:8px">{grp}</div>'
    for it in dict(NAV)[grp]:
        h += f'<div class="item{" sel" if it==selected else ""}" style="padding-left:16px">{it}</div>'
    return f'<div class="nav mini" style="height:{height}px"><div class="brand"><div class="logo">N</div>Nick\'s Stock Desk</div>{h}</div>'

dd = ""
for l in ["Ticker","Sector","Verdict"]:
    dd += f'<div class="dd"><span>{l}</span><span class="dmut">All</span><svg width="10" height="6" viewBox="0 0 10 6"><path d="M1 1l4 4 4-4" stroke="#8B96AD" stroke-width="1.5" fill="none"/></svg></div>'

def rail(label, sub, inner, x):
    return f'<div class="col" style="left:{x}px"><div class="clab">{label}</div><div class="csub">{sub}</div>{inner}</div>'
X = 244
cols = (rail("On VCP", "Scanners open, VCP selected", nav_html("VCP", height=600, extra_cls="mini"), X) +
        rail("On AAII", "Sentiment open, AAII selected", nav_html("AAII", height=600, extra_cls="mini"), X+244) +
        rail("On Help", "System open, Help selected", nav_html("Help", height=600, extra_cls="mini"), X+488) +
        rail("Option B: two-level", "Sections fixed, pages listed below", two_level("AAII", 600), X+732))

spec = '''<div class="spec"><div class="sh">Measurements (canvas px)</div>
<table>
<tr><td>Nav rail</td><td>x 0, w 220, full height, #121826</td></tr>
<tr><td>Rail border</td><td>1 px #1E293B</td></tr>
<tr><td>Brand</td><td>15 bold #E6EBF5, logo 22&times;22 #7C9CFF r6</td></tr>
<tr><td>Group label</td><td>11 bold CAPS #8B96AD, h 31</td></tr>
<tr><td>Count</td><td>11 #5B6680, right edge x 200</td></tr>
<tr><td>Page item</td><td>13 #C3CBDB, text x 34, h 28, pitch 29</td></tr>
<tr><td>Selected pill</td><td>x 12, w 195, h 28, #1A2236 r6</td></tr>
<tr><td>Accent bar</td><td>x 12, w 3, h 28, #7C9CFF</td></tr>
<tr><td>Selected text</td><td>13 bold #7C9CFF</td></tr>
<tr><td>Hover</td><td>not possible in Looker</td></tr>
<tr><td>Content</td><td>starts x 244 (24 px gap)</td></tr>
</table>
<div class="pz"><div class="pzl">Selected state, enlarged</div><div class="zoom"><div class="zi">Top stocks</div></div></div></div>'''

html = f'''<!doctype html><html><head><meta charset="utf-8"><style>{CSS}
body{{width:1600px;height:1000px;position:relative}}
.nav{{position:absolute;left:0;top:0}}
.nav.mini{{position:relative;border:1px solid #1E293B;border-radius:8px}}
.board{{position:absolute;left:244px;top:24px;width:1332px}}
.bt{{font-size:13px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#7C9CFF}}
.frame{{position:relative;margin-top:10px;border:1px dashed #2A3650;border-radius:8px;padding:24px;height:196px}}
.ctrls{{display:flex;gap:16px;margin-top:20px}}
.ann{{position:absolute;font-size:11px;color:#7C9CFF;white-space:nowrap}}
.ann.r{{text-align:right}}
.col{{position:absolute;top:300px;width:220px}}
.clab{{font-size:14px;font-weight:700;margin-bottom:2px}}
.csub{{font-size:12px;color:#8B96AD;margin-bottom:10px}}
.item.gsel{{color:#E6EBF5;background:#1A2236;font-weight:700}}
.icnt{{float:right;color:#5B6680;font-size:11px}}
.div2{{height:1px;background:#1E293B;margin:10px 0 0}}
.spec{{position:absolute;left:1220px;top:300px;width:356px;background:#121826;border:1px solid #1E293B;border-radius:8px;padding:16px}}
.sh{{font-size:14px;font-weight:700;margin-bottom:10px}}
.spec table{{border-collapse:collapse;font-size:12px;width:100%}}
.spec td{{padding:6px 0;border-bottom:1px solid #1E293B;vertical-align:top}}
.spec td:first-child{{color:#8B96AD;width:100px}}
.pz{{margin-top:14px}} .pzl{{font-size:11px;color:#8B96AD;margin-bottom:8px}}
.zoom{{background:#121826;border:1px solid #1E293B;border-radius:8px;padding:12px}}
.zi{{height:42px;line-height:42px;border-radius:9px;background:#1A2236;box-shadow:inset 4px 0 0 #7C9CFF;color:#7C9CFF;font-weight:700;font-size:19px;padding-left:30px}}
</style></head><body>
{nav_html("Today")}
<div class="board">
<div class="bt">Shared header, same on every page</div>
<div class="frame">{header_html("Top stocks","Oct 23, 7:24 PM PT")}<div class="ctrls">{dd}</div>
<div class="ann" style="left:24px;top:2px">Title: 32 bold #E6EBF5, x 244, y 24, h 36</div>
<div class="ann" style="left:24px;top:94px">Research line: 14 #8B96AD, y 66, h 20</div>
<div class="ann r" style="right:24px;top:62px">Updated chip: 12, right edge x 1576, y 28, h 30</div>
<div class="ann" style="left:24px;top:166px">Filters row (only on pages that need it): y 106, h 36, w 220, 16 px gaps, left to right in priority order</div>
</div>
<div class="bt" style="position:absolute;top:252px">Navigation: only the current group is open (recommended)</div>
</div>
{cols}{spec}
<div class="tag" style="bottom:12px">Sample picture, nav and header design. Real page names from LOOKER_SPEC.md</div>
</body></html>'''
open("nav_header.html","w").write(html)
