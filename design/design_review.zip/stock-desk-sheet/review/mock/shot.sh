#!/bin/bash
# usage: shot.sh page.html out.png  (1600x1000 CSS px at 2x = 3200x2000)
google-chrome --headless=new --no-sandbox --disable-gpu --hide-scrollbars --force-device-scale-factor=2 \
  --window-size=1600,1000 --screenshot="$2" "file://$(realpath $1)" 2>/dev/null
