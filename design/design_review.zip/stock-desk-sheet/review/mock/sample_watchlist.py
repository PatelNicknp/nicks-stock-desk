import csv,sys
sys.path.insert(0,'.')
from common import *
D='/workspace/nsd-repo/data/'
R=lambda f:list(csv.DictReader(open(D+f)))
ps=R('portfolio_summary.csv')[0]; pf=R('portfolio.csv'); wl=R('watchlist.csv')
H=1040
def usd(v,d=0,sign=False):
    v=float(v); s=f"{abs(v):,.{d}f}"; return (("+" if v>0 else "-" if v<0 else "") if sign else ("-" if v<0 else ""))+"$"+s
def card(l,v,c,sub,subc=MU):
    return f'<div class="card"><div class="l">{l}</div><div class="v" style="color:{c}">{v}</div><div class="s" style="color:{subc}">{sub}</div></div>'
warn=f'<div style="height:34px;border:1px solid {AM};border-radius:6px;background:#121826;display:flex;align-items:center;padding:0 14px;font-size:13px;color:{AM};margin-bottom:16px">{esc(ps["example_warning"])}</div>'
cards='<div class="row">'+card("Portfolio value",usd(ps['value']),TX,f'{ps["n_holdings"]} holdings')+card("Day P/L",usd(ps['day_pnl'],2,True),retc(ps['day_pnl']),f'{float(ps["day_pnl_pct"]):+.2f}%',retc(ps['day_pnl_pct']))+card("Total gain",usd(ps['total_gain'],0,True),retc(ps['total_gain']),f'{float(ps["total_gain_pct"]):+.2f}%',retc(ps['total_gain_pct']))+card("Average desk score",f'{float(ps["avg_score"]):.1f}',TX,f'<b style="color:{AM}">{ps["needs_attention"]}</b> needs attention')+'</div>'
SC={"Below stop":DN,"Weakening":AM,"Earnings soon":AC,"On track":MU}
pf=sorted(pf,key=lambda r:-float(r['weight_pct']))
rows=""
for r in pf:
    sc=int(float(r['score']))
    rows+=f'''<tr><td class="tk">{r["ticker"]}</td><td class="num">{float(r["shares"]):.0f}</td><td class="num">{f(r["avg_cost"])}</td><td class="num">{f(r["price"])}</td><td class="num">{usd(r["value"])}</td>
<td class="num" style="color:{retc(r["gain"])}">{usd(r["gain"],0,True)}</td><td class="num" style="color:{retc(r["gain_pct"])}">{f(r["gain_pct"],1,True)}</td><td class="num">{f(r["weight_pct"],1)}</td>
<td class="pill" style="background:{band(sc)}">{sc}</td><td class="c">{f(r["score_week_change"],0,True)}</td><td style="color:{VC[r["verdict"]]};font-weight:700">{r["verdict"]}</td><td class="num">{f(r["stop"])}</td><td style="color:{SC.get(r["status"],TX)};font-weight:700">{r["status"]}</td></tr>'''
hold=f'''<div class="panel" style="margin-bottom:16px"><div class="pad" style="padding-bottom:6px;display:flex;justify-content:space-between"><div class="ptitle">My holdings</div><div class="cap">{len(pf)} holdings &middot; example rows</div></div><table><thead><tr><th>Ticker</th><th class="num">Shares</th><th class="num">Avg cost</th><th class="num">Price</th><th class="num">Value</th><th class="num">Gain</th><th class="num">Gain %</th><th class="num">Weight %<span class="sort">&#9660;</span></th><th class="c">Score</th><th class="c">Score vs week ago</th><th>Verdict</th><th class="num">Stop</th><th>Status</th></tr></thead><tbody>{rows}</tbody></table></div>'''
wl=sorted(wl,key=lambda r:-float(r['score']))
def dist(v):
    if v=='': return f'<td class="num">{NA_HTML}</td>'
    x=float(v); return f'<td class="num" style="color:{UP if x==0 else AM if x>0 else DN}">{x:+.2f}</td>'
wrows="".join(f'''<tr><td class="tk">{r["ticker"]}</td><td>{esc(r["company"])}</td><td class="num">{f(r["price"])}</td><td class="num" style="color:{retc(r["day_pct"])}">{f(r["day_pct"],2,True)}</td><td class="pill" style="background:{band(int(float(r["score"])))}">{int(float(r["score"]))}</td><td style="color:{VC[r["verdict"]]};font-weight:700">{r["verdict"]}</td><td class="num">{f(r["entry_low"])}</td><td class="num">{f(r["entry_high"])}</td>{dist(r["distance_to_entry_pct"])}<td style="color:{TC.get(r["timing"],TX)}">{r["timing"]}</td><td class="m2">{esc(r["note_input"]) or ""}</td></tr>''' for r in wl)
watch=f'''<div class="panel"><div class="pad" style="padding-bottom:6px"><div class="ptitle">Watchlist, not owned yet</div></div><table><thead><tr><th>Ticker</th><th>Company</th><th class="num">Price</th><th class="num">Day %</th><th class="c">Score<span class="sort">&#9660;</span></th><th>Verdict</th><th class="num">Entry low</th><th class="num">Entry high</th><th class="num">Distance to entry %</th><th>Trend</th><th>Nick's note</th></tr></thead><tbody>{wrows}</tbody></table></div>'''
html=page("Watchlist and portfolio","Watchlist and portfolio",[("Verdict","All"),("Holding status","All"),("Ticker","All")],warn+cards+hold+watch,H)
render(html,'/workspace/stock-desk-sheet/review/sample_watchlist_and_portfolio.png',H); print('ok')
