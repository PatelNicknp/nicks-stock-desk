# Headline sentiment: Looker design spec (Design Pro)

**Purpose.** Recent headlines for the focus list with a simple word-rule tone (+1 positive, 0 neutral, -1 negative). The tone is not added into the desk score.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Tone (244), Ticker (460), Publisher (676); feed status line x 1116 |
| 158 | 32 | Caption (verbatim) |
| 206 | 96 | 3 count cards of 366: Positive, Neutral, Negative |
| 318 | 880 | Headlines table, full width, 20 rows |

Canvas 1400 x 1230.

## 2. Elements (tab `headline_sentiment`)

**Controls.** Tone: drop-down `tone` (1 / 0 / -1), default all; label "Tone (1 positive, -1 negative)". Ticker: drop-down. Publisher: drop-down `publisher`, default all.

**Caption (verbatim).** "Tone is a word rule on the headline (beat, upgrade, probe, layoff, and similar). It is not added into the desk score."

**Count cards.** Record Count, `tone` = 1 (7), = 0 (125), = -1 (4); backgrounds #14532D, #283146, #7F1D1D.

**Headlines table.** Columns: `ticker` Ticker (w 70), `tone` Tone (w 60, centred), `headline` Headline (wrap ON, widest), `publisher` Source, `published` Published, `tone_note` Why this tone (wrap, 11 pt muted). Sort `published` Descending (text in yyyy-mm-dd hh:mm PT form sorts correctly). Rows 20. Rules: tone = 1 fill #14532D, 0 fill #283146, -1 fill #7F1D1D (3), ticker (1). Optional link: in the data source add a field "Headline link" = `HYPERLINK(link, headline)` and use it instead of `headline`, so the headline itself opens the article. Plain article links only, no trading buttons.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Table: copy the Stock scorecard News table (headline/source/published already styled), switch to `headline_sentiment`, add tone columns.
- Cards: copy the Insider trading cards (same three backgrounds).

## 5. Data gaps
- Only 34 focus tickers have headlines (136 rows). 125 of 136 are tone 0.
- `published` is text, not a date; sorting still works because of its format, but a date range control cannot use it.

## 6. Build order
1. Canvas 1400 x 1230. 2. Table (copied from News). 3. Cards, caption. 4. Controls; test Tone = -1 shows 4 rows.
