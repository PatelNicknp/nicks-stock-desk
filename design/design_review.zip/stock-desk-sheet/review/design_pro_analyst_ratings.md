# Analyst ratings: Looker design spec (Design Pro)

**Purpose.** What Wall Street analysts think of each stock (mean rating, how many analysts, median target) and the desk's analyst points, strongest first.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Analyst points (244), Min. analysts slider (460, w 260), Ticker (736); feed status line x 1116 |
| 158 | 96 | 3 count cards of 366: +2 points, +1 point, 0 points |
| 270 | 880 | Ratings table, full width, 25 rows |
| 1166 | 32 | Caption |

Canvas 1400 x 1230.

## 2. Elements (tab `analyst_ratings`)

**Controls.** Analyst points: drop-down `pts_analyst`, multi, default all. Min. analysts: Slider on `analyst_count`, default 0 to max (raise the low end to hide thinly covered names). Ticker: drop-down, Search ON.

**Count cards.** Record Count with filter `pts_analyst` = 2 / = 1 / = 0 (207, 223, 85 today). Card backgrounds use the point fills (#166534, #14532D, #283146).

**Ratings table.** Columns: `ticker` Ticker, `company` Company, `analyst_mean` Mean rating (1 = strong buy) (2), `analyst_count` Analysts (0), `pts_analyst` Analyst points, `target_analyst` Median target (2), `price` Price (2). Sort `pts_analyst` Descending, then `analyst_count` Descending. Rows 25. Rules: point rules on `pts_analyst` (6), ticker (1), null amber on `analyst_mean`, `target_analyst` (2) = 9.

**Caption.** 11 pt muted: "Targets are the median analyst target. Mean rating runs from 1 (strong buy) to 5 (sell). Upside is not calculated here."

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Point colours (-2..+2), per point column.** Style > Conditional formatting > Add > Single colour, Apply to = that column only (not entire row): = 2 fill #166534; = 1 fill #14532D; = 0 fill #283146; = -1 fill #7F1D1D; = -2 fill #B91C1C; all with font #E6EBF5 bold; plus Is null > font #D6A64A, no fill. Centre the column if Style offers alignment. Looker allows 20 rules per chart: if a table has more than three point columns, use one Colour scale rule per column instead (Colour type > Colour scale, Min -2 #B91C1C, Mid 0 #283146, Max 2 #166534), or a "Select any field" rule set when every coloured column is a point column.

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Table: copy the Dividend scanner table (it already has a point column styled), switch to `analyst_ratings`, point the six rules at `pts_analyst`.
- Cards: copy from Growth; set background per card.

## 5. Data gaps
- `upside_pct` is blank on all 523 rows. Per the spec it is not calculated in Looker; the column is left off (it would be a full column of dashes). Add it back when the job fills it.
- `target_analyst_kind` is "median" on 519 rows (blank on 4): moved into the caption.
- `pts_analyst` only takes 0, 1, 2 today (no negative points); the -1 / -2 rules are there for later. Blank on 8 rows: amber dash = n/a.

## 6. Build order
1. Canvas 1400 x 1230. 2. Data source. 3. Table (copied), rules. 4. Cards, caption. 5. Controls; test Min. analysts 10 hides small names.
