# Dividend scanner: Looker design spec (Design Pro)

**Purpose.** Dividend payers whose yield clears the desk's level and are not AVOID, with yield versus their own average.

No sample picture (same look as `sample_vcp.png`).

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Passes screen (244), Sector (460), Verdict (676), Ticker (892); feed status line x 1116 |
| 158 | 96 | 4 count cards of 271 |
| 270 | 880 | Scanner table, full width, 25 rows |
| 1166 | 40 | Caption |

Canvas 1400 x 1240.

## 2. Elements (tab `scanner_dividend`)

**Controls.** Passes screen: `passes`, Single select, default `yes`, grouped with the table. Sector, Verdict, Ticker as on Growth.

**Count cards (y 158).** "Passing the screen" Record Count, `passes` = yes (75 today). "Of those, BUY" (`passes` = yes AND `verdict` = BUY). "Average yield %, passing" `div_yield` Average, 2 dec. "Yield above own average" Record Count, filter `passes` = yes AND `pts_div_yield` = 1.

**Scanner table (y 270).** Columns: `ticker` Ticker, `company` Company, `sector` Sector, `price` Price (2), `div_yield` Yield % (2), `div_yield_avg` Own avg yield % (2), `pts_div_yield` Yield points, `score` Score, `verdict` Verdict. Sort `div_yield` Descending. Rows 25. Colours: point rules on `pts_div_yield` (6), score bands (5), verdict (3), ticker (1), Is-null amber on `div_yield` and `div_yield_avg` (2) = 17. Yield columns stay #E6EBF5 (a yield is not a gain or loss).

**Caption (y 1166).** "Passes when the yield is at least the desk's level (setting scoring.dividend_min_pct) and the label is not AVOID. A yield of 0 is real (no dividend). A dash means the yield could not be read." `why` is left out: two fixed sentences.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Point colours (-2..+2), per point column.** Style > Conditional formatting > Add > Single colour, Apply to = that column only (not entire row): = 2 fill #166534; = 1 fill #14532D; = 0 fill #283146; = -1 fill #7F1D1D; = -2 fill #B91C1C; all with font #E6EBF5 bold; plus Is null > font #D6A64A, no fill. Centre the column if Style offers alignment. Looker allows 20 rules per chart: if a table has more than three point columns, use one Colour scale rule per column instead (Colour type > Colour scale, Min -2 #B91C1C, Mid 0 #283146, Max 2 #166534), or a "Select any field" rule set when every coloured column is a point column.

**Total score bands (`score`, desk range -6 to 13).** Single colour rules, Apply to = Score column, font #E6EBF5 bold: >= 12 fill #166534; between 9 and 11 fill #14532D; between 5 and 8 fill #283146; between 1 and 4 fill #7F1D1D; <= 0 fill #B91C1C. Same bands as Top stocks, so copying a Top stocks table brings them along.

**Verdict text.** Rules on `verdict`, Apply to = Verdict column, bold, no fill: Equal to BUY font #22C55E; HOLD font #F59E0B; AVOID font #EF4444.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Page > Duplicate page on Growth; Ctrl+A (not nav/header) > Setup > Data source > `scanner_dividend`. Swap the three growth columns for the yield columns.
- Copy the `pts_div_yield` rules later to Dividend fundamentals (Financials group) by copying this whole table there.

## 5. Data gaps
- Spec columns are all present. `sector` and `price` are added (real columns) so the Sector control has something to show.
- `div_yield` blank on 5 rows, `div_yield_avg` and `pts_div_yield` on 7: amber dashes.
- Sector names mix two naming sets (see Growth).

## 6. Build order
1. Duplicate Growth; canvas 1400 x 1240.
2. Data source swap, columns, rules.
3. Cards, caption. Test: Passes = yes gives 75 rows, top yield first.
