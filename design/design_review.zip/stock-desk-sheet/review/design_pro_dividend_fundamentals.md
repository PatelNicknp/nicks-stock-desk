# Dividend fundamentals: Looker design spec (Design Pro)

**Purpose.** The full dividend list (not only names that pass the screen): yield, own average yield, dividend per share, points and verdict, highest yield first.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Pays a dividend (244), Sector (460), Verdict (676), Ticker (892); feed status line x 1116 |
| 158 | 96 | 4 cards of 271: Pay a dividend, Pay none (yield 0), Yield unknown, Average yield of payers |
| 270 | 880 | Dividend table, full width, 25 rows |
| 1166 | 40 | Caption |

Canvas 1400 x 1240.

## 2. Elements (tab `dividend_scanner`)

**Controls.** Pays a dividend: Slider on `div_yield`, default 0.01 to max (the on/off for non-payers: drag the low end to 0 to include them). Sector, Verdict: drop-downs. Ticker: drop-down, Search ON.

**Cards.** Record Count with filters: `div_yield` > 0; `div_yield` = 0; `div_yield` Is null (5 today); and `div_yield` Average with filter `div_yield` > 0 (2 dec, label "Average yield %, payers"). Group the slider with the table only, so the cards always show the full split.

**Dividend table.** Columns: `ticker` Ticker, `company` Company, `sector` Sector, `price` Price (2), `div_yield` Yield % (2), `div_yield_avg` Own avg yield % (2), `dps` Dividend per share (2), `pts_div_yield` Points, `verdict` Verdict. Sort `div_yield` Descending. Rows 25. Rules: points (6), verdict (3), ticker (1), null amber on `div_yield`, `div_yield_avg`, `dps` (3) = 13.

**Caption.** 11 pt muted: "A yield of 0 is real: the company does not pay. A dash means the yield could not be read. The Data updates page shows how many are unknown."

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Point colours (-2..+2), per point column.** Style > Conditional formatting > Add > Single colour, Apply to = that column only (not entire row): = 2 fill #166534; = 1 fill #14532D; = 0 fill #283146; = -1 fill #7F1D1D; = -2 fill #B91C1C; all with font #E6EBF5 bold; plus Is null > font #D6A64A, no fill. Centre the column if Style offers alignment. Looker allows 20 rules per chart: if a table has more than three point columns, use one Colour scale rule per column instead (Colour type > Colour scale, Min -2 #B91C1C, Mid 0 #283146, Max 2 #166534), or a "Select any field" rule set when every coloured column is a point column.

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Verdict text.** Rules on `verdict`, Apply to = Verdict column, bold, no fill: Equal to BUY font #22C55E; HOLD font #F59E0B; AVOID font #EF4444.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Copy the whole Dividend scanner table (Scanners group), Setup > Data source > `dividend_scanner`, remove `score`, add `dps`. Rules carry over (same field names).
- Cards: copy from Dividend scanner and change filters.

## 5. Data gaps
- The spec says "the freshness page separates" yield 0 from blank; there is no Freshness page in the nav. The `freshness` tab is placed on Data updates (see that file), and the cards here make the split visible.
- `dividend_scanner` has no `score` column (the scanner tab does); the spec does not ask for it.
- `div_yield` blank on 5 rows, `div_yield_avg` and `pts_div_yield` on 7.

## 6. Build order
1. Canvas 1400 x 1240. 2. Table (copied), cards, caption. 3. Controls; test slider low end 0 adds the non-payers.
