# Quality scanner: Looker design spec (Design Pro)

**Purpose.** Stocks with strong return on equity and modest debt, shown with their point colours. Today the page is honestly empty because the ROE and debt/equity feed is missing.

No sample picture (same look as `sample_vcp.png`).

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Passes screen (244), Sector (460), Verdict (676), Ticker (892); feed status line x 1116 |
| 158 | 44 | Amber notice strip (explains the empty page), full width |
| 218 | 96 | 3 count cards of 366 |
| 330 | 880 | Scanner table, full width, 25 rows |
| 1226 | 40 | Caption |

Canvas 1400 x 1300.

## 2. Elements (tab `scanner_quality`)

**Controls.** Passes screen: drop-down `passes`, Single select, default `yes` (group it with the table). Sector, Verdict, Ticker as on Growth.

**Notice strip (y 158).** Text box (static), 12 pt #F59E0B, border #F59E0B 1 px, radius 6, background #121826: "No stock passes today: return on equity and debt/equity are not in the free filings feed yet (blank for all 523 stocks). The page fills in by itself when they arrive." Delete this box once `roe` has values.

**Count cards (y 218).** "Passing the screen" Record Count, filter `passes` = yes (0 today). "ROE on file" = `roe` Count (counts non-blank, 0 today). "Debt/equity on file" = `de` Count (0 today). These three make the gap visible without inventing anything.

**Scanner table (y 330).** Columns: `ticker` Ticker, `company` Company, `sector` Sector, `roe` Return on equity % (1), `de` Debt / equity (2), `pts_roe` ROE points, `pts_de` Debt points, `score` Score, `verdict` Verdict. Sort `roe` Descending. Rows 25. Colours: point rules on `pts_roe` and `pts_de` (6 each), score bands (5), verdict (3), ticker (1) = 21: drop the ticker accent rule here (20). With Passes = yes the table shows Looker's small "No data": expected today.

**Caption (y 1226).** "Passes when return on equity is high and debt/equity is at most the desk's limit (setting scoring.quality_max_de), and the label is not AVOID." `why` is left out: today it is one sentence for every row ("Does not pass the quality screen.").

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Point colours (-2..+2), per point column.** Style > Conditional formatting > Add > Single colour, Apply to = that column only (not entire row): = 2 fill #166534; = 1 fill #14532D; = 0 fill #283146; = -1 fill #7F1D1D; = -2 fill #B91C1C; all with font #E6EBF5 bold; plus Is null > font #D6A64A, no fill. Centre the column if Style offers alignment. Looker allows 20 rules per chart: if a table has more than three point columns, use one Colour scale rule per column instead (Colour type > Colour scale, Min -2 #B91C1C, Mid 0 #283146, Max 2 #166534), or a "Select any field" rule set when every coloured column is a point column.

**Total score bands (`score`, desk range -6 to 13).** Single colour rules, Apply to = Score column, font #E6EBF5 bold: >= 12 fill #166534; between 9 and 11 fill #14532D; between 5 and 8 fill #283146; between 1 and 4 fill #7F1D1D; <= 0 fill #B91C1C. Same bands as Top stocks, so copying a Top stocks table brings them along.

**Verdict text.** Rules on `verdict`, Apply to = Verdict column, bold, no fill: Equal to BUY font #22C55E; HOLD font #F59E0B; AVOID font #EF4444.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Page > Duplicate page on Growth, then Ctrl+A (leave out nav and header) > Setup > Data source > `scanner_quality`. Swap the growth columns for the four quality columns.
- Point rules: Looker cannot duplicate a rule inside a chart, so add the six for `pts_de` by hand (same values as `pts_roe`), or use one Colour scale rule per point column (Min -2 #B91C1C, Mid 0 #283146, Max 2 #166534) to save rules.
- Cards: copy from Growth, change metric and filter; delete the fourth card and use Arrange > Make same size + Distribute for three.

## 5. Data gaps
- `roe`, `de`, `pts_roe`, `pts_de` are blank on all 523 rows; `passes` is `no` on every row. The job's `data_status` still says OK. Ask the job to set `data_status` = MISSING with a note while the feed is absent; the feed status line would then explain the page by itself and the static notice can go.
- `scanner_quality` has `price` but the spec's column list does not; left off to keep the table short.
- Sector names mix two naming sets (see Growth).

## 6. Build order
1. Duplicate Growth; canvas 1400 x 1300.
2. Swap data source to `scanner_quality`, swap columns, rules.
3. Notice strip, cards (3), caption.
4. Test: Passes = no shows all 523 with amber dashes in the four quality columns.
