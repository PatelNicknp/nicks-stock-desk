# Nick's Stock Desk: Today page (Looker Design Pro)

Sample picture: `sample_today_polished.png` (generator: `mock/gen_today.py`, same nav and header code as the other samples).
Based on `looker_today_v2.png` and LOOKER_SPEC.md "## 1. Today". The nav and header come from `design_pro_nav_header.md`, so build that first.
Canvas 1600 x 1000. Positions are canvas px. Set them in the panels, nudge with the arrow keys, and use Arrange > Align / Distribute /
Make same size. Don't drag.

Theme (exact): bg #0B0F17, panels #121826, text #E6EBF5, muted #8B96AD, grid/border #1E293B, up #22C55E, down #EF4444,
hold #F59E0B, accent #7C9CFF, Roboto, radius 8, 16 px card padding, 24 px outer margin. Blank values show `n/a` in #D6A64A
(shared colour rule).

Layout at a glance (x, y, w, h):
- Header: title 244,24,720,36 · research line 244,66 · Updated chip right edge 1576, y 28
- Scorecards: 7 cards, y 110, h 96, first x 244, last x 1400, each w 176
- Breadth chart panel 244,230,800,380 · Sector panel 1060,230,516,380
- Top-5 sectors panel 244,634,520,342 · Latest alerts panel 780,634,796,342 (bottom edge 976, 24 px margin)

## Steps, in priority order

1. **Fix the right-edge cut-off and the frame.** Theme and layout > Layout > Navigation type Hidden. Canvas size Custom 1600 x 1000.
   Apply the shared nav and header. Nothing may end past x 1576. The sector panel now ends exactly there.
2. **Compact header.** Title text box: x 244, y 24, w 720, h 36, 32 bold #E6EBF5. Research line: x 244, y 66, h 20, 14 #8B96AD, one line
   (make the box w 1000 so it doesn't wrap). Delete the empty space between them by moving the research box up. Everything below moves up about 120 px.
3. **Scorecards: smaller and tidy (the biggest visual win).**
   - Every card: Style > Background #121826, Border #1E293B weight 1, Border radius 8, Alignment Left.
     Metric name (label) 11 #8B96AD. Primary metric 27 #E6EBF5, decimals as listed. Comparison 12.
     Comparison fields: Positive change colour #22C55E, Negative change colour #EF4444.
   - Size: select all 7 > Arrange > Make same size (w 176, h 96). Put the first at x 244 and the last at x 1400, all at y 110, then Arrange >
     Align top > Distribute horizontally (gaps come out about 16 px). If a scorecard still floats its value at the top, the 96 px height fixes it.
   - If the label sits under the value, tick Hide metric name and add the label as a text box at card x+16, y 124 (11 bold CAPS #8B96AD).
   Cards, left to right:
   1. **S&P 500**: metric `spy_price`, renamed "S&P 500", 2 decimals. Add a field in market_today:
      `spy_prev_close` = `spy_price / (1 + spy_day_pct / 100)`. Setup > Other comparison options > Comparison type **Metric** >
      Target metric `spy_prev_close`. The change then reads ▼ 0.52%, matching `spy_day_pct`. Comparison label "today", 2 decimals.
   2. **% above 50-day**: Add a field `b50` = `CASE WHEN breadth_sma50 > 0 THEN breadth_sma50 ELSE NULL END` and `b50_wk` (same for
      `breadth_sma50_week_ago`). Metric `b50`, 1 decimal. Comparison type Metric > Target `b50_wk`. Style > Comparison fields >
      **Show absolute change** on (points, not %), label "vs week ago".
      Why: today's market_today export has `breadth_sma50`, `_sma100`, `_sma200` and `_week_ago` all = 0 while the 20-day is 67.9.
      That's a missing value written as 0. The refresh job should write a blank. Until it does, the CASE stops a false 0. If Style offers
      Missing data, pick "-". Otherwise the card shows "No data", which is honest.
   3. **Advancers / decliners**: one panel rectangle (176 x 96, #121826, border #1E293B, radius 8) with a label text box
      "ADVANCERS / DECLINERS". Two scorecards with no background and no label: `advancers` 27 #22C55E and `decliners` 27 #EF4444, with
      a "/" text box between them, 27 #5B6680. Sub-line text cell: field `CONCAT("of ", CAST(universe_n AS TEXT), " stocks")`, 12 #8B96AD.
      Select the three value pieces > Arrange > Align middle.
   4. **New 52-week highs**: metric `highs_52w`, 0 decimals, comparison None. Sub-line text cell `CONCAT(CAST(lows_52w AS TEXT), " new lows")`.
   5. **Put/call mood**: the zone is text, so use the text cell recipe (nav file, step 13) on `put_call_zone`, font 27. Conditional formatting:
      text colour #F59E0B when the zone contains "Greed" or "Fear" (crowd leaning one way = caution), #E6EBF5 for Neutral.
      Sub-line text cell: `CONCAT(CAST(ROUND(put_call,2) AS TEXT), " today · 5-day ", CAST(ROUND(put_call_ma5,2) AS TEXT))`.
   6. **VIX**: metric `vix`, 2 decimals, comparison None. Sub-line text box "fear gauge", 12 #8B96AD.
   7. **10-year yield**: text cell on a field `y10_text` =
      `CASE WHEN fred_dgs10 IS NULL THEN "n/a" ELSE CONCAT(CAST(ROUND(fred_dgs10,2) AS TEXT), "%") END`, font 27.
      Sub-line `curve_text` = `CASE WHEN fred_t10y2y IS NULL THEN "10y–2y n/a" ELSE CONCAT("10y–2y ", CAST(ROUND(fred_t10y2y,2) AS TEXT)) END`.
      Conditional formatting: text equal to "n/a" → #D6A64A. Never 0 when FRED is blocked.
4. **Breadth chart: no drops to 0, readable dates, title instead of legend.**
   - Panel: Insert > Rectangle x 244, y 230, w 800, h 380, #121826, border #1E293B, radius 8.
     Title text box x 260, y 244, "Market breadth", 15 bold #E6EBF5. Sub text x 260, y 266,
     "% of the 523 desk stocks above each average, 6 months", 12 #8B96AD.
   - Insert > Time series, x 252, y 300, w 784, h 300. Data source `breadth_history`. Dimension `date`. Metrics `pct_above_sma20`,
     `pct_above_sma50`, `pct_above_sma100`, `pct_above_sma200` (aggregation Average), renamed "20-day", "50-day", "100-day", "200-day".
     Default date range > Custom > Advanced: start today minus 6 months, end today.
   - Style: **Missing data > Line breaks** (not "Line to zero"; breaks are honest about the June and September gaps, while interpolation would draw
     a straight line through a month with no data). Series colours: 20-day #7C9CFF, 50-day #E6EBF5, 100-day #F59E0B, 200-day #8B96AD,
     line weight 2, points off. Left Y-axis min 0, max 100. Axis labels 11 #8B96AD, gridlines #1E293B. Chart background transparent,
     border none. **Legend: None.**
   - If the line still drops to 0, the sheet holds 0 instead of blank. Add fields like `p20` =
     `CASE WHEN pct_above_sma20 > 0 THEN pct_above_sma20 ELSE NULL END` (same for 50/100/200) and chart those.
   - Dates: the wider chart (784 px instead of about 330) stops the rotated, crowded labels. If they are still rotated, click the
     calendar icon on `date` > ISO Year Week (weekly points, Average keeps the % right).
   - Legend replacement = 4 chips in the panel's top-right (they also give the latest values, as the Breadth page asks for). Each chip is a text cell
     (h 28, background #0F1420, border #1E293B, radius 6, 12 #E6EBF5) on market_today, for example
     `CONCAT("20-day ", CAST(ROUND(breadth_sma20,1) AS TEXT), "%")`. Use the `b50`-style CASE so blanks show "—", and put an 8 px Insert > Circle
     in the series colour before each chip. Right-align the chip group to x 1028, y 246. Arrange > Distribute horizontally.
   - Small note bottom-right of the panel, 11 #5B6680: "Gaps = days with no breadth data (shown as breaks, not 0)".
5. **Sector bar: calm colours, short names, no legend.**
   - Panel rectangle x 1060, y 230, w 516, h 380. Title "Sectors today" (15 bold) at x 1076, y 244. Sub "Day % change, 11 S&P sector ETFs"
     (12 #8B96AD) at y 266.
   - Insert > Bar chart, x 1068, y 296, w 500, h 306. Source `sectors`. Filter: Add a filter > Include > `ticker` > In >
     XLK,XLV,XLF,XLI,XLC,XLY,XLP,XLE,XLU,XLRE,XLB.
   - Short names (fixes the cramped "Communication Servic..."): field `short_name` =
     `CASE ticker WHEN "XLK" THEN "Technology" WHEN "XLV" THEN "Health Care" WHEN "XLF" THEN "Financials" WHEN "XLI" THEN "Industrials"
     WHEN "XLC" THEN "Communication" WHEN "XLY" THEN "Discretionary" WHEN "XLP" THEN "Staples" WHEN "XLE" THEN "Energy"
     WHEN "XLU" THEN "Utilities" WHEN "XLRE" THEN "Real Estate" WHEN "XLB" THEN "Materials" ELSE name END`.
     Dimension `short_name`.
   - Up/down colours by sign: fields `day_up` = `CASE WHEN day_pct >= 0 THEN day_pct ELSE NULL END` and
     `day_down` = `CASE WHEN day_pct < 0 THEN day_pct ELSE NULL END`. Metrics day_up and day_down (Average), Stacked bars on, Sort by `day_pct` descending,
     Bars 11.
   - Style: Horizontal. Series colours: day_up #1F9D55, day_down #D14343 (slightly softened from #22C55E/#EF4444 so 11 bars don't shout;
     if Nick wants the exact theme hex, swap them in). Show data labels, 1 decimal, label colour #22C55E / #EF4444 per series if offered,
     otherwise #E6EBF5. **Legend None.** Y-axis labels 12 #C3CBDB, X-axis labels 10 #5B6680, gridlines #1E293B, background transparent.
6. **Top 5 sectors table.** Panel x 244, y 634, w 520, h 342, with title "Top 5 sectors today" and sub "Best day % of the 19 sector and
   industry ETFs". Insert > Table x 244, y 698, w 520, h 270, source `sectors`. Dimension `name` ("Sector"), metric `day_pct` ("Day %",
   2 decimals). Add `day_pct` a second time, header blank, Style > that column > Bar, colour #1F9D55. Sort `day_pct` descending,
   Rows per page 5, pagination off, Row numbers on (this is the #). Table colours as on Top stocks: header bg #121826, header text #8B96AD bold
   12, odd rows #0F1420, even rows #121826, borders #1E293B, body 13 #E6EBF5. Day % font colour >0 #22C55E, <0 #EF4444.
7. **Latest alerts table.** Panel x 780, y 634, w 796, h 342. Title "Latest alerts". Sub "Changes since the previous run. Nothing is emailed and
   nothing is sent to a broker." Text box "All alerts ›" 12 #7C9CFF at the panel's top-right, linked to the Alerts page (paste the URL).
   Insert > Table x 780, y 698, w 796, h 270, source `alerts`. Columns: `ticker` ("Ticker", bold #7C9CFF), `text` ("What changed"),
   field `score_move` = `CONCAT(CAST(score_prev AS TEXT), " → ", CAST(score AS TEXT))` ("Score"), `verdict` ("Verdict": BUY #22C55E,
   HOLD #F59E0B, AVOID #EF4444 text colour). Rows per page 8, pagination off. Sort: newest first by the alert's time column if the tab has
   one. If not, ask the refresh job to add a row number, because Looker can't know which rows are "latest". Same table colours as step 6.
   Missing data: "-". In the table only, never a pop-up.
8. **Final tidy.** Select the two chart panels > Arrange > Align top. Same for the two bottom panels. Check that every panel edge sits on x 244 or ends at x 1576.
   View mode: nothing is clipped on the right, and no axis labels are rotated.

## What the sample shows (real vs placeholder)
Real (market_today export saved as `/home/box/Downloads/data.csv`, updated 2026-10-23 19:24 PT, matching looker_today_v2.png):
S&P 759.97 and −0.52%, advancers 144, decliners 378, universe 523, 52-week highs 14 and lows 5, put/call 0.69, 5-day 0.594 (shown 0.59),
zone Greed, VIX 19.45, 10y 4.96%, 10y–2y 0.31, 20-day breadth 67.9%.
Read off the current Looker chart pixels (about ±0.05): the sector day % values, and the 20-day breadth line shape and gaps (traced).
Placeholders "—": % above 50/100/200-day and the week-ago comparison (the export has 0, which is not believable), the 50/100/200 lines, and
all alert rows (no alerts data on this computer).

## Build order
1. Nav and header (other file), canvas 1600 x 1000.
2. Data-source fields: spy_prev_close, b50, b50_wk, y10_text, curve_text, short_name, day_up, day_down, score_move, chip texts.
3. The 7 scorecards (step 3), then size, align and distribute.
4. Breadth panel and chart (step 4).
5. Sector panel and chart (step 5).
6. Top 5 table, then the alerts table (steps 6-7).
7. Final alignment pass and a View-mode check (step 8).
