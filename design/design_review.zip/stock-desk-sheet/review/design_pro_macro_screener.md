# Macro screener: Looker design spec (Design Pro)

**Purpose.** Recent US economic releases (jobs, growth, inflation): actual versus forecast and a +1 / 0 / -1 signal for whether the surprise usually helps stocks. A label, not a forecast.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Category (244), Indicator (460), Signal (676); feed status line x 1116 |
| 158 | 40 | Caption (verbatim) |
| 214 | 96 | 3 cards of 366: Helpful surprises (+1), Neutral (0), Unhelpful (-1) |
| 326 | 700 | Releases table, full width, 20 rows |

Canvas 1400 x 1060.

## 2. Elements (tab `macro_screener`)

**Controls.** Category: drop-down `category` (Jobs, Growth, Inflation), default all. Indicator: drop-down `indicator`, default all. Signal: drop-down `signal`, default all.

**Caption (verbatim).** "Signal is +1 when the surprise is in the direction that usually helps stocks (for unemployment and jobless claims, lower is the helpful direction). It is a label, not a forecast."

**Cards.** Record Count with filter `signal` = 1 (18), = 0 (7), = -1 (9); backgrounds #14532D, #283146, #7F1D1D.

**Releases table.** Columns: `date` Date, `category` Category, `indicator` Indicator, `actual` Actual, `forecast` Forecast, `surprise` Surprise, `signal` Signal. `actual` and `forecast` are text with units (194K, 0.6%): keep them text. `surprise` Number, Decimal precision Auto (units differ by indicator). Sort `date` Descending. Rows 20. Rules: point rules on `signal` (6), `category` font #8B96AD (none).

**MISSING state.** If the only row is MISSING, the feed status line shows the note and the table is empty. Never type a CPI number.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Point colours (-2..+2), per point column.** Style > Conditional formatting > Add > Single colour, Apply to = that column only (not entire row): = 2 fill #166534; = 1 fill #14532D; = 0 fill #283146; = -1 fill #7F1D1D; = -2 fill #B91C1C; all with font #E6EBF5 bold; plus Is null > font #D6A64A, no fill. Centre the column if Style offers alignment. Looker allows 20 rules per chart: if a table has more than three point columns, use one Colour scale rule per column instead (Colour type > Colour scale, Min -2 #B91C1C, Mid 0 #283146, Max 2 #166534), or a "Select any field" rule set when every coloured column is a point column.

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Table: copy the Analyst ratings table (one point column styled), switch to `macro_screener`, re-point rules to `signal`.
- Cards: copy the Insider trading cards.

## 5. Data gaps
- `surprise` mixes units (-6000 for claims, 0.1 for percent series): shown as is with Auto decimals; it is context, the signal is the point.
- Some releases repeat on two dates (e.g. Jobless claims 194K vs 200K on 2026-10-23 and 2026-10-22). That is in the file; not fixed in Looker.
- `country` is US on every row; left off.

## 6. Build order
1. Canvas 1400 x 1060. 2. Table, cards, caption. 3. Controls; test Category = Inflation shows the CPI rows.
