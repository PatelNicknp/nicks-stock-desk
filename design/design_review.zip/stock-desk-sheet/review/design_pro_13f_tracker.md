# 13F tracker: Looker design spec (Design Pro)

**Purpose.** Whether big funds added or cut each stock in the latest public holdings filings, plus the largest holders of the stock Nick picks.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Left | Right |
| --- | --- | --- | --- |
| 106 | 36 | Control bar: Ticker (244), Institutional points (460); feed status line x 1116 | |
| 158 | 32 | Caption (verbatim), full width | |
| 206 | 880 | Summary table (x 244, w 740), 25 rows | Top holders table (x 1000, w 376), 10 rows |

Canvas 1400 x 1120.

## 2. Elements (tab `institutional_13f`)

**Controls.** Ticker: drop-down `ticker`, Search ON, default all (drives both tables). Institutional points: drop-down `pts_institutional`, default all, grouped with the summary table.

**Caption (verbatim).** "Summary of the latest public holdings file, plus the largest holders. Not every fund. Built this way so the page stays fast."

**Summary table (x 244).** Chart filter Include `row_type` = summary. Columns: `ticker` Ticker, `increased_shares` Shares added (Compact ON), `decreased_shares` Shares cut (Compact ON), `holders` Holders (0), `ownership_pct` Owned by funds % (1), `as_of` As of, `pts_institutional` Points. Sort `ownership_pct` Descending (or `pts_institutional` Descending if Nick prefers). Rows 25. Setup > Chart interactions > Cross-filtering ON (click a ticker to see its holders). Rules: points (6), ticker (1), `increased_shares` font #22C55E and `decreased_shares` font #EF4444 via Is-not-null (2) = 9.

**Top holders (x 1000).** Filter Include `row_type` = top_holder. Columns: `owner` Holder (wrap), `shares` Shares (Compact ON), `share_change` Change (Compact ON), `as_of` As of. Sort `shares` Descending. Rows 10. Return rules on `share_change` (3). Title "Largest holders (click a ticker)". Without a ticker picked, it lists the biggest positions across the desk.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Point colours (-2..+2), per point column.** Style > Conditional formatting > Add > Single colour, Apply to = that column only (not entire row): = 2 fill #166534; = 1 fill #14532D; = 0 fill #283146; = -1 fill #7F1D1D; = -2 fill #B91C1C; all with font #E6EBF5 bold; plus Is null > font #D6A64A, no fill. Centre the column if Style offers alignment. Looker allows 20 rules per chart: if a table has more than three point columns, use one Colour scale rule per column instead (Colour type > Colour scale, Min -2 #B91C1C, Mid 0 #283146, Max 2 #166534), or a "Select any field" rule set when every coloured column is a point column.

**Return colours (text, not fill).** Per return column: > 0 font #22C55E; < 0 font #EF4444; = 0 leaves #E6EBF5; Is null > font #D6A64A. Apply to that column only.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Summary: copy the Analyst ratings table, switch to `institutional_13f`, add the row_type filter, re-point the point rules.
- Holders: copy the summary table, change the filter and columns.

## 5. Data gaps
- `ownership_pct` can exceed 100 (e.g. 105.54, 118.4): filings double count; shown as is.
- `as_of` is text like 6/30/2026 and mixes four dates (mostly 6/30/2026, some 12/31/2025). Set it to Type Date (format M/D/YYYY) in the data source so it sorts; if Looker rejects it, leave as text.
- `pts_institutional` blank on 3 summary rows: amber dash.

## 6. Build order
1. Canvas 1400 x 1120. 2. Data source; `as_of` type. 3. Summary table, cross-filtering. 4. Holders table. 5. Controls; test click AAPL shows its 5 holders.
