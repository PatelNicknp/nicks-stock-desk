# Earnings tracker: Looker design spec (Design Pro)

**Purpose.** Every earnings report on file: estimate, actual and surprise, newest first. A blank actual is a future date, never a miss.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Left | Right |
| --- | --- | --- | --- |
| 106 | 36 | Control bar: Dates (date range, 244, w 260), Ticker (520); feed status line x 1116 | |
| 158 | 300 | Surprise column chart for the picked ticker (x 244, w 740) | Beat count cards, stacked (x 1000, w 376): Beats, Misses, Upcoming |
| 474 | 880 | Tracker table, full width, 25 rows | |

Canvas 1400 x 1390.

## 2. Elements (tab `earnings_tracker`)

**Controls.** Dates: Date range on `earnings_date`, default Advanced: start Today minus 365 days, end Today plus 90 days (keeps the next report). Ticker: drop-down, Search ON, default all. The date range is the on/off for old and future reports; upcoming rows are shown muted (rule below).

**Surprise chart (x 244).** Column chart, Dimension `earnings_date`, Metric `surprise_pct` Average "EPS surprise %", Sort `earnings_date` Ascending, Bars 12, bar rules > 0 #22C55E, < 0 #EF4444, data labels ON (1 dec). Title "EPS surprise % by report (pick a ticker)".

**Cards (x 1000, three 376 x 88 stacked).** Record Count with filters: "Beats" `surprise_pct` > 0; "Misses" `surprise_pct` < 0; "Upcoming (no actual yet)" `eps_actual` Is null.

**Tracker table.** Columns: `ticker` Ticker, `earnings_date` Report date, `eps_estimate` EPS estimate (2), `eps_actual` EPS actual (2), `surprise_pct` Surprise % (1). Sort `earnings_date` Descending. Rows 25. Rules: return rules on `surprise_pct` (3); `eps_actual` Is null > Entire row font #8B96AD (upcoming, not a miss) (1); ticker (1).

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Bar/column chart style (B).** Style > Bars colour as listed, Show data labels ON (11 pt #E6EBF5) when there are fewer than 15 bars, Axes 11 pt #8B96AD, Gridlines #1E293B, Background #121826, Border #1E293B, radius 8, Legend None (title names it). Bar charts accept conditional formatting: > 0 bar #22C55E, < 0 bar #EF4444.

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Return colours (text, not fill).** Per return column: > 0 font #22C55E; < 0 font #EF4444; = 0 leaves #E6EBF5; Is null > font #D6A64A. Apply to that column only.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Chart: copy the Backtest bucket chart (bar +/- rules already set), switch source and dimension.
- Table: copy the Earnings calendar table, switch to `earnings_tracker`, trim columns.

## 5. Data gaps
- `result` is blank on all 12,720 rows (not used; a beat/miss word would have needed it).
- `eps_actual` blank on 546 rows (future dates or not reported); `surprise_pct` blank on 541. Shown muted / amber dash, never as misses.
- `earnings_tracker` and `earnings_history` hold the same reports; this page uses `earnings_tracker` as the spec says.

## 6. Build order
1. Canvas 1400 x 1390; `earnings_date` type Date. 2. Date range and Ticker controls. 3. Chart, cards, table. Test: Ticker ADSK shows 4 green bars for the last year and 2026-11-27 muted as upcoming.
