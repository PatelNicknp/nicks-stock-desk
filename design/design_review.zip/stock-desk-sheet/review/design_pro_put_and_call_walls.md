# Put and call walls: Looker design spec (Design Pro)

**Purpose.** For one focus-list ticker and one expiry, where open interest piles up by strike (calls green, puts red) and the two wall strikes. Sentiment only, not a contract to trade.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Ticker (244), Expiry (460), Strike range slider (676, w 300); feed status line x 1116 |
| 158 | 40 | Caption (verbatim, not optional), full width |
| 214 | 420 | Open interest by strike, column chart, full width |
| 650 | 120 | Walls table (2 rows), x 244 w 740 | 
| 650 | 120 | Note box (the tab's `note`), x 1000 w 376 |

Canvas 1400 x 800.

## 2. Elements (tab `option_walls`)

**Controls.** Ticker: drop-down `ticker`, Single select, Search ON, default NVDA (first focus name; Nick changes it). Expiry: drop-down `expiry`, Single select, default the nearest date at build time (2026-10-26 today). Looker cannot default to "nearest" by itself; see Data gaps. Strike range: Slider on `strike`, default full range (lets Nick zoom in on strikes near the price).

**Caption (verbatim).** "Open interest by strike. Sentiment only. Not a contract to trade. Chains refresh once a day for the focus list, so most of the universe is not on this page."

**Column chart (y 214, 1132 x 420).** Dimension `strike` (Number used as dimension, label "Strike"), Breakdown dimension `side`, Metric `open_interest` Sum, label "Open interest". Sort `strike` Ascending; Bars up to 120. Style > Colour by: series; set call #22C55E and put #EF4444 (Style > Series colours, or Theme > Dimension value colours: call / put). Stacked OFF. Data labels OFF (too many bars). Legend Top (names call / put). Title "Open interest by strike".

**Walls table (x 244, y 650).** Filter Include `is_wall` = yes. Columns: `side` Side, `strike` Strike (2), `open_interest` Open interest (0, thousands separator), `volume` Volume today (0). Sort `side` Ascending. Rows 2. Rules: side = call font #22C55E bold; put font #EF4444 bold. Title "The walls: most open interest".

**Note box (x 1000, y 650).** Text-value box on `note`: "Open interest only, for the focus list, once a day. Not an option pick." 11 pt muted.

**MISSING state.** If the tab is the MISSING row, the feed status line shows the note and the chart shows "No data". Add a chart filter on the chart: Exclude `data_status` = MISSING, so no fake bars appear.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Bar/column chart style (B).** Style > Bars colour as listed, Show data labels ON (11 pt #E6EBF5) when there are fewer than 15 bars, Axes 11 pt #8B96AD, Gridlines #1E293B, Background #121826, Border #1E293B, radius 8, Legend None (title names it). Bar charts accept conditional formatting: > 0 bar #22C55E, < 0 bar #EF4444.

**Text-value box (one-row table).** For a text field (company, reason, headline): Insert > Table, Dimension = the field, remove the metric (Record Count). Style: Table header OFF, Pagination OFF, Row numbers OFF, Wrap text ON, Background transparent, border none, Missing data Show blank. Font size and colour as listed.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Column chart: copy the Backtest bucket chart (dark style), switch to `option_walls`, set dimension, breakdown and colours. Remove its > 0 / < 0 bar rules (colour comes from the side here).
- Walls table: copy any finished small table (e.g. Backtest Year by year).

## 5. Data gaps
- No "nearest expiry" flag. Ask the job to add `is_nearest` (yes/no) so the Expiry default can be a page filter instead of a fixed date that goes stale. Until then, the default date has to be moved by hand each week.
- Only 34 focus tickers have chains (6,437 rows, 10 expiry dates; NVDA has 3 expiries and 87 strikes).
- `volume` is blank on 405 rows: amber dash.
- No strike, expiry or premium is suggested anywhere; walls are context only.

## 6. Build order
1. Canvas 1400 x 800. 2. Controls (Ticker, Expiry defaults). 3. Column chart, colours. 4. Walls table, note box, caption. Test: NVDA, 2026-10-26: call wall 225, put wall 200.
