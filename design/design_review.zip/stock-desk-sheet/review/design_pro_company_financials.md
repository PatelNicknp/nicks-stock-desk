# Company financials: Looker design spec (Design Pro)

**Purpose.** One company's annual figures from SEC filings, year by year: revenue, profits, EPS, margins and free cash flow. Margins stay blank when the filing did not have the line.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Left | Right |
| --- | --- | --- | --- |
| 106 | 36 | Control bar: Ticker (244), Years (date range on fy_end, 460, w 260); feed status line x 1116 | |
| 158 | 32 | Caption (verbatim) | |
| 206 | 300 | Revenue and net income columns (x 244, w 558) | Margins line (x 818, w 558) |
| 522 | 520 | Year table, full width, 15 rows | |

Canvas 1400 x 1080.

## 2. Elements (tab `company_financials`)

**Controls.** Ticker: drop-down `ticker`, Single select, Search ON, default ADSK (or the report-level Ticker). Years: Date range on `fy_end`, default Advanced start Today minus 3650 days (10 years), end Today.

**Caption (verbatim).** "Annual figures from SEC filings. Margins are blank when the filing did not include that line."

**Revenue and net income (x 244).** Column chart, Dimension `fy_end` (Date, show as year), Metrics `revenue` "Revenue" #7C9CFF and `net_income` "Net income" #8B96AD (Sum), Compact numbers ON (shows 4.2B), Sort `fy_end` Ascending, Bars 10. Legend Top. Title "Revenue and net income by fiscal year".

**Margins line (x 818).** Time series, Dimension `fy_end`, Metrics `gross_margin` #E6EBF5, `operating_margin` #7C9CFF, `net_margin` #8B96AD (Average, 1 dec), Missing data **Line breaks** (a missing margin must not be bridged or drawn at 0). Legend Top. Title "Margins %".

**Year table.** Columns: `fy_end` Fiscal year end, `revenue` Revenue, `gross_profit` Gross profit, `op_income` Operating income, `net_income` Net income, `eps` EPS (2), `gross_margin` Gross margin % (1), `operating_margin` Operating margin % (1), `net_margin` Net margin % (1), `fcf` Free cash flow. Money columns Compact numbers ON (e.g. 4.2B). Sort `fy_end` Descending. Rows 15. Rules: return rules on `net_income` and `fcf` (negative red; 6); null amber on the three margins and `revenue` (4) = 10. Never Show 0 for margins.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Bar/column chart style (B).** Style > Bars colour as listed, Show data labels ON (11 pt #E6EBF5) when there are fewer than 15 bars, Axes 11 pt #8B96AD, Gridlines #1E293B, Background #121826, Border #1E293B, radius 8, Legend None (title names it). Bar charts accept conditional formatting: > 0 bar #22C55E, < 0 bar #EF4444.

**Line chart style (L).** Time series chart, Dimension `date` (type Date). Style > Series: weight 2, colours as listed, Missing data > Linear interpolation (or Line breaks), never Show as 0. Axes Roboto 11 pt #8B96AD; Grid > Axis and Gridline colour #1E293B; Chart background #121826, Border #1E293B, radius 8. Legend: None for one series (the title names it); for several series, Legend Top, Roboto 11 pt #8B96AD, or name the colours in the title. Title Roboto 13 pt bold #E6EBF5 on the chart (Style > Show title) or a text box above it.

**Return colours (text, not fill).** Per return column: > 0 font #22C55E; < 0 font #EF4444; = 0 leaves #E6EBF5; Is null > font #D6A64A. Apply to that column only.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Year table: copy the Financials summary table, switch to `company_financials`, swap columns.
- Column chart: copy the Earnings tracker chart; delete its +/- bar rules; add the second metric.
- Margins line: copy the Breadth or Backtest line chart; switch Missing data to Line breaks.

## 5. Data gaps
- `pe`, `ps`, `pfcf` are blank on all 8,441 rows (not in the spec; left off).
- Blank rates are high: `revenue` 3,770 rows, `gross_profit` 5,072, `gross_margin` 6,640, `operating_margin` 4,769, `net_margin` 4,911, `fcf` 2,908. Many older years come from partial filings; the 10-year default hides most of them.
- `fy_end` has many distinct dates (fiscal years end in different months); treat it as Date and show as year.
- `filed` is on the tab but not in the spec; left off.

## 6. Build order
1. Canvas 1400 x 1080; `fy_end` type Date. 2. Controls. 3. Two charts, table, caption. Test: ADSK shows about 10 fiscal years, margins blank where missing.
