# Put/call ratio: Looker design spec (Design Pro)

**Purpose.** The market mood gauge: the equity put/call ratio and its 5-day average against the fear (1.0) and greed (0.7) lines, with today's zone. Market mood only, not an option position.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Left | Right |
| --- | --- | --- | --- |
| 106 | 36 | Control bar: Period (date range, 244, w 260), Zone (520); feed status line x 1116 | |
| 158 | 32 | Caption (verbatim) | |
| 206 | 96 | Latest box: date, ratio, 5-day avg (x 244, w 740) | Zone chip panel (x 1000, w 376) |
| 318 | 420 | Line chart, full width | |
| 754 | 300 | Recent readings table, full width (10 rows) | |

Canvas 1400 x 1090.

## 2. Elements (tab `put_call`)

**Page filter (always on).** Page > Current page settings > Filters > Add: Include `name` Equal to EQUITY PUT/CALL RATIO. (Type it once, slowly; or copy it from this file.)

**Controls.** Period: Date range on `date`, default Last 90 days (the tab holds about 110 sessions from 2026-05-18). Zone: drop-down on `zone` (Fear / Neutral / Greed), default all, x 520; it filters the readings table only (Arrange > Group the control with that table).

**Caption (verbatim).** "Market mood only. Not an option position."

**Latest box (x 244, y 206).** Latest-row table: Dimensions `date` Date, `value` Put/call, `ma5` 5-day avg (3 decimals), header ON, value 20 pt.

**Zone chip (x 1000, y 206).** Latest-row table with Dimension `zone` only and Sort `date` Descending (Sort accepts a field that is not shown), Rows 1. Rules on `zone`: Fear font #EF4444; Greed font #22C55E; Neutral font #8B96AD. Label above: "Today's zone".

**Line chart (y 318, 1132 x 420).** Time series, Dimension `date`, Metrics `value` "Put/call" #7C9CFF (Average), `ma5` "5-day avg" #E6EBF5. Reference lines: Metric `fear_line` Average, colour #EF4444 dashed, label "Fear 1.0"; Metric `greed_line` Average, colour #22C55E dashed, label "Greed 0.7". Missing data Linear interpolation. Y axis min 0.3, max 1.3 (Style > Left Y-axis). Legend Top. Title "Equity put/call ratio".

**Recent readings (y 754).** Table: `date` Date, `value` Put/call (2), `ma5` 5-day avg (3), `zone` Zone. Sort `date` Descending. Rows 10. Zone font rules as above.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Latest-row box.** Looker scorecards cannot pick "the latest row". Use a table instead: Dimensions `date` + the field(s), Sort `date` Descending, Rows per page 1, Pagination OFF, header ON (11 pt muted) or OFF, no border, value 20 pt bold. It always shows the newest row.

**Zone chip.** A latest-row box on the zone field inside a 140 x 40 rectangle (background #121826, border #1E293B, radius 6). Font colour rules on the zone text as listed; no fill.

**Line chart style (L).** Time series chart, Dimension `date` (type Date). Style > Series: weight 2, colours as listed, Missing data > Linear interpolation (or Line breaks), never Show as 0. Axes Roboto 11 pt #8B96AD; Grid > Axis and Gridline colour #1E293B; Chart background #121826, Border #1E293B, radius 8. Legend: None for one series (the title names it); for several series, Legend Top, Roboto 11 pt #8B96AD, or name the colours in the title. Title Roboto 13 pt bold #E6EBF5 on the chart (Style > Show title) or a text box above it.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Line chart: copy the Backtest "Growth of 10,000" chart, switch to `put_call`, swap metrics, add the two reference lines. XLY/XLP and Historical P/E copy this one next.
- Zone chip: build here; XLY/XLP copies it (rules change to Risk on / Risk off).

## 5. Data gaps
- The tab mixes 25 CBOE ratio names; the page filter keeps only EQUITY PUT/CALL RATIO (110 rows). The other 24 are not used.
- `fear_line` and `greed_line` are 1.0 and 0.7 on every row (from settings); the reference lines read them, so a settings change flows through.
- Looker has no viewer switch to hide one line of a chart; the zone drop-down is the page's on/off control.

## 6. Build order
1. Canvas 1400 x 1090; page filter on `name`.
2. Line chart (copied), reference lines.
3. Latest box, zone chip, readings table.
4. Controls. Test: Period Last 30 days; latest zone shows Greed (0.69 on 2026-10-22).
