# Sector macro scores: Looker design spec (Design Pro)

**Purpose.** How the latest economic surprises tilt each sector ETF (growth, inflation, jobs and a total), next to the ETFs' own price changes. Two separate tables, no blending. A sketch, not a forecast.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Left | Right |
| --- | --- | --- | --- |
| 106 | 36 | Control bar: Macro score (244), Sector ETF (460); feed status line x 1116 | |
| 158 | 32 | Caption | |
| 206 | 720 | Macro table (x 244, w 620), 19 rows | Price change table (x 880, w 496), 19 rows |

Canvas 1400 x 960.

## 2. Elements

**Controls.** Macro score: drop-down `macro_score` (tab `sector_macro`), default all. Sector ETF: drop-down `ticker` (tab `sector_macro`), multi; it filters both tables when Looker matches the `ticker` field across the two tabs; if the right table does not react, add a second Ticker drop-down for `sectors` and group it with that table.

**Caption.** Text-value box on `plain_english` (one value): "Rule of thumb from the latest surprises. It is not a forecast." plus static text: "Weights are fixed in the job (for example, hotter inflation helps energy and hurts technology). The Help page says they are a sketch."

**Macro table (tab `sector_macro`, x 244).** Columns: `ticker` ETF, `name` Sector, `macro_growth` Growth, `macro_inflation` Inflation, `macro_jobs` Jobs, `macro_score` Total. Sort `macro_score` Descending. Rows 19, pagination OFF. Colour the four number columns with the point scale: 4 x 6 = 24 rules is over the limit, so use one Colour scale rule per column (Min -2 #B91C1C, Mid 0 #283146, Max 2 #166534), or "Select any field" exact rules (=2, =1, =0, =-1, =-2: 5 rules; the text columns never equal a number). Centre the four columns.

**Price change table (tab `sectors`, x 880).** Columns: `ticker` ETF, `day_pct` Day % (2), `week_pct` Week % (2), `month_pct` Month % (2), `ytd_pct` YTD % (2). Sort `ytd_pct` Descending and title it "Price change (sorted by YTD)" (the two tables cannot share one order without blending). Rows 19. Return rules on the four columns (12).

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Point colours (-2..+2), per point column.** Style > Conditional formatting > Add > Single colour, Apply to = that column only (not entire row): = 2 fill #166534; = 1 fill #14532D; = 0 fill #283146; = -1 fill #7F1D1D; = -2 fill #B91C1C; all with font #E6EBF5 bold; plus Is null > font #D6A64A, no fill. Centre the column if Style offers alignment. Looker allows 20 rules per chart: if a table has more than three point columns, use one Colour scale rule per column instead (Colour type > Colour scale, Min -2 #B91C1C, Mid 0 #283146, Max 2 #166534), or a "Select any field" rule set when every coloured column is a point column.

**Return colours (text, not fill).** Per return column: > 0 font #22C55E; < 0 font #EF4444; = 0 leaves #E6EBF5; Is null > font #D6A64A. Apply to that column only.

**Text-value box (one-row table).** For a text field (company, reason, headline): Insert > Table, Dimension = the field, remove the metric (Record Count). Style: Table header OFF, Pagination OFF, Row numbers OFF, Wrap text ON, Background transparent, border none, Missing data Show blank. Font size and colour as listed.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Macro table: copy the Macro screener table, switch to `sector_macro`; use "Select any field" rules.
- Price table: copy the Gainers and losers table or the Today page's Top sectors table (if built) and switch to `sectors`.

## 5. Data gaps
- `plain_english` is the same sentence on all 19 rows, so it is the caption, not a column.
- The two tables cannot share a sort order without blending (not allowed). Both list the same 19 ETFs.
- If the surprise feed is missing the macro cells go blank: amber dashes, and the feed status line shows the note.

## 6. Build order
1. Canvas 1400 x 960. 2. Both tables. 3. Caption, controls. Test: Macro score = 2 shows one ETF on the left.
