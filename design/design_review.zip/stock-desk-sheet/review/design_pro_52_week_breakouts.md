# 52-week breakouts: Looker design spec (Design Pro)

**Purpose.** Stocks within 1% of, or through, their 52-week high today, closest first, with volume and the desk's score. An empty list is a result (nobody near a high), not a broken feed.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Sector (244), Verdict (460), Ticker (676); feed status line x 1116 |
| 158 | 96 | 3 cards of 366: Near a 52-week high, With volume above average, Of those, BUY |
| 270 | 560 | Breakouts table, full width, 15 rows |
| 846 | 32 | Caption |

Canvas 1400 x 910.

## 2. Elements (tab `breakouts`)

**Controls.** Sector, Verdict: drop-downs, default all. Ticker: drop-down, Search ON.

**Cards.** Record Count (14 today); Record Count filter `volume_ratio` >= 1; Record Count filter `verdict` = BUY.

**Breakouts table.** Columns: `ticker` Ticker, `company` Company, `sector` Sector, `price` Price (2), `dist_52w_high_pct` From 52-week high % (2), `volume_ratio` Volume vs 50-day (2), `score` Score, `verdict` Verdict. Sort `dist_52w_high_pct` Descending (closest to the high, or through it, first). Rows 15. Rules: score bands (5), verdict (3), ticker (1), `dist_52w_high_pct` >= 0 font #22C55E bold (through the high) (1), `volume_ratio` >= 1.5 font #22C55E (1) = 11.

**Caption.** "Within 1% of the 52-week closing high. If the list is empty, nobody is near a high today: that is a result, and the note above says so."

**Empty state.** When the only row is the MISSING note, the feed status line (right of the controls) shows it; nothing else to build.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Total score bands (`score`, desk range -6 to 13).** Single colour rules, Apply to = Score column, font #E6EBF5 bold: >= 12 fill #166534; between 9 and 11 fill #14532D; between 5 and 8 fill #283146; between 1 and 4 fill #7F1D1D; <= 0 fill #B91C1C. Same bands as Top stocks, so copying a Top stocks table brings them along.

**Verdict text.** Rules on `verdict`, Apply to = Verdict column, bold, no fill: Equal to BUY font #22C55E; HOLD font #F59E0B; AVOID font #EF4444.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Duplicate the Growth scanner page (Page > Duplicate page), Ctrl+A (not nav/header) > Setup > Data source > `breakouts`; remove the Passes control; swap the growth columns for distance and volume.

## 5. Data gaps
- All spec columns present. Today all 14 rows are just under the high (-0.03% to -0.99%), none through it.

## 6. Build order
1. Duplicate Growth; canvas 1400 x 910. 2. Swap source and columns. 3. Cards, caption.
