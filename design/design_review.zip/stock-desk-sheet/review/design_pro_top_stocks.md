# Nick's Stock Desk: design review, Top stocks page (Looker Design Pro)

Based on looker_top_stocks_v2.png (Oct 23, 9:06 PM PT) and LOOKER_SPEC.md. Goal from Nick: look really
appealing and professional. Keep the spec theme: background #0B0F17, panels #121826, text #E6EBF5,
muted #8B96AD, grid #1E293B, up #22C55E, down #EF4444, hold #F59E0B, accent #7C9CFF.
Use panel settings, arrow keys and the Arrange menu (dragging is unreliable).

## Priority fixes

1. Human column names (biggest "professional" win). Raw names like r.., s.., day_.., entry_low,
   trade_target, index_membership look unfinished. In Setup, click each field's name and rename:
   rank > #, ticker > Ticker, company > Company, sector > Sector, score > Score, verdict > Verdict,
   price > Price, day_pct > Day %, timing > Trend, entry_low > Entry low, entry_high > Entry high,
   stop > Stop, trade_target > Target. Same for the drop-downs: Setup > Control field label, e.g. Verdict,
   Sector, Confidence, Index.
2. Fewer columns so nothing is cut and there is no sideways scrollbar. Remove "reason" from this table
   (it is long text and always cut off); it belongs on the Stock scorecard page. Keep:
   #, Ticker, Company, Sector, Score, Verdict, Price, Day %, Trend, Entry low, Entry high, Stop, Target.
3. Header block is too tall and empty. Title 32 bold #E6EBF5 at the top left (24 px margin), research
   line right under it, 14 #8B96AD (shared header, see design_pro_nav_header.md). Move the four drop-downs into one slim row under that (about 36 px
   tall each, Style > Background #121826, Border #1E293B, radius 6, text #E6EBF5 12 pt). The table then
   starts about 140 px from the top instead of about 260 px.
4. Table styling. Style > Table colours: Header background #121826, header font #8B96AD bold 11 pt,
   Odd row #0F1420, Even row #121826 (soft zebra), Cell borders #1E293B, Highlight on hover #1A2236.
   Body font 12 pt #E6EBF5. Style > Background and border: Background #121826, Border #1E293B, radius 8.
5. Score colours. Scores run up to about 13, so the -2..+2 rule paints every row the same green.
   Use bands: >= 12 fill #166534, 9 to 11 fill #14532D, 5 to 8 fill #283146, 1 to 4 fill #7F1D1D,
   <= 0 fill #B91C1C, text #E6EBF5 bold, centred. (Adjust bands to the real score range if it differs.)
6. Verdict as coloured text, bold: BUY #22C55E, HOLD #F59E0B, AVOID #EF4444 (font colour rules, no fill).
7. Trend as coloured text: Uptrend #22C55E, Downtrend #EF4444, Extended #F59E0B, Sideways #8B96AD.
8. Day % : keep Type Number (day_pct is already a percent, -1.08 means -1.08%; Percent type would show -108%), 2 decimals, '%' in the label, font colour > 0 #22C55E, < 0 #EF4444.
9. Prices: Price, Entry low, Entry high, Stop, Target as Number with exactly 2 decimals
   (today 252.2 vs 45.69 looks messy). Right-align numbers if the build offers it.
10. Ticker bold #7C9CFF (font rule "is not null" or Style for that column) so it reads like a link.
11. Rows per page 25 is good. Keep sort by Score descending. Turn off the row-number column
    (Style > Table body > Row numbers off) if # is shown.
12. Left navigation: Theme and layout > Navigation type Left, selected page in #7C9CFF.

## Look across the whole report (both reports)
- Same header on every page: title, research line, Updated box, made report-level.
- One theme in Theme and layout > Theme > Customise, set before building more pages.
- One radius (8 for panels, 6 for pills and controls), one border colour, 24 px outer margin, 16 px gaps.
- Coloured fills only for scores. Everything else uses coloured text, so the page stays calm.
- No raw field names anywhere, no cut-off headers, no sideways scrolling.
