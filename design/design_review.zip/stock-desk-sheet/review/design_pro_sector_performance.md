# Sector performance: Looker design spec (Design Pro)

**Purpose.** Equal-weight returns of the desk's own stocks in each sector (day to year-to-date), with breadth and average score. Not the ETF: the ETF view is the Top sectors table from `sectors`.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Sector (244), Min. stocks slider (460, w 260); feed status line x 1116 |
| 158 | 32 | Caption |
| 206 | 300 | Month % column chart by sector, full width |
| 522 | 560 | Sector table, full width, 15 rows |

Canvas 1400 x 1110.

## 2. Elements (tab `sector_performance`)

**Controls.** Sector: drop-down `sector`, multi, default all. Min. stocks: Slider on `n`, default 5 to max (hides one-stock "sectors" such as Consumer Cyclical with n = 1; drag to 1 to show them).

**Caption.** "Equal weight across the desk's stocks in each sector, not the sector ETF. The ETF view is Top sectors."

**Column chart.** Dimension `sector`, Metric `month_pct` Average "Month %", Sort Descending, bar rules > 0 #22C55E, < 0 #EF4444, data labels ON (1 dec). Title "Past month, equal-weight %".

**Sector table.** Columns: `sector` Sector, `day_pct` Day %, `week_pct` Week %, `month_pct` Month %, `month3_pct` 3 months %, `ytd_pct` YTD % (all 2 dec), `pct_above_sma50` % above 50-day (1), `score_avg` Average score (2), `n` Stocks (0). Sort `ytd_pct` Descending. Rows 15, pagination OFF. Rules: return rules on the five % return columns: 5 x 3 = 15 (drop the null rule on them: never blank today) so 5 x 2 = 10; `n` < 5 font #8B96AD (1).

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Bar/column chart style (B).** Style > Bars colour as listed, Show data labels ON (11 pt #E6EBF5) when there are fewer than 15 bars, Axes 11 pt #8B96AD, Gridlines #1E293B, Background #121826, Border #1E293B, radius 8, Legend None (title names it). Bar charts accept conditional formatting: > 0 bar #22C55E, < 0 bar #EF4444.

**Return colours (text, not fill).** Per return column: > 0 font #22C55E; < 0 font #EF4444; = 0 leaves #E6EBF5; Is null > font #D6A64A. Apply to that column only.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Chart: copy the Backtest bucket chart (bar +/- rules set), switch to `sector_performance`.
- Table: copy the Gainers table, switch source, swap columns; copy the Day % rule pair across.

## 5. Data gaps
- Sector names come from two naming sets: Consumer Cyclical (n 1), Consumer Defensive (1), Financial Services (1), Technology (3) sit beside Consumer Discretionary, Consumer Staples, Financials, Information Technology. Their tiny n gives extreme numbers (Consumer Cyclical week -20.41%, YTD -43.24%). The Min. stocks slider hides them by default; the job should map them to the 11 GICS names.

## 6. Build order
1. Canvas 1400 x 1110. 2. Table, chart. 3. Slider default 5; test dragging it to 1 brings back the four one-off sectors.
