# AAII: Looker design spec (Design Pro)

**Purpose.** An honest MISSING page: AAII does not publish a free machine-readable survey, so the page explains that in readable type and points to the put/call page. No fake chart, no typed numbers.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: none needed (feed status line x 1116 shows MISSING) |
| 158 | 200 | Message panel, w 740, centred block at x 244 |
| 374 | 48 | Link text to Put/call ratio |

Canvas 1400 x 600.

## 2. Elements (tab `aaii_sentiment`)

**Message panel (x 244, y 158, 740 x 200).** Rectangle (panel style). Inside: small label "Status" 11 pt muted over a text-value box on `data_status` (reads MISSING), 13 pt bold #F59E0B. Under it a text-value box on `note`, Roboto 18 pt #E6EBF5, wrap ON, w 700: "AAII does not publish a free machine-readable survey. This page stays MISSING on purpose. The put/call page is the free mood gauge."

**Link (y 374).** Text box "The free mood gauge is the put/call ratio." 14 pt #7C9CFF, linked to the Put/call ratio page (select the words > link icon > paste that page's URL; do not type it).

**On/off.** Nothing to switch: the page has no data rows. `bullish_pct`, `neutral_pct`, `bearish_pct` are not placed anywhere.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Text-value box (one-row table).** For a text field (company, reason, headline): Insert > Table, Dimension = the field, remove the metric (Record Count). Style: Table header OFF, Pagination OFF, Row numbers OFF, Wrap text ON, Background transparent, border none, Missing data Show blank. Font size and colour as listed.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Panel: copy any panel rectangle. Text-value boxes: copy the Backtest headline box and switch it to `aaii_sentiment`.
- Link text: copy a nav item text box (already link-styled) and change words and URL.

## 5. Data gaps
- `as_of`, `bullish_pct`, `neutral_pct`, `bearish_pct` are blank (1 row, MISSING) by design. Nothing to chart.

## 6. Build order
1. Canvas 1400 x 600. 2. Data source. 3. Panel, status, note, link. Done.
