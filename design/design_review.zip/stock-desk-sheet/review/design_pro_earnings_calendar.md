# Earnings calendar: Looker design spec (Design Pro)

**Purpose.** Who reports in the next two weeks, how the last report went (surprise and next-day move), and the usual next-day move, with a switch for Nick's holdings.

No sample picture (table page in the Top stocks look).

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Days away slider (244, w 300), Holdings only (560), Ticker (776); feed status line x 1116 |
| 158 | 96 | 3 count cards of 366: Reporting in the window, Of those, Nick's holdings, After the close |
| 270 | 880 | Calendar table, full width, 25 rows |
| 1166 | 40 | Caption (verbatim) |

Canvas 1400 x 1240.

## 2. Elements (tab `earnings_calendar`)

**Controls.** Days away: Slider on `days_away`, default range 0 to 14 (the on/off for "far away" names: drag the ends in the slider's Setup > Default value fields, not on the canvas). Holdings only: drop-down `owns`, Single select, default all (pick yes for Nick's holdings). Ticker: drop-down `ticker`, Search ON. All three drive cards and table.

**Count cards.** Record Count; "Reporting in the window" (no extra filter, 326 today for 0-14); "Nick's holdings" filter `owns` = yes; "After the close" filter `when_hint` = after close.

**Calendar table.** Columns: `ticker` Ticker, `company` Company, `next_earnings` Report date (Date, format e.g. Oct 30), `when_hint` When, `days_away` Days away (0), `last_eps_actual` Last EPS (2), `last_eps_estimate` Last estimate (2), `last_surprise_pct` Last surprise % (1), `last_1d_move_pct` Last next-day move % (1), `avg_1d_move_pct` Avg next-day move % (1), `n_past` Reports on file (0). Sort `days_away` Ascending, then `ticker`. Rows 25. Colours: ticker (1); return rules on `last_surprise_pct`, `last_1d_move_pct`, `avg_1d_move_pct` (9); `owns` as a narrow last column "Held": yes font #F59E0B bold, no font #5B6680 (2) = 12. `when_hint` after close #7C9CFF, other #8B96AD (2) = 14.

**Caption (verbatim).** "The one-day move is the next session after a report that hit at or after 4pm Eastern, otherwise the session of the report. The average is the last eight reports."

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Return colours (text, not fill).** Per return column: > 0 font #22C55E; < 0 font #EF4444; = 0 leaves #E6EBF5; Is null > font #D6A64A. Apply to that column only.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Table: copy the Top stocks table; Setup > Data source > `earnings_calendar`; delete score/verdict rules; copy the Day % rule pair to the three % columns.
- Cards: copy from Growth.
- Slider: style once here; Earnings tracker reuses a date control instead.

## 5. Data gaps
- `next_earnings` and `days_away` blank for 2 tickers; the slider hides them.
- `last_1d_move_pct` and `avg_1d_move_pct` blank for 6 (price history did not cover the session): amber dash = n/a.
- The spec names a "toggle for holdings": Looker checkboxes need a true/false field and `owns` is yes/no text, so it is a one-pick drop-down.

## 6. Build order
1. Canvas 1400 x 1240, header, Earnings nav block.
2. Data source `earnings_calendar`; `next_earnings` type Date.
3. Table (copied), cards, caption.
4. Slider (default 0-14), Holdings drop-down, Ticker. Test: Holdings only = yes shows MSFT (4 days) and AAPL (9 days); widen the slider to 90 and all 5 holdings appear.
