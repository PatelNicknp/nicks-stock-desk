# Gainers and losers: Looker design spec (Design Pro)

**Purpose.** Today's 15 biggest gainers and 15 biggest losers on the desk, side by side, with score and verdict for context.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Left | Right |
| --- | --- | --- | --- |
| 106 | 36 | Control bar: Sector (244), Verdict (460); feed status line x 1116 | |
| 158 | 600 | Gainers table (x 244, w 558), 15 rows | Losers table (x 818, w 558), 15 rows |
| 774 | 32 | Caption | |

Canvas 1400 x 840.

## 2. Elements (tab `gainers_losers`)

**Controls.** Sector, Verdict: drop-downs, default all (they filter both tables).

**Gainers table (x 244).** Chart filter Include `side` = gainer. Columns: `ticker` Ticker, `company` Company, `price` Price (2), `day_pct` Day % (2), `score` Score, `verdict` Verdict. `sector` left off to fit 558 px (it is in the control). Sort `day_pct` Descending. Rows 15, pagination OFF. Title "Biggest gainers today". Rules: return (3), score bands (5), verdict (3), ticker (1) = 12.

**Losers table (x 818).** Copy of the gainers table, filter `side` = loser, Sort `day_pct` Ascending, title "Biggest losers today".

**Caption.** "Day % is the latest session's change, for stocks on the desk only."

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Total score bands (`score`, desk range -6 to 13).** Single colour rules, Apply to = Score column, font #E6EBF5 bold: >= 12 fill #166534; between 9 and 11 fill #14532D; between 5 and 8 fill #283146; between 1 and 4 fill #7F1D1D; <= 0 fill #B91C1C. Same bands as Top stocks, so copying a Top stocks table brings them along.

**Return colours (text, not fill).** Per return column: > 0 font #22C55E; < 0 font #EF4444; = 0 leaves #E6EBF5; Is null > font #D6A64A. Apply to that column only.

**Verdict text.** Rules on `verdict`, Apply to = Verdict column, bold, no fill: Equal to BUY font #22C55E; HOLD font #F59E0B; AVOID font #EF4444.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Gainers: copy the Top stocks table (all needed rules are there), switch to `gainers_losers`, trim columns, add the side filter. Losers: copy Gainers, flip filter and sort. Arrange > Align top, Make same size.

## 5. Data gaps
- All spec columns present (30 rows, 15 per side). `sector` is dropped from the tables to avoid sideways scrolling.
- Sector names mix two naming sets (e.g. Technology and Information Technology).

## 6. Build order
1. Canvas 1400 x 840. 2. Gainers table, then copy to Losers. 3. Controls, caption.
