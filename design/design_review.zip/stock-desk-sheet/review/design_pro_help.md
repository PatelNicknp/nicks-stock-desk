# Help: Looker design spec (Design Pro)

**Purpose.** Plain-English answers about the desk (the score, blanks, backtest limits, feeds that stay MISSING) and, at the bottom, the settings switches. No upsells, no course links, no "unlock".

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Topic (244, w 300), Settings group (560) |
| 158 | 1000 | Help list, full width (23 rows, wrap) |
| 1174 | 28 | Section title "Settings" + caption |
| 1210 | 420 | Settings table, w 740, 10 rows per page |

Canvas 1400 x 1660.

## 2. Elements

**Controls.** Topic: drop-down `topic` (tab `help`), Search ON, default all. Settings group: Input box control on `setting` (tab `settings`): typing "feature." or "scoring." narrows the table (Input box matches text contained in the field). Group it with the settings table.

**Help list (tab `help`).** Two-column table: `topic` Topic (w 220, bold #E6EBF5, 13 pt), `plain_english` What it means (wrap ON, 13 pt, line spacing natural). No sort other than the sheet order: Looker sorts, so use Sort `topic` Ascending, or leave Sort empty to keep the sheet order if your version allows. Rows 25, pagination OFF. Header OFF (cleaner), row borders #1E293B.

**Settings table (tab `settings`).** Columns `setting` Setting (11 pt, #8B96AD), `value` Value. Sort `setting` Ascending. Rows 10 per page, pagination ON (this is the "collapsed" version: Looker cannot fold a table, so it starts on page 1 and Nick pages on). Rule: `value` Equal to True font #22C55E; False font #EF4444.

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Help list: copy the Backtest Test limits table (two columns, wrap already on), switch to `help`.
- Settings: copy the Data updates field coverage table, switch to `settings`.

## 5. Data gaps
- `help` and `settings` have no `data_status`, `note` or `disclaimer` columns, so no feed status line.
- The last settings row is `label` (the research line text); harmless, it shows at the end when sorted.
- 47 `feature.*` switches are all True today.

## 6. Build order
1. Canvas 1400 x 1660. 2. Help list. 3. Settings table, Input box. Test: type scoring. shows the score lines.
