# Earnings report cards: Looker design spec (Design Pro)

**Purpose.** A letter grade per company from a fixed rule on recent earnings beats and revenue growth, with the one-line summary. Not a write-up, not a trade.

No sample picture.

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Grade (244), Ticker (460); feed status line x 1116 |
| 158 | 40 | Caption (verbatim), full width |
| 214 | 96 | 5 grade count cards (A, B, C, D, F), 213 each |
| 326 | 880 | Report card table, full width, 25 rows |
| 1222 | 32 | Sources line |

Canvas 1400 x 1280.

## 2. Elements (tab `earnings_cards`)

**Controls.** Grade: drop-down `grade`, multi, default all. Ticker: drop-down `ticker`, Search ON.

**Caption (verbatim).** "Grades are a fixed rule on the last few earnings beats and revenue growth versus the company's own history. They are not a write-up from a person, and they are not a trade."

**Grade cards (y 214).** Five scorecards 213 x 96, Record Count, filter `grade` = A / B / C / D / F; label "Grade A" etc. Card background uses the grade fill (A #166534, B #14532D, C #283146, D #7F1D1D, F #B91C1C), value #E6EBF5. Today: A 157, B 273, C 59, D 19, F 12. Keep them outside the Grade control's group (Arrange > Group the Grade control with the table).

**Report card table.** Columns: `ticker` Ticker, `company` Company, `grade` Grade (centred, w 70), `summary` Summary (wrap ON, the widest column). Sort `grade` Ascending (A first), then `ticker`. Rows 25. Rules: grade fills (6), ticker (1).

**Sources line (y 1222).** Text-value box on `sources` (one distinct value), 11 pt muted: "Yahoo Finance earnings dates. Revenue vs estimate is not in that free feed, so revenue is left blank."

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Grade fills.** Rules on `grade`, Apply to = Grade column, font #E6EBF5 bold, centred: Equal to A fill #166534; B fill #14532D; C fill #283146; D fill #7F1D1D; F fill #B91C1C; Is null font #D6A64A (amber dash = n/a, no history).

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Text-value box (one-row table).** For a text field (company, reason, headline): Insert > Table, Dimension = the field, remove the metric (Record Count). Style: Table header OFF, Pagination OFF, Row numbers OFF, Wrap text ON, Background transparent, border none, Missing data Show blank. Font size and colour as listed.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Table: copy the Top stocks table, switch to `earnings_cards`, replace score rules with grade rules.
- Cards: style "Grade A", copy four times, change filter and background; Arrange > Distribute horizontally.

## 5. Data gaps
- `grade` blank for 4 tickers (no history): amber dash = n/a; sorted last.
- `summary` has 9 distinct sentences; fine.
- `sources` is the same on every row, so it is a line, not a column.

## 6. Build order
1. Canvas, header. 2. Data source. 3. Table, cards, caption, sources line. 4. Controls; test Grade = F shows 12 rows.
