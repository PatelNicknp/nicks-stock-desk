# Leaders: Looker design spec (Design Pro)

**Purpose.** VCP and CANSLIM on one row per ticker: names that are ready or broke out on either scan, with which scan each comes from. When a name is on both, buy point, stop and target are the VCP ones; a CANSLIM-only row leaves stop and target blank.

No sample picture (same look as `sample_vcp.png`).

## 1. Layout (content x 244-1376)

| y | Height | Element |
| --- | --- | --- |
| 106 | 36 | Control bar: Status (244), On VCP (460), On CANSLIM (676), Ticker (892); feed status line x 1116 |
| 158 | 96 | 4 count cards of 271: On both scans, VCP only, CANSLIM only, Ready |
| 270 | 520 | Leaders table, full width, 14 rows |
| 806 | 220 | Why this name (detail), full width |
| 1042 | 48 | Rule line (`note`) |

Canvas 1400 x 1120.

## 2. Elements (tab `scanner_leaders`)

**Controls.** Status: `status`, multi, default READY + BROKEN OUT today (grouped with the table and detail). On VCP: `on_vcp` (yes/no), default all. On CANSLIM: `on_canslim`, default all. Picking yes on both shows the overlap. Ticker: `ticker`.

**Count cards.** Record Count with filters: "On both scans" `on_vcp` = yes AND `on_canslim` = yes; "VCP only" `on_vcp` = yes AND `on_canslim` = no; "CANSLIM only" `on_vcp` = no AND `on_canslim` = yes; "Ready" `status` = READY (112).

**Leaders table (y 270).** Columns: `ticker` Ticker, `index_membership` Index, `status` Status, `on_vcp` VCP, `on_canslim` CANSLIM, `pivot` Buy point (2), `stop` Stop (2), `target` Target (2), `strength` Strength (bar), `vcp_status` VCP status, `canslim_status` CANSLIM status, `vcp_strength` VCP strength (0), `canslim_strength` CANSLIM strength (0), `freshness` Data. Sort `strength` Descending. Rows 14. Cross-filtering ON. Colours: setup words (6); `on_vcp` and `on_canslim` yes #22C55E / no #8B96AD (4); ticker (1); stop/target Is-not-null font (2); Is-null amber on `stop`, `target`, `vcp_status`, `vcp_strength` (4) = 17. Column widths: keep yes/no columns about 60 px so the row fits 1132 px.

**Why this name (y 806).** Table `ticker`, `reason` (wrap), Rows 3, sort `strength` Descending.

**Rule line (y 1042).** Text-value box on `note`: "Leaders is the overlap of a ready or just-broken VCP and a strict CANSLIM qualify. A name on only one of those still appears."

## 3. Styling

**Canvas grid.** Positions are on a 1400-wide canvas: left nav x 0-220, content x 244-1376 (w 1132). Shared header and nav come from design_pro_nav_header.md (title y 24, research line y 66, Updated chip top right); paste them first. Control bar y 106-142 (drop-downs 200-220 x 36, 16 px gaps, from x 244). Content starts y 158. Gaps 16 px. Columns: 2 = 558 + 16 + 558; 3 = 366 / 367 / 367; 4 = 271 each; 6 = 175 each. **If the canvas is 1600 wide** (the nav/header spec recommends it), content runs x 244-1576: widen every full-width element by 200, and in split rows widen the left element by 200 and move the right element 200 px right. Position with arrow keys (Shift+arrow for bigger steps), Arrange > Align (Left / Top), Arrange > Distribute horizontally, Arrange > Make same size. No dragging.

**Table style (T).** Style tab: Table header > Wrap text ON, Roboto 11 pt bold, colour #8B96AD. Table colours > Header background #121826, Cell border #1E293B, Odd row #0F1420, Even row #121826 (and Highlight/hover #1A2236 if your version shows it). Table labels > Roboto 12 pt #E6EBF5. Table body > Row numbers OFF, Wrap text OFF unless a column below says wrap. Background and border > Background #121826, Border colour #1E293B, weight 1, Border radius 8. Missing data > Show "-" (never Show 0). Rename every field in Setup: click the field name, type the human label, Enter. Prices: Setup > field > Number, decimals 2 (or Style > Column > Decimal precision 2). Values ending _pct are already in percent units (-1.08 means -1.08%): keep them Number with 1-2 decimals and put "%" in the label. Do NOT switch them to Percent type (that shows -108%).

**Setup words (pattern scanners).** `status` font, bold, Apply to Status column: Equal to BROKEN OUT today #22C55E; READY #F59E0B; WATCHING #8B96AD. `freshness` font: FRESH #8B96AD; PARTIAL #F59E0B; STALE #EF4444. Strength as a calm data bar: Style > the Strength column > Bar (Show number ON), bar colour #7C9CFF, 0 decimals.

**Click-to-read detail panel.** Main table: Setup > Chart interactions > Cross-filtering ON. The detail table (same tab) then shows the clicked row; with nothing clicked it shows the top rows by the same sort. Detail table: Dimensions `ticker` + the long text fields, Style > General > Horizontal OFF, Wrap text ON, Rows 3, header ON (11 pt muted). Caption above it: "Click a row in the table to read its full reason." 

**Count cards.** Scorecards, Metric Record Count (or the stated average), each with its own chart filter. Keep them out of the main switch's reach: select the main switch and the table only > Arrange > Group, so the cards always show the whole picture. Values 24 pt #E6EBF5, no colour.

**Scorecard style (S).** Style > Label Roboto 11 pt #8B96AD; Metric Roboto 24 pt bold #E6EBF5; Background #121826, Border #1E293B, radius 8; Compact numbers OFF; Missing data Show "-"; no comparison unless stated. Size 271 x 96 (4 across) unless stated.

**Ticker accent.** Rule: `ticker` Is not null > font #7C9CFF bold, Apply to = Ticker column.

**Text-value box (one-row table).** For a text field (company, reason, headline): Insert > Table, Dimension = the field, remove the metric (Record Count). Style: Table header OFF, Pagination OFF, Row numbers OFF, Wrap text ON, Background transparent, border none, Missing data Show blank. Font size and colour as listed.

**Blank = n/a (amber dash).** Looker cannot print custom text for blank cells. Missing data > Show "-", then Style > Conditional formatting > Add > Single colour > field > condition Is null (called Empty in some versions) > Font #D6A64A, no fill, Apply to: that column. The amber dash is the desk's n/a. Never choose Show 0.

**Feed status line.** One-row table, Dimension `note`, chart filter Include `data_status` Equal to MISSING. Style as a text-value box, Roboto 12 pt, font #F59E0B, height 28 px, placed at the right end of the control bar (x 1116, y 112, w 260, h 24) unless the page says otherwise. When the feed is fine the table is empty; if Looker prints a faint "No data", set Table labels font #121826 so it vanishes on the panel and add rule `note` Is not null > font #F59E0B so a real note still shows.

**Control style (C).** Drop-down list: Setup > Control field label = human name; Search ON for ticker/company lists. Style > Background #121826, Border #1E293B 1 px, Border radius 6, Roboto 12 pt #E6EBF5, size 200 x 36. Slider and checkbox: same colours, accent #7C9CFF. Every chart group on the page has a control, so Nick can switch any part off or narrow it. A control filters every chart on the page that uses that tab; to limit it to one group, select the control and the charts it should drive and use Arrange > Group.

**Text boxes.** Section titles Roboto 13 pt bold #E6EBF5. Captions Roboto 11 pt #8B96AD, wrap ON, transparent background. Type captions slowly and re-read them once: the builder sometimes drops characters.

## 4. Copy-paste reuse
- Page > Duplicate page on Box breakout (full-width detail layout); Ctrl+A (not nav/header) > Setup > Data source > `scanner_leaders`. Add the on/status/strength pairs.
- Copy the status-word rules once more for `vcp_status` and `canslim_status` only if the rule budget allows (6 more = 23, over the limit): leave those two columns plain #E6EBF5.

## 5. Data gaps
- Today 5 names are on both scans, 1 is VCP only, 178 are CANSLIM only. Stop and target are blank on the 178 CANSLIM-only rows (by design): amber dashes.
- `status` has READY 112 and WATCHING 72, no BROKEN OUT today rows.
- `vcp_status`, `vcp_strength` blank on 178 rows; `canslim_status` and `canslim_strength` blank on 1 (the VCP-only row).

## 6. Build order
1. Duplicate Box breakout; title "Leaders".
2. Swap source, columns, rules.
3. Cards, detail, rule line. Test: On VCP = yes shows 6 names with stops and targets filled (5 on both, 1 VCP only).
